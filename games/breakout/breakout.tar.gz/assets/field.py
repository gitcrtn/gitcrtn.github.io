import math
WIDTH = 720
HEIGHT = 720
TOP = 56
PADDLE_W = 112
PADDLE_W_LONG = 168
PADDLE_H = 16
PADDLE_Y = 640
PADDLE_SPEED = 9
BALL = 12
BALL_SPEED = 6.0
SPEED_PER_STAGE = 0.5
SPEED_PER_HITS = 0.5
HITS_PER_SPEEDUP = 12
SPEED_MAX = 10.0
BALLS_MAX = 3
LAUNCH_ANGLE = 30
EDGE_ANGLE = 60
MOVE_ANGLE = 20
MAX_ANGLE = 70
SPLIT_ANGLE = 30
COLS = 10
ROWS = 8
BRICK_W = 64
BRICK_H = 24
BRICK_GAP = 4
BRICK_LEFT = 22
BRICK_TOP = 100
HARD = "H"
POINTS = 10
POINTS_HARD = 30
EMPTY = "."
LONG = "E"
MULTI = "M"
SLOW = "S"
LIFE = "1"
ITEM_KINDS = (LONG, MULTI, SLOW, LIFE)
ITEM_W = 48
ITEM_H = 24
ITEM_SPEED = 3
ITEM_POINTS = 50
def brick_rect(col, row):
    return (BRICK_LEFT + col * (BRICK_W + BRICK_GAP), BRICK_TOP + row * (BRICK_H + BRICK_GAP), BRICK_W, BRICK_H)
class Ball:
    __slots__ = ("x", "y", "vx", "vy")
    def __init__(self, x=0.0, y=0.0, vx=0.0, vy=0.0):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
    def overlaps(self, x, y, w, h):
        return self.x < x + w and self.x + BALL > x and self.y < y + h and self.y + BALL > y
    def aim(self, speed, angle):
        rad = math.radians(angle)
        self.vx = speed * math.sin(rad)
        self.vy = -speed * math.cos(rad)
class Item:
    __slots__ = ("kind", "x", "y")
    def __init__(self, kind, x, y):
        self.kind, self.x, self.y = kind, x, y
class Field:
    def __init__(self, rows, stage=0, items=None):
        if len(rows) > ROWS or any(len(row) != COLS for row in rows):
            raise ValueError("ブロックの並びは、横 %d、縦 %d までです" % (COLS, ROWS))
        self.base_speed = min(SPEED_MAX, BALL_SPEED + SPEED_PER_STAGE * stage)
        self.bricks = {}
        for r, row in enumerate(rows):
            for c, kind in enumerate(row):
                if kind != EMPTY:
                    self.bricks[(c, r)] = [kind, 2 if kind == HARD else 1]
        self.drops = {}
        if items:
            if len(items) != len(rows) or any(len(row) != COLS for row in items):
                raise ValueError("アイテムの並びは、ブロックの並びと同じ形にします")
            for r, row in enumerate(items):
                for c, kind in enumerate(row):
                    if kind == EMPTY:
                        continue
                    if kind not in ITEM_KINDS or (c, r) not in self.bricks:
                        raise ValueError("アイテムの並びが違います: %r（列 %d、行 %d）" % (kind, c, r))
                    self.drops[(c, r)] = kind
        self.paddle_w = PADDLE_W
        self.paddle_x = (WIDTH - PADDLE_W) / 2
        self.paddle_dir = 0
        self.gained = 0
        self.reset_ball()
    def reset_ball(self):
        self.launched = False
        self.speed = self.base_speed
        self.paddle_hits = 0
        self.items = []
        self._set_paddle_w(PADDLE_W)
        self.balls = [Ball()]
        self._ride()
    def _set_paddle_w(self, width):
        center = self.paddle_x + self.paddle_w / 2
        self.paddle_w = width
        self.paddle_x = max(0.0, min(float(WIDTH - width), center - width / 2))
    def _ride(self):
        ball = self.balls[0]
        ball.x = self.paddle_x + (self.paddle_w - BALL) / 2
        ball.y = float(PADDLE_Y - BALL)
    def step(self, move=0, launch=False):
        events = []
        self.gained = 0
        before = self.paddle_x
        self.paddle_x = max(0.0, min(float(WIDTH - self.paddle_w), self.paddle_x + move * PADDLE_SPEED))
        self.paddle_dir = (self.paddle_x > before) - (self.paddle_x < before)
        if not self.launched:
            self._ride()
            if launch:
                self.launched = True
                self.balls[0].aim(self.speed, self.paddle_dir * LAUNCH_ANGLE)
                events.append("launch")
            return events
        for ball in self.balls:
            self._move_ball(ball, events)
            if not self.bricks:
                self.items = []
                events.append("clear")
                return events
        self.balls = [ball for ball in self.balls if ball.y <= HEIGHT]
        if not self.balls:
            self.reset_ball()
            events.append("miss")
            return events
        self._move_items(events)
        return events
    def _move_ball(self, ball, events):
        ball.x += ball.vx
        ball.y += ball.vy
        if ball.x < 0:
            ball.x, ball.vx = 0.0, abs(ball.vx)
            events.append("wall")
        elif ball.x > WIDTH - BALL:
            ball.x, ball.vx = float(WIDTH - BALL), -abs(ball.vx)
            events.append("wall")
        if ball.y < TOP:
            ball.y, ball.vy = float(TOP), abs(ball.vy)
            events.append("wall")
        if ball.vy > 0 and ball.overlaps(self.paddle_x, PADDLE_Y, self.paddle_w, PADDLE_H):
            self._hit_paddle(ball)
            events.append("paddle")
        else:
            self._hit_brick(ball, events)
    def _hit_paddle(self, ball):
        self.paddle_hits += 1
        if self.paddle_hits % HITS_PER_SPEEDUP == 0:
            self.speed = min(SPEED_MAX, self.speed + SPEED_PER_HITS)
        half = self.paddle_w / 2
        offset = (ball.x + BALL / 2 - (self.paddle_x + half)) / half
        angle = max(-1.0, min(1.0, offset)) * EDGE_ANGLE + self.paddle_dir * MOVE_ANGLE
        if self.paddle_dir:
            angle = self.paddle_dir * max(MOVE_ANGLE, self.paddle_dir * angle)
        ball.y = float(PADDLE_Y - BALL)
        ball.aim(self.speed, max(-MAX_ANGLE, min(MAX_ANGLE, angle)))
    def _hit_brick(self, ball, events):
        best, best_area = None, 0.0
        for key in self.bricks:
            bx, by, bw, bh = brick_rect(*key)
            if ball.overlaps(bx, by, bw, bh):
                ox = min(ball.x + BALL, bx + bw) - max(ball.x, bx)
                oy = min(ball.y + BALL, by + bh) - max(ball.y, by)
                if ox * oy > best_area:
                    best, best_area = key, ox * oy
        if not best:
            return
        key = best
        bx, by, bw, bh = brick_rect(*key)
        px = ball.x + BALL - bx if ball.vx > 0 else bx + bw - ball.x
        py = ball.y + BALL - by if ball.vy > 0 else by + bh - ball.y
        tx = px / abs(ball.vx) if ball.vx else math.inf
        ty = py / abs(ball.vy) if ball.vy else math.inf
        if tx < ty:
            ball.x = bx - BALL if ball.vx > 0 else bx + bw
            ball.vx = -ball.vx
        else:
            ball.y = by - BALL if ball.vy > 0 else by + bh
            ball.vy = -ball.vy
        brick = self.bricks[key]
        brick[1] -= 1
        if brick[1] > 0:
            events.append("hard")
            return
        del self.bricks[key]
        self.gained += POINTS_HARD if brick[0] == HARD else POINTS
        events.append("brick")
        kind = self.drops.pop(key, None)
        if kind:
            self.items.append(Item(kind, bx + (bw - ITEM_W) / 2, float(by)))
    def _move_items(self, events):
        falling = []
        for item in self.items:
            item.y += ITEM_SPEED
            if (item.x < self.paddle_x + self.paddle_w and item.x + ITEM_W > self.paddle_x
                    and item.y < PADDLE_Y + PADDLE_H and item.y + ITEM_H > PADDLE_Y):
                self.gained += ITEM_POINTS
                self._take(item.kind)
                events.append("item:" + item.kind)
            elif item.y <= HEIGHT:
                falling.append(item)
        self.items = falling
    def _take(self, kind):
        if kind == LONG:
            self._set_paddle_w(PADDLE_W_LONG)
        elif kind == MULTI:
            self._split()
        elif kind == SLOW:
            self.paddle_hits = 0
            for ball in self.balls:
                scale = self.base_speed / math.hypot(ball.vx, ball.vy)
                ball.vx, ball.vy = ball.vx * scale, ball.vy * scale
            self.speed = self.base_speed
    def _split(self):
        src = self.balls[0]
        speed = math.hypot(src.vx, src.vy)
        heading = math.degrees(math.atan2(src.vx, -src.vy))
        for turn in (-SPLIT_ANGLE, SPLIT_ANGLE):
            if len(self.balls) >= BALLS_MAX:
                break
            angle = heading + turn
            angle = (angle + 180) % 360 - 180
            if abs(angle) <= 90:
                angle = max(-MAX_ANGLE, min(MAX_ANGLE, angle))
            else:
                limit = 180 - MAX_ANGLE
                angle = math.copysign(max(limit, abs(angle)), angle)
            ball = Ball(src.x, src.y)
            ball.aim(speed, angle)
            self.balls.append(ball)
