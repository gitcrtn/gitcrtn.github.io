import sys
import field as fld
from field import Field
from rgbkit import HEIGHT, WIDTH, Game, parse_command
from stages import STAGES
LIVES = 3
LIVES_MAX = 5
CLEAR_BONUS = 100
CLEAR_SECONDS = 1.5
RESULT_LOCK = 1.0
WHITE = (240, 240, 240)
GRAY = (150, 150, 160)
ACCENT = (110, 200, 255)
WALL = (70, 80, 110)
PADDLE = (200, 220, 255)
BRICK_COLORS = {"r": (235, 90, 90), "o": (245, 150, 70), "y": (240, 210, 80),
                "g": (110, 200, 120), "c": (100, 200, 230), "b": (90, 130, 235)}
HARD_COLORS = {2: (205, 210, 220), 1: (125, 130, 140)}
ITEM_COLORS = {fld.LONG: (120, 220, 140), fld.MULTI: (255, 150, 220),
               fld.SLOW: (120, 200, 255), fld.LIFE: (255, 220, 90)}
ITEM_BACK = (14, 18, 40)
COMMAND_WORDS = ("serve", "play", "hit", "lastbrick", "lastlife", "gameover")
SOUNDS = ("launch", "paddle", "wall", "brick", "hard", "miss", "clear", "over", "item")
class Breakout(Game):
    title = "ブロック崩し"
    background = (14, 18, 40)
    step_seconds = 1 / 60
    uses_3d = False
    web_keyboard = {}
    web_touch_layout = {}
    web_sound_band = (300, 6000)
    def start(self):
        data = self.load_json("save.json", {})
        try:
            self.high = max(0, int(data["high"]))
        except (KeyError, TypeError, ValueError):
            self.high = 0
        for name in SOUNDS:
            self.sound.load("sounds/%s.wav" % name)
        self.set_scene("title")
        self.stage = 0
        self.score = 0
        self.lives = LIVES
        self.field = None
        self.first_stage = 0
        self.first_lives = LIVES
        self.record = True
    def controls(self):
        return {"dpad", "a", "b", "start"}
    def set_scene(self, scene):
        self.enter(scene)
        self.scene_seconds = 0.0
    def new_game(self):
        self.score = 0
        self.lives = self.first_lives
        self.start_stage(self.first_stage)
    def start_stage(self, stage):
        self.stage = stage
        rows, items = STAGES[stage]
        self.field = Field(rows, stage, items)
        self.set_scene("game")
    def end_game(self, scene):
        self.settle()
        self.set_scene(scene)
    def settle(self):
        if not self.record:
            return
        if self.score > self.high:
            self.high = self.score
        self.save_json("save.json", {"high": self.high})
    def to_title(self):
        self.settle()
        self.set_scene("title")
    def update(self, dt):
        inp = self.input
        self.scene_seconds += dt
        if self.scene == "title":
            if inp.tapped("a"):
                self.new_game()
        elif self.scene == "stageclear":
            if self.scene_seconds >= CLEAR_SECONDS:
                self.lives = min(LIVES_MAX, self.lives + 1)
                self.start_stage(self.stage + 1)
        elif self.scene in ("gameover", "allclear"):
            if inp.tapped("a") and self.scene_seconds >= RESULT_LOCK:
                self.set_scene("title")
    def step(self):
        if self.scene != "game":
            return
        inp = self.input
        allowed = inp.only("left", "right", "a")
        move = inp.direction()[0] if allowed else 0
        launch = not self.field.launched and allowed and inp.pressed("a")
        events = self.field.step(move, launch)
        self.score += self.field.gained
        for event in events:
            if event == "miss":
                self.lives -= 1
                if self.lives <= 0:
                    self.sound.play("sounds/over.wav")
                    self.end_game("gameover")
                else:
                    self.sound.play("sounds/miss.wav")
            elif event == "clear":
                self.score += CLEAR_BONUS
                self.sound.play("sounds/clear.wav")
                if self.stage + 1 < len(STAGES):
                    self.set_scene("stageclear")
                else:
                    self.end_game("allclear")
            elif event.startswith("item:"):
                if event == "item:" + fld.LIFE:
                    self.lives = min(LIVES_MAX, self.lives + 1)
                self.sound.play("sounds/item.wav")
            else:
                self.sound.play("sounds/%s.wav" % event, volume=0.5 if event == "wall" else 1.0)
    def menu_items(self):
        if self.scene == "title":
            return []
        return [("タイトルへ戻る", self.ask_title)]
    def ask_title(self):
        self.confirm("タイトルへ戻りますか？", self.to_title, lines=["いまのゲームは、失われます"])
    def draw(self, gfx):
        if self.scene == "title":
            gfx.text(WIDTH // 2, 190, "ブロック崩し", 84, WHITE, align="center")
            for i, color in enumerate(BRICK_COLORS.values()):
                gfx.rect(WIDTH // 2 - 213 + i * 72, 320, 66, 24, color)
            gfx.text(WIDTH // 2, 400, "HIGH SCORE  %06d" % self.high, 32, ACCENT, align="center")
            gfx.text(WIDTH // 2, 520, "A: スタート", 36, WHITE, align="center")
            gfx.text(WIDTH // 2, 630, "START: メニュー", 20, GRAY, align="center")
            if not self.record:
                gfx.text(WIDTH // 2, 572, "隠しコマンド（ハイスコアは記録しない）", 16, GRAY, align="center")
                gfx.text(WIDTH // 2, 594, self.command, 16, GRAY, align="center")
            return
        self.draw_field(gfx)
        if self.scene == "game" and not self.field.launched:
            gfx.text(WIDTH // 2, 440, "A: 発射", 32, WHITE, align="center")
        elif self.scene == "stageclear":
            gfx.text(WIDTH // 2, 400, "STAGE CLEAR", 64, WHITE, align="center")
        elif self.scene in ("gameover", "allclear"):
            gfx.rect(0, fld.TOP, WIDTH, HEIGHT - fld.TOP, (0, 0, 0, 150))
            gfx.text(WIDTH // 2, 220, "GAME OVER" if self.scene == "gameover" else "ALL CLEAR", 72,
                     WHITE, align="center")
            gfx.text(WIDTH // 2, 350, "SCORE  %06d" % self.score, 40, WHITE, align="center")
            gfx.text(WIDTH // 2, 410, "HIGH SCORE  %06d" % self.high, 32, ACCENT, align="center")
            if self.scene_seconds >= RESULT_LOCK:
                gfx.text(WIDTH // 2, 540, "A: タイトルへ", 32, WHITE, align="center")
    def draw_field(self, gfx):
        f = self.field
        gfx.text(20, 12, "SCORE %06d" % self.score, 26, WHITE)
        gfx.text(WIDTH // 2, 12, "STAGE %d" % (self.stage + 1), 26, GRAY, align="center")
        for i in range(self.lives):
            gfx.rect(WIDTH - 36 - i * 24, 20, 14, 14, WHITE)
        gfx.rect(0, fld.TOP - 4, WIDTH, 4, WALL)
        for key, (kind, hits) in f.bricks.items():
            x, y, w, h = fld.brick_rect(*key)
            gfx.rect(x, y, w, h, HARD_COLORS[hits] if kind == fld.HARD else BRICK_COLORS[kind])
            gfx.rect(x, y + h - 4, w, 4, (0, 0, 0, 60))
            if key in f.drops:
                gfx.rect(x + w // 2 - 5, y + 5, 10, 10, WHITE)
        for item in f.items:
            gfx.rect(item.x, item.y, fld.ITEM_W, fld.ITEM_H, ITEM_COLORS[item.kind])
            gfx.text(item.x + fld.ITEM_W // 2, item.y + fld.ITEM_H // 2, item.kind, 20, ITEM_BACK,
                     align="center", valign="middle")
        gfx.rect(f.paddle_x, fld.PADDLE_Y, f.paddle_w, fld.PADDLE_H, PADDLE)
        if self.scene == "game":
            for ball in f.balls:
                gfx.rect(ball.x, ball.y, fld.BALL, fld.BALL, WHITE)
    def save(self):
        self.settle()
        self.log("saved: high=%d" % self.high if self.record else "not saved (hidden command)")
    def scene_name(self):
        if self.scene == "game":
            return "play" if self.field.launched else "serve"
        return self.scene
    def debug_state(self):
        state = {"scene": self.scene_name(), "stage": self.stage + 1, "score": self.score,
                 "lives": self.lives, "high": self.high}
        if self.field:
            f = self.field
            ball = f.balls[0]
            state.update({"paddle_x": round(f.paddle_x), "paddle_w": f.paddle_w, "launched": f.launched,
                          "bricks": len(f.bricks), "balls": len(f.balls), "items": len(f.items),
                          "speed": f.speed,
                          "ball": [round(ball.x, 2), round(ball.y, 2), round(ball.vx, 2), round(ball.vy, 2)]})
        return state
    def hidden_command(self, text):
        values = parse_command(text)
        item = None
        words = []
        unknown = []
        for name, value in values.items():
            if name == "stage" and value.isdigit() and 1 <= int(value) <= len(STAGES):
                self.first_stage = int(value) - 1
            elif name == "lives" and value.isdigit() and 1 <= int(value) <= LIVES_MAX:
                self.first_lives = int(value)
            elif name == "item" and value in fld.ITEM_KINDS:
                item = value
            elif name in COMMAND_WORDS and not value:
                words.append(name)
            else:
                unknown.append(name + ("=" + value if value else ""))
        if unknown:
            self.log("command: unknown %s" % " ".join(unknown))
        if len(unknown) == len(values):
            return
        self.record = False
        self.new_game()
        f = self.field
        if item:
            f.items = [fld.Item(item, (WIDTH - fld.ITEM_W) / 2, 560.0)]
        if "gameover" in words:
            self.lives = 0
            self.end_game("gameover")
            return
        if not set(words) & {"play", "hit", "lastbrick", "lastlife"}:
            return
        f.step(0, True)
        ball = f.balls[0]
        if "hit" in words:
            ball.y, ball.vy = 400.0, f.speed
        if "lastbrick" in words:
            key = (5, 4)
            f.bricks = {key: ["c", 1]}
            f.drops = {}
            bx, by, bw, bh = fld.brick_rect(*key)
            ball.x, ball.y = bx + (bw - fld.BALL) / 2, by + bh + 60.0
        if "lastlife" in words:
            self.lives = 1
            ball.x, ball.y, ball.vy = 100.0, 690.0, f.speed
if __name__ == "__main__":
    sys.exit(Breakout().run())
