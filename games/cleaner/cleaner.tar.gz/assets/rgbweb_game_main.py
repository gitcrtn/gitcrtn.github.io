import math
import random
import sys
from array import array
from rgbkit import Game, Progress, anim, format_time, g3d, g3dbody, g3dfx, g3dtop, gfxfx
import rooms
import vacuum
SPEED = 2.5
TURN = 540.0
DIRECTIONS = ("up", "down", "left", "right")
CAMERA_HEIGHT = 4.6
CAMERA_BACK = 3.4
CAMERA_AHEAD = 0.6
CAMERA_NEAR = 2.3
CAMERA_FAR = 2.0
CAMERA_FOLLOW = 6.0
CAMERA_FOV = 60
DULL_FLOOR = (140, 118, 95)
CLEAN_FLOOR = (225, 182, 128)
FLOOR_COLOR = anim.Curve([(0.0, DULL_FLOOR), (1.0, CLEAN_FLOOR)])
GAUGE = (120, 220, 255)
GAUGE_BACK = (30, 40, 60)
DEBRIS = [((125, 125, 132), (0.10, 0.03, 0.10), (0, 0, 0)),
          ((150, 95, 50), (0.06, 0.05, 0.06), (0, 0, 0)),
          ((245, 245, 240), (0.14, 0.025, 0.10), (6, 25, 0))]
SUCK_TIME = 0.15
SUCK_SIZE = anim.Curve([(0.0, 1.0), (1.0, 0.2)])
CELL = 1.0
SUCK_SOUND = "sounds/suck.wav"
PICK_SOUND = "sounds/pick.wav"
BUMP_SOUND = "sounds/bump.wav"
CLEAR_SOUND = "sounds/clear.wav"
CURSOR_SOUND = "sounds/cursor.wav"
DENY_SOUND = "sounds/deny.wav"
MARK_LEFT = 5
MARK = (255, 230, 80)
SPARKLE_SIZE = anim.Curve([(0.0, 0.0), (0.3, 0.09), (1.0, 0.0)])
SPARKLE_COLOR = anim.Curve([(0.0, (255, 255, 255)), (1.0, (255, 235, 140))])
CLEAR_WAIT = 1.5
TITLE_TEXT = (255, 250, 210)
LOCKED = (120, 120, 130)
ROW_BAND = (60, 140, 200, 200)
LIST_BACK = (0, 0, 0, 120)
ORBIT_SWING = 25.0
ORBIT_SPEED = 0.3
NO_TIME = "--:--.-"
BACKGROUND = (60, 50, 45)
WHITE = (255, 255, 255)
SHADE = (20, 20, 30)
PLANKS = ["aaaaaaaaaaaaaaaa",
          "aaaaaaaaaaaaaaaa",
          "aaaaaaaaaaaaaaaa",
          "bbbbbbbbbbbbbbbb",
          "aaaaaaaaaaaaaaaa",
          "aaaaabaaaaaaaaaa",
          "aaaaabaaaaaaaaaa",
          "bbbbbbbbbbbbbbbb",
          "aaaaaaaaaaaaaaaa",
          "aaaaaaaaaaaaabaa",
          "aaaaaaaaaaaaabaa",
          "bbbbbbbbbbbbbbbb",
          "aaaaaaaaaaaaaaaa",
          "aabaaaaaaaaaaaaa",
          "aabaaaaaaaaaaaaa",
          "bbbbbbbbbbbbbbbb"]
class Cleaner(Game):
    title = "ピカピカおそうじ"
    background = BACKGROUND
    step_seconds = 1 / 60
    view_size = 320
    save_with_command = False
    uses_3d = True
    web_keyboard = {}
    web_touch_layout = {}
    web_sound_band = (300, 6000)
    def controls(self):
        return {"dpad", "left_stick", "a", "b", "start"}
    def start(self):
        self.input.left_stick_counts = False
        view = self.view = g3d.View(self, size=self.view_size)
        view.background(BACKGROUND)
        view.light((0.4, -1.0, 0.6), ambient=0.55)
        planks = view.texture_rows(PLANKS, {"a": (255, 255, 255), "b": (200, 200, 200)})
        self.vacuum = view.mesh(vacuum.shape())
        self.debris_meshes = [view.mesh(g3d.box(), color=color) for color, _, _ in DEBRIS]
        self.mark = view.mesh(g3d.box(0.2, 0.2, 0.2), color=MARK, lit=False)
        self.sparkles = g3dfx.Puffs(view, life=0.9, limit=60, rise=0.7, size=SPARKLE_SIZE, color=SPARKLE_COLOR, lit=False)
        self.sparkle_rng = random.Random(5)
        for path in (SUCK_SOUND, PICK_SOUND, BUMP_SOUND, CLEAR_SOUND, CURSOR_SOUND, DENY_SOUND):
            self.sound.load(path)
        self.assets = [self.room_assets(room, planks) for room in rooms.ROOMS]
        self.progress = Progress(self, stages=len(rooms.ROOMS), low=0.0)
        self.keep = None
        self.new_best = False
        self.go_title()
    def hidden_command(self, text):
        values = self.command_values()
        if values.flag("unlock"):
            self.progress.unlocked = len(rooms.ROOMS)
        self.keep = values.int("left", 0, None)
        room = values.int("room", 1, len(rooms.ROOMS))
        if room is not None:
            self.load_room(room - 1)
            self.restart()
        else:
            self.go_title()
    def room_assets(self, room, planks):
        view = self.view
        rug = None
        if room.rug:
            _, (w, d), color = room.rug
            rug = view.mesh(g3d.plane(w, d), color=color)
        floor = view.mesh(g3d.plane(room.w, room.d, cells=int(max(room.w, room.d))), texture=planks)
        return {"room": view.mesh(room.shape()), "floor": floor, "rug": rug, "layout": room.make_debris()}
    def load_room(self, index):
        self.room_index = index
        self.room = rooms.ROOMS[index]
        assets = self.assets[index]
        self.room_mesh, self.floor, self.rug_mesh, self.layout = assets["room"], assets["floor"], assets["rug"], assets["layout"]
        self.setup()
    def restart(self):
        self.setup()
        self.enter("play")
    def setup(self):
        x, z = self.room.start
        self.body = g3dbody.Body(pos=(x, 0.0, z), width=vacuum.WIDTH, height=0.4)
        self.heading = 0.0
        self.moving = False
        self.hits = 0
        self.touching = False
        self.cam_x, self.cam_z = self.camera_target()
        self.time = 0.0
        self.pieces = list(self.layout)
        if self.keep is not None:
            self.pieces = self.pieces[:self.keep]
        self.total = len(self.layout)
        self.alive = [True] * len(self.pieces)
        self.left = len(self.pieces)
        self.cells = {}
        for i, (x, z, _) in enumerate(self.pieces):
            self.cells.setdefault(self.cell(x, z), []).append(i)
        self.flying = []
        self.dirty = True
        self.sparkles.clear()
        self.new_best = False
    def cell(self, x, z):
        return (math.floor(x / CELL), math.floor(z / CELL))
    @property
    def clean(self):
        return 1.0 - self.left / self.total if self.total else 1.0
    def move_input(self):
        inp = self.input
        sx, sy = inp.stick("left")
        if (sx, sy) != (0.0, 0.0) and inp.none_but(*DIRECTIONS):
            return sx, -sy
        if inp.only(*DIRECTIONS):
            dx, dy = inp.direction()
            length = math.hypot(dx, dy)
            if length:
                return dx / length, -dy / length
        return 0.0, 0.0
    def step_play(self):
        dt = self.step_seconds
        mx, mz = self.move_input()
        self.moving = (mx, mz) != (0.0, 0.0)
        if self.moving:
            target = math.degrees(math.atan2(mx, mz)) % 360.0
            self.heading = anim.approach_angle(self.heading, target, TURN * dt)
        events = self.body.update(dt, self.room.boxes, mx * SPEED * dt, mz * SPEED * dt)
        touching = any(event.kind == "hit" for event in events)
        if touching and not self.touching:
            self.hits += 1
            self.sound.play(BUMP_SOUND, volume=0.6, every=0.4)
        self.touching = touching
        self.time += dt
        self.suck()
        self.fly(dt)
        tx, tz = self.camera_target()
        self.cam_x = anim.follow(self.cam_x, tx, CAMERA_FOLLOW, dt)
        self.cam_z = anim.follow(self.cam_z, tz, CAMERA_FOLLOW, dt)
    def suck(self):
        x, z, heading = self.body.x, self.body.z, self.heading
        cx, cz = g3dtop.world(x, z, heading, vacuum.MOUTH_FRONT / 2, 0.0)
        reach = math.hypot(vacuum.MOUTH_FRONT / 2, vacuum.MOUTH_HALF)
        x0, z0 = self.cell(cx - reach, cz - reach)
        x1, z1 = self.cell(cx + reach, cz + reach)
        for ix in range(x0, x1 + 1):
            for iz in range(z0, z1 + 1):
                for i in self.cells.get((ix, iz), ()):
                    if self.alive[i]:
                        px, pz, kind = self.pieces[i]
                        if vacuum.in_mouth(x, z, heading, px, pz):
                            self.alive[i] = False
                            self.dirty = True
                            self.flying.append([px, pz, kind, 0.0])
    def fly(self, dt):
        if not self.flying:
            return
        for piece in self.flying:
            piece[3] += dt / SUCK_TIME
        done = [piece for piece in self.flying if piece[3] >= 1.0]
        if done:
            self.flying = [piece for piece in self.flying if piece[3] < 1.0]
            self.left -= len(done)
            self.sound.play(PICK_SOUND, volume=0.5, every=0.05)
            if self.left == 0 and not self.flying:
                self.cleared()
    def cleared(self):
        self.log("debris: all picked time=%s" % format_time(self.time))
        progress = self.progress
        self.new_best = progress.record(self.room_index, self.time)
        progress.unlock(self.room_index + 2)
        progress.save()
        self.sound.stop_held()
        self.sound.play(CLEAR_SOUND, volume=0.7)
        self.moving = False
        self.enter("clear")
    def update_play(self, dt):
        self.sound.hold(SUCK_SOUND, True, volume=0.45 if self.moving else 0.3)
    def go_title(self):
        self.sound.stop_held()
        self.load_room(self.progress.selected)
        self.enter("title")
    def update_title(self, dt):
        inp = self.input
        last = len(rooms.ROOMS) - 1
        row = max(0, min(last, self.room_index + inp.cursor("up", "down")))
        if row != self.room_index:
            self.sound.play(CURSOR_SOUND, volume=0.5)
            self.load_room(row)
        if inp.tapped("a", since=self.entered):
            if self.room_index < self.progress.unlocked:
                self.progress.selected = self.room_index
                self.progress.save()
                self.restart()
            else:
                self.sound.play(DENY_SOUND, volume=0.6)
    def draw_title(self, gfx):
        room = self.room
        swing = ORBIT_SWING * math.sin(self.scene_time * ORBIT_SPEED)
        self.view.orbit((0.0, 0.0, 0.0), max(room.w, room.d) * 0.85, 5.0, 180.0 + swing)
        self.draw_world()
        gfx.text(360, 110, "ピカピカおそうじ", 80, TITLE_TEXT, align="center", valign="middle", shadow=SHADE)
        gfx.rect(110, 330, 500, 210, LIST_BACK)
        for i, each in enumerate(rooms.ROOMS):
            y = 345 + i * 64
            if i == self.room_index:
                gfx.rect(120, y - 4, 480, 54, ROW_BAND)
            if i < self.progress.unlocked:
                best = self.progress.best[i]
                gfx.text(150, y, each.name, 36, WHITE, shadow=SHADE)
                gfx.text(570, y, format_time(best) if best is not None else NO_TIME, 36, WHITE, align="right", shadow=SHADE)
            else:
                gfx.text(150, y, "？？？", 36, LOCKED)
        gfx.text(360, 595, "A: はじめる", 24, WHITE, align="center", shadow=SHADE)
    def update_clear(self, dt):
        if self.input.tapped("a", since=self.entered, wait=CLEAR_WAIT):
            self.sparkles.clear()
            self.go_title()
            return
        self.sparkles.step(dt)
        for _ in range(2):
            x = self.cam_x + self.sparkle_rng.uniform(-3.0, 3.0)
            z = self.cam_z + self.sparkle_rng.uniform(-2.0, 2.5)
            hw, hd = self.room.w / 2 - 0.1, self.room.d / 2 - 0.1
            if -hw < x < hw and -hd < z < hd:
                self.sparkles.emit((x, 0.05, z), size=1.0)
    def draw_clear(self, gfx):
        self.play_camera()
        self.draw_world()
        gfx.text(360, 230, "ピカピカ！", 96, TITLE_TEXT, align="center", valign="middle", shadow=SHADE)
        gfx.text(360, 340, format_time(self.time), 56, WHITE, align="center", valign="middle", shadow=SHADE)
        if self.new_best:
            gfx.text(360, 420, "ベスト更新！", 36, TITLE_TEXT, align="center", valign="middle", shadow=SHADE)
        if self.scene_time >= CLEAR_WAIT:
            gfx.text(360, 650, "A: もどる", 24, WHITE, align="center", shadow=SHADE)
    def camera_target(self):
        limit_x = max(0.0, self.room.w / 2 - 2.0)
        near, far = -self.room.d / 2 + CAMERA_NEAR, self.room.d / 2 - CAMERA_FAR
        return (max(-limit_x, min(limit_x, self.body.x)), max(near, min(max(near, far), self.body.z)))
    def play_camera(self):
        cx, cz = self.cam_x, self.cam_z
        self.view.camera(eye=(cx, CAMERA_HEIGHT, cz - CAMERA_BACK), look_at=(cx, 0.0, cz + CAMERA_AHEAD), fov=CAMERA_FOV)
    def draw_play(self, gfx):
        self.play_camera()
        self.draw_world()
        gfx.text(20, 16, self.room.name, 28, WHITE, shadow=SHADE)
        gfx.text(20, 50, format_time(self.time), 40, WHITE, shadow=SHADE)
        gfx.text(700, 16, "きれい度 %d%%" % int(self.clean * 100), 40, WHITE, align="right", shadow=SHADE)
        gfxfx.bar(gfx, 480, 66, 220, 14, self.clean, GAUGE, back=GAUGE_BACK, edge=SHADE)
    def draw_world(self):
        view = self.view
        view.draw(self.floor, color=tuple(round(c) for c in FLOOR_COLOR.at(self.clean)))
        if self.rug_mesh is not None:
            (rx, rz), _, _ = self.room.rug
            view.draw(self.rug_mesh, pos=(rx, 0.005, rz))
        view.draw(self.room_mesh)
        self.draw_debris(view)
        view.shadow((self.body.x, 0.0, self.body.z), radius=0.4, strength=0.45)
        view.draw(self.vacuum, pos=(self.body.x, 0.0, self.body.z), rot=(0, self.heading, 0))
        if self.scene == "play" and 0 < self.left <= MARK_LEFT:
            self.draw_marks(view)
        self.sparkles.draw()
        view.show()
    def draw_marks(self, view):
        bob = 0.08 * math.sin(self.scene_time * 5.0)
        for i, (x, z, _) in enumerate(self.pieces):
            if self.alive[i]:
                view.draw(self.mark, pos=(x, 0.55 + bob, z), rot=(45, self.scene_time * 120.0 % 360.0, 45))
    def draw_debris(self, view):
        if self.dirty:
            self.arrays = [array("f") for _ in DEBRIS]
            for i, (x, z, kind) in enumerate(self.pieces):
                if self.alive[i]:
                    self.arrays[kind].extend((x, DEBRIS[kind][1][1] / 2, z))
            self.dirty = False
        for kind, (_, size, rot) in enumerate(DEBRIS):
            if self.arrays[kind]:
                view.draw_many(self.debris_meshes[kind], self.arrays[kind], rot=rot, scale=size)
        if self.flying:
            tx, tz = g3dtop.world(self.body.x, self.body.z, self.heading, vacuum.INTAKE, 0.0)
            for px, pz, kind, t in self.flying:
                _, (sx, sy, sz), rot = DEBRIS[kind]
                k = SUCK_SIZE.at(t)
                view.draw(self.debris_meshes[kind], pos=(px + (tx - px) * t, sy / 2 + 0.06 * t, pz + (tz - pz) * t),
                          rot=rot, scale=(sx * k, sy * k, sz * k))
    def menu_items(self):
        if self.scene == "play":
            return [("やり直す", self.ask_restart), ("部屋を選ぶ", self.ask_title)]
        return []
    def ask_restart(self):
        self.confirm("やり直しますか？", self.restart, lines=["部屋の最初から、はじめます"])
    def ask_title(self):
        self.confirm("部屋を選びますか？", self.go_title, lines=["いまの掃除は、おしまいになります"])
    def save(self):
        self.progress.save()
    def debug_state(self):
        return {"scene": self.scene, "room": self.room_index + 1, "x": round(self.body.x, 2),
                "z": round(self.body.z, 2), "heading": round(self.heading, 1), "moving": self.moving, "hit": self.hits,
                "left": self.left, "total": self.total, "clean": round(self.clean * 100, 1), "time": round(self.time, 2),
                "sfx": self.sound.history[-4:], "held": self.sound.held(), "flying": len(self.flying),
                "marks": sum(self.alive) if self.scene == "play" and 0 < self.left <= MARK_LEFT else 0,
                "unlocked": self.progress.unlocked, "selected": self.progress.selected, "new_best": self.new_best,
                "best": [None if b is None else round(b, 2) for b in self.progress.best]}
if __name__ == "__main__":
    sys.exit(Cleaner().run())
