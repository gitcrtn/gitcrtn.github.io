import math
import random
from rgbkit import g3d, g3dbody
import vacuum
DUST, CRUMB, PAPER = 0, 1, 2
KINDS = {"d": DUST, "c": CRUMB, "p": PAPER}
EDGE_GAP = 0.04
START_CLEAR = 0.8
WALL_THICK = 0.2
WALL_HEIGHT = 2.0
WALL = (236, 226, 208)
SOFA = (96, 140, 190)
CUSHION = (130, 170, 215)
WOOD = (150, 105, 70)
DARK_WOOD = (110, 75, 50)
TV = (40, 42, 50)
RUG = (200, 120, 110)
POT = (190, 110, 70)
LEAF = (80, 160, 90)
SHEET = (240, 240, 250)
BLANKET = (240, 170, 80)
PILLOW = (250, 250, 255)
TOY_BOX = (230, 90, 90)
TOYS = [(80, 160, 230), (250, 210, 60), (110, 200, 110)]
BOOKS = [(200, 70, 70), (70, 120, 200), (230, 190, 60), (90, 170, 100)]
COUNTER = (220, 222, 228)
COUNTER_TOP = (120, 125, 135)
SINK = (170, 180, 195)
FRIDGE = (235, 240, 245)
HANDLE = (150, 155, 165)
CHAIR = (175, 125, 80)
def _sofa(shape, x, z):
    shape.add(g3d.box(2.2, 0.4, 0.8), pos=(x, 0.2, z), color=SOFA)
    shape.add(g3d.box(2.2, 0.5, 0.25), pos=(x, 0.65, z + 0.28), color=SOFA)
    shape.add(g3d.box(0.25, 0.25, 0.8), pos=(x - 0.98, 0.52, z), color=SOFA)
    shape.add(g3d.box(0.25, 0.25, 0.8), pos=(x + 0.98, 0.52, z), color=SOFA)
    shape.add(g3d.box(0.8, 0.1, 0.5), pos=(x - 0.45, 0.45, z - 0.05), color=CUSHION)
    shape.add(g3d.box(0.8, 0.1, 0.5), pos=(x + 0.45, 0.45, z - 0.05), color=CUSHION)
def _low_table(shape, x, z, w, d, h):
    shape.add(g3d.box(w, 0.06, d), pos=(x, h - 0.03, z), color=WOOD)
    for sx in (-1, 1):
        for sz in (-1, 1):
            shape.add(g3d.box(0.06, h - 0.06, 0.06), pos=(x + sx * (w / 2 - 0.06), (h - 0.06) / 2, z + sz * (d / 2 - 0.06)),
                      color=DARK_WOOD)
def _tv_stand(shape, x, z):
    shape.add(g3d.box(0.5, 0.45, 1.6), pos=(x, 0.225, z), color=DARK_WOOD)
    shape.add(g3d.box(0.08, 0.6, 1.1), pos=(x - 0.05, 0.8, z), color=TV)
    shape.add(g3d.box(0.12, 0.05, 0.3), pos=(x - 0.05, 0.475, z), color=TV)
def _plant(shape, x, z):
    shape.add(g3d.cylinder(0.22, 0.4, sides=10), pos=(x, 0.0, z), color=POT)
    shape.add(g3d.box(0.45, 0.45, 0.45), pos=(x, 0.65, z), rot=(0, 30, 0), color=LEAF)
    shape.add(g3d.box(0.3, 0.3, 0.3), pos=(x, 0.95, z), rot=(0, 10, 0), color=LEAF)
class Room:
    def __init__(self, name, w, d, furniture, start, build, debris, scatter="dcp", rug=None):
        self.name, self.w, self.d = name, w, d
        self.start, self.rug = start, rug
        self.debris, self.scatter = debris, scatter
        hw, hd, t = w / 2, d / 2, WALL_THICK
        self.walls = [g3dbody.Box(-hw - t, hw + t, 0, 1, hd, hd + t),
                      g3dbody.Box(-hw - t, hw + t, 0, 1, -hd - t, -hd),
                      g3dbody.Box(-hw - t, -hw, 0, 1, -hd, hd),
                      g3dbody.Box(hw, hw + t, 0, 1, -hd, hd)]
        self.furniture = [g3dbody.Box.at((x, h / 2, z), (fw, h, fd)) for x, z, fw, fd, h in furniture]
        self.boxes = self.walls + self.furniture
        self._build = build
    def shape(self):
        hw, hd, t, h = self.w / 2, self.d / 2, WALL_THICK, WALL_HEIGHT
        shape = g3d.Shape([], [])
        shape.add(g3d.box(self.w + 2 * t, h, t), pos=(0, h / 2, hd + t / 2), color=WALL)
        shape.add(g3d.box(t, h, self.d), pos=(-hw - t / 2, h / 2, 0), color=WALL)
        shape.add(g3d.box(t, h, self.d), pos=(hw + t / 2, h / 2, 0), color=WALL)
        self._build(shape)
        return shape
    def free(self, x, z):
        r = vacuum.WIDTH / 2
        return not any(x + r > b.x0 and x - r < b.x1 and z + r > b.z0 and z - r < b.z1 for b in self.boxes)
    def reachable(self, px, pz, free=None):
        free = free or self.free
        for step in range(16):
            heading = step * 22.5
            a = math.radians(heading)
            fx, fz = math.sin(a), math.cos(a)
            rx, rz = fz, -fx
            for front in (0.1, 0.25, 0.4):
                for right in (0.0, -0.25, 0.25):
                    x, z = px - fx * front - rx * right, pz - fz * front - rz * right
                    if free(x, z) and vacuum.in_mouth(x, z, heading, px, pz):
                        return True
        return False
    def placeable(self, px, pz):
        hw, hd, g = self.w / 2 - EDGE_GAP, self.d / 2 - EDGE_GAP, EDGE_GAP
        if not (-hw < px < hw and -hd < pz < hd):
            return False
        if any(b.x0 - g < px < b.x1 + g and b.z0 - g < pz < b.z1 + g for b in self.furniture):
            return False
        sx, sz = self.start
        if math.hypot(px - sx, pz - sz) < START_CLEAR:
            return False
        return self.reachable(px, pz)
    def make_debris(self):
        count, seed, clusters = self.debris
        rng = random.Random(seed)
        pieces = []
        def put(pick, kinds, number):
            for _ in range(number):
                for _ in range(200):
                    x, z = pick()
                    if self.placeable(x, z):
                        pieces.append((x, z, KINDS[rng.choice(kinds)]))
                        break
        for cx, cz, radius, number, kinds in clusters:
            def near(cx=cx, cz=cz, radius=radius):
                a, d = rng.uniform(0, 2 * math.pi), radius * math.sqrt(rng.random())
                return cx + math.cos(a) * d, cz + math.sin(a) * d
            put(near, kinds, number)
        hw, hd = self.w / 2, self.d / 2
        put(lambda: (rng.uniform(-hw, hw), rng.uniform(-hd, hd)), self.scatter, count - len(pieces))
        return pieces
def _bed(shape, x, z, w, d):
    shape.add(g3d.box(w, 0.3, d), pos=(x, 0.15, z), color=WOOD)
    shape.add(g3d.box(w - 0.06, 0.15, d - 0.06), pos=(x, 0.37, z), color=SHEET)
    shape.add(g3d.box(w - 0.02, 0.06, d * 0.62), pos=(x, 0.47, z - d * 0.17), color=BLANKET)
    shape.add(g3d.box(w * 0.6, 0.1, 0.35), pos=(x, 0.5, z + d / 2 - 0.3), color=PILLOW)
    shape.add(g3d.box(w, 0.75, 0.08), pos=(x, 0.375, z + d / 2 - 0.04), color=DARK_WOOD)
def _desk(shape, x, z, w, d, h):
    shape.add(g3d.box(w, 0.05, d), pos=(x, h - 0.025, z), color=WOOD)
    shape.add(g3d.box(w, h - 0.05, 0.05), pos=(x, (h - 0.05) / 2, z + d / 2 - 0.025), color=DARK_WOOD)
    for sz in (-1, 1):
        shape.add(g3d.box(0.05, h - 0.05, 0.05), pos=(x - w / 2 + 0.05, (h - 0.05) / 2, z + sz * (d / 2 - 0.05)),
                  color=DARK_WOOD)
def _toy_box(shape, x, z):
    shape.add(g3d.box(0.8, 0.45, 0.6), pos=(x, 0.225, z), color=TOY_BOX)
    shape.add(g3d.box(0.18, 0.18, 0.18), pos=(x - 0.2, 0.54, z), rot=(0, 20, 0), color=TOYS[0])
    shape.add(g3d.box(0.14, 0.14, 0.14), pos=(x + 0.1, 0.52, z + 0.1), rot=(0, 45, 0), color=TOYS[1])
    shape.add(g3d.cylinder(0.08, 0.12, sides=8), pos=(x + 0.25, 0.45, z - 0.1), color=TOYS[2])
def _bookshelf(shape, x, z, d, h):
    shape.add(g3d.box(0.4, h, d), pos=(x - 0.05, h / 2, z), color=DARK_WOOD)
    for row in range(4):
        y = 0.12 + row * h / 4
        for i, color in enumerate(BOOKS):
            shape.add(g3d.box(0.06, 0.26, d / 5), pos=(x + 0.16, y + 0.13, z - d / 2 + d / 8 + i * d / 4 - 0.02 * row),
                      color=color)
def _chair(shape, x, z, back_z):
    shape.add(g3d.box(0.42, 0.05, 0.42), pos=(x, 0.43, z), color=CHAIR)
    shape.add(g3d.box(0.42, 0.45, 0.05), pos=(x, 0.68, z + back_z * 0.19), color=CHAIR)
    for sx in (-1, 1):
        for sz in (-1, 1):
            shape.add(g3d.box(0.04, 0.42, 0.04), pos=(x + sx * 0.18, 0.21, z + sz * 0.18), color=DARK_WOOD)
def _counter(shape, x, z, w, d):
    shape.add(g3d.box(w, 0.86, d), pos=(x, 0.43, z), color=COUNTER)
    shape.add(g3d.box(w, 0.04, d), pos=(x, 0.88, z), color=COUNTER_TOP)
    shape.add(g3d.box(0.6, 0.02, d * 0.6), pos=(x + w * 0.2, 0.905, z), color=SINK)
def _fridge(shape, x, z):
    shape.add(g3d.box(0.75, 1.8, 0.65), pos=(x, 0.9, z), color=FRIDGE)
    shape.add(g3d.box(0.04, 0.5, 0.04), pos=(x - 0.28, 1.3, z - 0.34), color=HANDLE)
    shape.add(g3d.box(0.04, 0.3, 0.04), pos=(x - 0.28, 0.55, z - 0.34), color=HANDLE)
def _living_build(shape):
    _sofa(shape, 0.0, 2.9)
    _low_table(shape, 0.0, 1.0, 1.2, 0.6, 0.4)
    _tv_stand(shape, -3.25, 0.2)
    _plant(shape, 3.0, 3.0)
_LIVING = Room("リビング", 7.0, 7.0,
               [(0.0, 2.9, 2.2, 0.8, 1.0), (0.0, 1.0, 1.2, 0.6, 0.4), (-3.25, 0.2, 0.5, 1.6, 1.0), (3.0, 3.0, 0.45, 0.45, 1.0)],
               start=(0.0, -2.0), build=_living_build, rug=((0.0, 1.2), (2.6, 1.8), RUG),
               debris=(120, 11, [(0.0, 1.0, 1.1, 22, "ccd"),
                                 (-2.6, 0.2, 0.7, 10, "d"),
                                 (3.1, -3.1, 0.6, 10, "d"),
                                 (-3.1, 3.1, 0.6, 8, "d"),
                                 (2.0, -1.0, 0.8, 10, "pp")]))
def _kids_build(shape):
    _bed(shape, -2.8, 1.9, 1.4, 2.2)
    _desk(shape, 3.1, 1.6, 0.8, 1.4, 0.72)
    _toy_box(shape, 0.6, 2.6)
    _bookshelf(shape, -3.25, -1.6, 1.4, 1.6)
_KIDS = Room("子ども部屋", 7.0, 6.0,
             [(-2.8, 1.9, 1.4, 2.2, 1.0), (3.1, 1.6, 0.8, 1.4, 1.0), (0.6, 2.6, 0.8, 0.6, 1.0), (-3.2, -1.6, 0.6, 1.4, 1.6)],
             start=(0.0, -1.5), build=_kids_build, rug=((0.3, 0.2), (2.4, 2.0), (120, 170, 220)),
             debris=(160, 23, [(2.3, 1.6, 0.9, 22, "ccp"),
                               (-1.7, 1.4, 0.7, 16, "d"),
                               (0.5, 1.7, 0.9, 18, "pp"),
                               (3.1, -2.5, 0.6, 10, "d"),
                               (-2.4, -2.5, 0.7, 10, "d")]))
def _dining_build(shape):
    _low_table(shape, 0.0, 0.5, 1.6, 1.0, 0.72)
    for x in (-0.45, 0.45):
        _chair(shape, x, -0.3, -1)
        _chair(shape, x, 1.3, 1)
    _counter(shape, -1.5, 3.2, 2.6, 0.6)
    _fridge(shape, 3.55, 3.1)
_DINING = Room("ダイニング", 8.0, 7.0,
               [(0.0, 0.5, 1.6, 1.0, 1.0), (-0.45, -0.3, 0.45, 0.45, 1.0), (0.45, -0.3, 0.45, 0.45, 1.0),
                (-0.45, 1.3, 0.45, 0.45, 1.0), (0.45, 1.3, 0.45, 0.45, 1.0), (-1.5, 3.2, 2.6, 0.6, 1.0),
                (3.55, 3.1, 0.75, 0.65, 1.0)],
               start=(0.0, -2.5), build=_dining_build,
               debris=(200, 37, [(0.0, 0.5, 1.6, 60, "ccp"),
                                 (-1.5, 2.4, 0.8, 24, "cp"),
                                 (3.0, 2.2, 0.6, 12, "d"),
                                 (-3.6, -3.1, 0.6, 10, "d"),
                                 (3.6, -3.1, 0.6, 10, "d")]))
ROOMS = [_LIVING, _KIDS, _DINING]
