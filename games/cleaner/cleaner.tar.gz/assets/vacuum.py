from rgbkit import g3d, g3dtop
HEAD = (70, 74, 84)
BRUSH = (40, 40, 46)
STICK = (200, 205, 215)
BODY = (235, 95, 70)
CUP = (170, 210, 235)
GRIP = (50, 52, 60)
WIDTH = 0.5
MOUTH_FRONT = 0.45
MOUTH_HALF = 0.35
INTAKE = 0.18
def shape():
    s = g3d.Shape([], [])
    s.add(g3d.box(0.6, 0.08, 0.22), pos=(0, 0.05, 0.14), color=HEAD)
    s.add(g3d.box(0.56, 0.03, 0.05), pos=(0, 0.015, 0.22), color=BRUSH)
    s.add(g3d.box(0.12, 0.1, 0.1), pos=(0, 0.1, 0.06), color=HEAD)
    s.add(g3d.box(0.05, 0.95, 0.05), pos=(0, 0.55, -0.12), rot=(-22, 0, 0), color=STICK)
    s.add(g3d.box(0.16, 0.3, 0.16), pos=(0, 0.72, -0.2), rot=(-22, 0, 0), color=BODY)
    s.add(g3d.box(0.12, 0.12, 0.12), pos=(0, 0.6, -0.11), rot=(-22, 0, 0), color=CUP)
    s.add(g3d.box(0.07, 0.2, 0.07), pos=(0, 1.0, -0.33), rot=(-22, 0, 0), color=GRIP)
    return s
def in_mouth(x, z, heading, px, pz):
    front, right = g3dtop.local(x, z, heading, px, pz)
    return 0.0 <= front <= MOUTH_FRONT and -MOUTH_HALF <= right <= MOUTH_HALF
