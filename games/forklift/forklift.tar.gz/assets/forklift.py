from rgbkit.g3dtop import inside, local, overlap, world
STEP = 1 / 60
BODY_FRONT = 0.25
BODY_LENGTH = 1.5
BODY_WIDTH = 1.0
FORK_LENGTH = 1.1
FORK_WIDTH = 0.8
CARGO = 1.0
CARGO_HEIGHT = 0.8
FORWARD = 3.0
REVERSE = 2.0
ACCEL = 8.0
TURN = 100.0
LIFT_MAX = 1.6
LIFT_SPEED = 0.8
POCKET = 0.1
ALIGN = 20.0
REACH = 0.8
SIDE = 0.25
CLEAR_HOLD = 0.5
def approach(value, target, amount):
    if value < target:
        return min(target, value + amount)
    return max(target, value - amount)
class Cargo:
    def __init__(self, x, z, angle=0.0):
        self.x, self.z, self.angle = float(x), float(z), float(angle)
    def box(self):
        return (self.x, self.z, CARGO / 2, CARGO / 2, self.angle)
class Forklift:
    def __init__(self, stage):
        self.stage = stage
        w, d = stage["floor"]
        self.bounds = (-w / 2, w / 2, -d / 2, d / 2)
        self.walls = [(x, z, d / 2, w / 2, 0.0) for x, z, w, d in stage.get("walls", ())]
        self.goals = [(x - w / 2, x + w / 2, z - d / 2, z + d / 2) for x, z, w, d in stage["goals"]]
        self.cargo = [Cargo(*c) for c in stage["cargo"]]
        self.x, self.z, self.angle = (float(v) for v in stage["start"])
        self.speed = 0.0
        self.lift = 0.0
        self.carrying = None
        self._grip = None
        self._denied = False
        self.placed = self.count_placed()
        self.full_time = 0.0
        self.cleared = False
    def body_box(self):
        cx, cz = world(self.x, self.z, self.angle, BODY_FRONT - BODY_LENGTH / 2, 0.0)
        return (cx, cz, BODY_LENGTH / 2, BODY_WIDTH / 2, self.angle)
    def fork_box(self):
        cx, cz = world(self.x, self.z, self.angle, BODY_FRONT + FORK_LENGTH / 2, 0.0)
        return (cx, cz, FORK_LENGTH / 2, FORK_WIDTH / 2, self.angle)
    def aligned(self, cargo):
        off = (cargo.angle - self.angle) % 90.0
        return min(off, 90.0 - off) <= ALIGN
    def can_insert(self, cargo):
        return self.carrying is None and self.lift <= POCKET and self.aligned(cargo)
    def under(self):
        fork = self.fork_box()
        return [i for i, c in enumerate(self.cargo) if i != self.carrying and overlap(fork, c.box())]
    def in_reach(self, cargo):
        f, r = local(self.x, self.z, self.angle, cargo.x, cargo.z)
        return f - BODY_FRONT <= REACH and abs(r) <= SIDE
    def target(self):
        best = None
        for i, cargo in enumerate(self.cargo):
            if not self.can_insert(cargo):
                continue
            f, r = local(self.x, self.z, self.angle, cargo.x, cargo.z)
            if abs(r) <= SIDE and 0.0 < f <= BODY_FRONT + 3.0 and (best is None or f < best[0]):
                best = (f, i)
        return best[1] if best else None
    def collides(self):
        parts = [self.body_box(), self.fork_box()]
        held = self.cargo[self.carrying] if self.carrying is not None else None
        if held:
            parts.append(held.box())
        for part in parts:
            if not inside(part, *self.bounds) or any(overlap(part, wall) for wall in self.walls):
                return True
        for cargo in self.cargo:
            if cargo is held:
                continue
            box = cargo.box()
            if overlap(parts[0], box) or (held and overlap(parts[2], box)):
                return True
            if overlap(parts[1], box) and not self.can_insert(cargo):
                return True
        return False
    def step(self, drive, steer, lift, dt=STEP):
        events = []
        if self.cleared:
            return events
        target = drive * (FORWARD if drive > 0 else REVERSE)
        self.speed = approach(self.speed, target, ACCEL * dt)
        if steer:
            before = self.angle
            self.angle = (self.angle + steer * TURN * dt) % 360.0
            self._carry()
            if self.collides():
                self.angle = before
                self._carry()
        if self.speed:
            before = (self.x, self.z)
            self.x, self.z = world(self.x, self.z, self.angle, self.speed * dt, 0.0)
            self._carry()
            if self.collides():
                self.x, self.z = before
                self._carry()
                if abs(self.speed) > 1.0:
                    events.append("bump")
                self.speed = 0.0
        self._lift(lift, dt, events)
        placed = self.count_placed()
        if placed > self.placed:
            events.append("goal")
        self.placed = placed
        self.full_time = self.full_time + dt if placed == len(self.goals) else 0.0
        if self.full_time >= CLEAR_HOLD:
            self.cleared = True
            self.speed = 0.0
            events.append("clear")
        return events
    def _lift(self, lift, dt, events):
        if lift <= 0:
            self._denied = False
        if lift > 0:
            if self.carrying is None:
                under = self.under()
                if under:
                    if len(under) == 1 and self.in_reach(self.cargo[under[0]]):
                        self.pick_up(under[0])
                        events.append("pickup")
                    else:
                        if not self._denied:
                            events.append("deny")
                        self._denied = True
                        return
            self.lift = min(LIFT_MAX, self.lift + LIFT_SPEED * dt)
        elif lift < 0:
            self.lift = max(0.0, self.lift - LIFT_SPEED * dt)
            if self.carrying is not None and self.lift == 0.0:
                self.carrying = self._grip = None
                events.append("place")
    def pick_up(self, index):
        cargo = self.cargo[index]
        f, r = local(self.x, self.z, self.angle, cargo.x, cargo.z)
        self.carrying, self._grip = index, (f, r, cargo.angle - self.angle)
    def _carry(self):
        if self.carrying is not None:
            f, r, turn = self._grip
            cargo = self.cargo[self.carrying]
            cargo.x, cargo.z = world(self.x, self.z, self.angle, f, r)
            cargo.angle = (self.angle + turn) % 360.0
    def filled(self):
        return [next((i for i, c in enumerate(self.cargo) if i != self.carrying and inside(c.box(), *goal)), None)
                for goal in self.goals]
    def count_placed(self):
        return sum(1 for index in self.filled() if index is not None)
    def over(self):
        if self.carrying is None:
            return None
        box = self.cargo[self.carrying].box()
        return next((i for i, goal in enumerate(self.goals) if inside(box, *goal)), None)
    def hold_over_goal(self, lift=0.5):
        saved = (self.x, self.z, self.angle, self.lift)
        x0, x1, z0, z1 = self.goals[0]
        cargo = self.cargo[0]
        home = (cargo.x, cargo.z, cargo.angle)
        gx, gz = (x0 + x1) / 2, (z0 + z1) / 2
        self.x, self.z, self.angle, self.lift = gx, gz - BODY_FRONT - CARGO / 2, 0.0, lift
        cargo.x, cargo.z, cargo.angle = gx, gz, 0.0
        self.pick_up(0)
        if self.collides():
            self.carrying = self._grip = None
            self.x, self.z, self.angle, self.lift = saved
            cargo.x, cargo.z, cargo.angle = home
            return False
        return True
