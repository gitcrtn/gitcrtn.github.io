import sys
import forklift as fl
from rgbkit import HEIGHT, WIDTH, Game, Progress, format_time
from scene3d import CAMERA_HOME, CAMERA_TILT, SKY, TILT_MAX, TILT_MIN, Scene3D
from stages import STAGES
WHITE = (255, 255, 255)
SHADOW = (20, 24, 34)
DIRECTIONS = ("up", "down", "left", "right")
CLEAR_WAIT = 1.0
CAMERA_TURN = 90.0
CAMERA_TILT_SPEED = 45.0
DENIED_SECONDS = 0.4
HELD = {"engine": 0.35, "reverse": 0.4, "lift": 0.4}
class ForkliftGame(Game):
    title = "フォークリフト"
    background = SKY
    step_seconds = fl.STEP
    save_with_command = False
    uses_3d = True
    web_keyboard = {}
    web_touch_layout = {}
    web_sound_band = (300, 6000)
    def start(self):
        self.input.left_stick_counts = False
        self.scene3d = Scene3D(self)
        self.progress = Progress(self, stages=len(STAGES), low=0.0)
        self.stage = self.progress.selected
        self.model = fl.Forklift(STAGES[self.stage])
        self.time = 0.0
        self.new_best = False
        self.drive = self.steer = 0.0
        self.lift_input = 0
        self.denied = None
        self.denied_left = 0.0
        self.spin = 0.0
        self.camera = CAMERA_HOME
        self.tilt = CAMERA_TILT
        for name in ("place", "deny", "goal", "clear", "pickup", "bump"):
            self.sound.load("sounds/%s.wav" % name)
        self.enter("title")
    def controls(self):
        return {"dpad", "left_stick", "right_stick", "a", "b", "x", "start"}
    def hidden_command(self, text):
        values = self.command_values()
        stage = values.int("stage", 1, len(STAGES))
        if values.flag("unlock"):
            self.progress.unlocked = len(STAGES)
        carry = values.flag("carry")
        if stage is not None or carry:
            self.start_stage((stage or 1) - 1)
            if carry and not self.model.hold_over_goal():
                self.log("command: carry does not fit in stage %d" % (self.stage + 1))
    def start_stage(self, index):
        self.sound.stop_held()
        self.stage = self.progress.selected = index
        self.model = fl.Forklift(STAGES[index])
        self.time = 0.0
        self.new_best = False
        self.drive = self.steer = 0.0
        self.lift_input = 0
        self.denied = None
        self.log("stage: %d start" % (index + 1))
        self.enter("play")
    def to_title(self):
        self.sound.stop_held()
        self.model = fl.Forklift(STAGES[self.progress.selected])
        self.enter("title")
    def finish(self):
        self.sound.stop_held()
        self.new_best = self.progress.record(self.stage, round(self.time, 2))
        self.progress.unlock(self.stage + 2)
        self.progress.save()
        self.log("stage: %d clear time=%.2f%s" % (self.stage + 1, self.time, " best" if self.new_best else ""))
        self.sound.play("sounds/clear.wav", volume=0.6)
        self.enter("clear")
    def menu_items(self):
        if self.scene in ("play", "clear"):
            return [("やり直す", lambda: self.start_stage(self.stage)), ("ステージを選ぶ", self.to_title)]
        return []
    def update_title(self, dt):
        inp = self.input
        self.spin = (self.spin + 12 * dt) % 360
        selected = self.progress.selected
        if inp.repeat("left") and inp.only(*DIRECTIONS):
            selected = max(0, selected - 1)
        elif inp.repeat("right") and inp.only(*DIRECTIONS):
            selected = min(self.progress.unlocked - 1, selected + 1)
        elif inp.tapped("a"):
            self.start_stage(selected)
            return
        if selected != self.progress.selected:
            self.progress.selected = selected
            self.model = fl.Forklift(STAGES[selected])
            self.sound.beep(660, 0.04)
    def update_play(self, dt):
        inp = self.input
        x, y = inp.stick("left")
        self.drive, self.steer = -y, x
        self.lift_input = 1 if inp.only("x") else -1 if inp.only("b") else 0
        rx, ry = inp.stick("right")
        self.camera = (self.camera - rx * CAMERA_TURN * dt) % 360
        self.tilt = max(TILT_MIN, min(TILT_MAX, self.tilt - ry * CAMERA_TILT_SPEED * dt))
        self.denied_left = max(0.0, self.denied_left - dt)
        if not self.denied_left:
            self.denied = None
    def step(self):
        if self.scene != "play":
            return
        model = self.model
        lift = model.lift
        events = model.step(self.drive, self.steer, self.lift_input)
        self.time += fl.STEP
        self.hold("engine", abs(model.speed) > 0.05 or abs(self.steer) > 0.05)
        self.hold("reverse", model.speed < -0.05)
        self.hold("lift", model.lift != lift)
        for event in events:
            if event == "deny":
                under = model.under()
                self.denied, self.denied_left = (under[0] if under else None), DENIED_SECONDS
            if event == "clear":
                self.finish()
            else:
                self.sound.play("sounds/%s.wav" % event, volume=0.6)
    def update_clear(self, dt):
        if self.input.tapped("a", since=self.entered, wait=CLEAR_WAIT):
            if self.stage + 1 < len(STAGES):
                self.start_stage(self.stage + 1)
            else:
                self.to_title()
    def hold(self, name, on):
        self.sound.hold("sounds/%s.wav" % name, on, volume=HELD[name])
    def save(self):
        self.progress.save()
    def draw(self, gfx):
        title = self.scene == "title"
        self.scene3d.draw(self.model, camera=self.spin if title else self.camera, tilt=self.tilt, title=title, denied=self.denied)
        self.draw_scene(gfx)
    def text(self, gfx, x, y, text, size, color=WHITE, align="left"):
        gfx.text(x, y, text, size, color, align=align, shadow=SHADOW)
    def draw_title(self, gfx):
        progress = self.progress
        best = progress.best[progress.selected]
        self.text(gfx, WIDTH // 2, 60, "フォークリフト", 76, (255, 205, 40), align="center")
        self.text(gfx, WIDTH // 2, 520, "ステージ %d / %d" % (progress.selected + 1, len(STAGES)), 44, align="center")
        self.text(gfx, WIDTH // 2, 580, "ベスト %s" % (format_time(best) if best is not None else "--"), 30,
                  align="center")
        self.text(gfx, WIDTH // 2, 636, "左右: 選ぶ（%d まで）   A: はじめる" % progress.unlocked, 24, align="center")
    def draw_hud(self, gfx):
        model = self.model
        self.text(gfx, 16, 12, "ステージ %d" % (self.stage + 1), 28)
        self.text(gfx, WIDTH // 2, 12, format_time(self.time), 32, align="center")
        self.text(gfx, WIDTH - 16, 12, "荷物 %d / %d" % (model.placed, len(model.goals)), 28, align="right")
        x, top, h = WIDTH - 52, 250, 240
        gfx.rect(x - 2, top - 2, 20, h + 4, SHADOW)
        gfx.rect(x, top, 16, h, (70, 76, 90))
        level = int(h * model.lift / fl.LIFT_MAX)
        pocket = int(h * fl.POCKET / fl.LIFT_MAX)
        gfx.rect(x - 8, top + h - pocket - 1, 32, 2, (90, 220, 120))
        color = (90, 220, 120) if model.lift <= fl.POCKET else (255, 205, 40)
        gfx.rect(x, top + h - level - 6, 16, level + 6, color)
        self.text(gfx, x + 8, top - 34, "リフト", 20, align="center")
    def draw_play(self, gfx):
        self.draw_hud(gfx)
        self.text(gfx, WIDTH // 2, HEIGHT - 38, "左スティック: 走る   右スティック: カメラ   X: 上げる   B: 下げる", 20,
                  align="center")
    def draw_clear(self, gfx):
        self.draw_hud(gfx)
        best = self.progress.best[self.stage]
        self.text(gfx, WIDTH // 2, 70, "CLEAR", 84, (70, 235, 110), align="center")
        self.text(gfx, WIDTH // 2, 178, "タイム %s%s" % (format_time(self.time), "  ベスト更新" if self.new_best else ""),
                  32, align="center")
        if best is not None:
            self.text(gfx, WIDTH // 2, 222, "ベスト %s" % format_time(best), 26, align="center")
        if self.scene_time >= CLEAR_WAIT:
            last = self.stage + 1 >= len(STAGES)
            self.text(gfx, WIDTH // 2, HEIGHT - 44, "A: ステージ選びへ" if last else "A: 次のステージ", 26,
                      align="center")
    def debug_state(self):
        model = self.model
        return {"scene": self.scene, "stage": self.stage + 1, "selected": self.progress.selected + 1,
                "unlocked": self.progress.unlocked, "x": round(model.x, 2), "z": round(model.z, 2),
                "angle": round(model.angle, 1), "lift": round(model.lift, 2), "carrying": model.carrying,
                "placed": model.placed, "time": round(self.time, 2), "camera": round(self.camera, 1),
                "tilt": round(self.tilt, 1)}
if __name__ == "__main__":
    sys.exit(ForkliftGame().run())
