import math
import forklift as fl
from rgbkit import g3d
from rgbkit.g3dtop import world
VIEW_SIZE = 360
SKY = (46, 52, 64)
CENTER = (0.0, 0.0, -0.2)
CAMERA_DISTANCE = 17.4
CAMERA_TILT = 62.0
TILT_MIN, TILT_MAX = 25.0, 85.0
CAMERA_HOME = 180.0
FOV = 50
FLOOR = (150, 152, 158)
WALL = (196, 128, 84)
WALL_HEIGHT = 0.9
YELLOW = (255, 200, 40)
DARK = (50, 52, 60)
STEEL = (120, 125, 135)
PALLET = (200, 160, 105)
GOAL = (255, 205, 30)
GOAL_FILLED = (70, 235, 110)
HOME = (90, 160, 255)
CARGO_PLAIN = (205, 205, 205)
CARGO_READY = (255, 255, 255)
CARGO_DENIED = (255, 110, 100)
PALLET_HEIGHT = 0.14
BODY_PARTS = [
    (0.0, 0.45, -0.45, 0.9, 0.5, 1.3, YELLOW),
    (0.0, 0.55, -1.08, 1.0, 0.7, 0.34, DARK),
    (0.0, 0.82, -0.55, 0.7, 0.24, 0.6, DARK),
    (-0.45, 0.28, 0.0, 0.16, 0.56, 0.56, DARK),
    (0.45, 0.28, 0.0, 0.16, 0.56, 0.56, DARK),
    (-0.45, 0.22, -0.95, 0.16, 0.44, 0.44, DARK),
    (0.45, 0.22, -0.95, 0.16, 0.44, 0.44, DARK),
    (-0.4, 1.2, -0.02, 0.07, 1.0, 0.07, DARK),
    (0.4, 1.2, -0.02, 0.07, 1.0, 0.07, DARK),
    (-0.4, 1.2, -0.9, 0.07, 1.0, 0.07, DARK),
    (0.4, 1.2, -0.9, 0.07, 1.0, 0.07, DARK),
    (-0.4, 1.73, -0.46, 0.08, 0.06, 1.0, DARK),
    (0.4, 1.73, -0.46, 0.08, 0.06, 1.0, DARK),
    (0.0, 1.73, -0.92, 0.88, 0.06, 0.08, DARK),
    (0.0, 1.73, 0.0, 0.88, 0.06, 0.08, DARK),
    (-0.3, 1.15, 0.19, 0.1, 2.1, 0.1, STEEL),
    (0.3, 1.15, 0.19, 0.1, 2.1, 0.1, STEEL),
]
LIFT_PARTS = [
    (0.0, 0.3, 0.26, 0.84, 0.44, 0.05, DARK),
    (-0.28, 0.05, fl.BODY_FRONT + fl.FORK_LENGTH / 2, 0.13, 0.06, fl.FORK_LENGTH, STEEL),
    (0.28, 0.05, fl.BODY_FRONT + fl.FORK_LENGTH / 2, 0.13, 0.06, fl.FORK_LENGTH, STEEL),
]
TILE = ["################"] + ["#oooooooooooooo#"] * 14 + ["################"]
TILE_COLORS = {"#": (205, 205, 205), "o": (255, 255, 255)}
def frame_rows(size=32, border=5):
    rows = []
    for y in range(size):
        row = ""
        for x in range(size):
            edge = min(x, y, size - 1 - x, size - 1 - y) < border
            row += ("#" if (x + y) // 4 % 2 == 0 else "k") if edge else "."
        rows.append(row)
    return rows
class Scene3D:
    def __init__(self, game):
        view = self.view = g3d.View(game, size=VIEW_SIZE)
        self.cube = view.mesh(g3d.box())
        self.crate = view.mesh(g3d.box(), texture=view.texture("crate.png"))
        self.tile = view.texture_rows(TILE, TILE_COLORS)
        frame = view.texture_rows(frame_rows(), {"#": (255, 255, 255), "k": (60, 60, 60)})
        self.frame = view.mesh(g3d.plane(1, 1), texture=frame, lit=False)
        view.background(SKY)
        view.light((0.45, -1.0, 0.6), ambient=0.55)
        self._floors = {}
    def floor(self, size):
        if size not in self._floors:
            w, d = size
            cells = max(1, round(w / 2))
            self._floors[size] = self.view.mesh(g3d.plane(w, d, cells=cells), texture=self.tile, color=FLOOR)
        return self._floors[size]
    def draw(self, model, camera=CAMERA_HOME, tilt=CAMERA_TILT, title=False, denied=None):
        view = self.view
        stage = model.stage
        if title:
            view.orbit((0.0, 0.0, 0.0), 13.0, 10.0, camera, fov=FOV)
        else:
            t = math.radians(tilt)
            view.orbit(CENTER, CAMERA_DISTANCE * math.cos(t), CAMERA_DISTANCE * math.sin(t), camera, fov=FOV)
        view.draw(self.floor(tuple(stage["floor"])))
        for x, z, _ in stage["cargo"]:
            view.draw(self.frame, pos=(x, 0.015, z), scale=(1.3, 1, 1.3), color=HOME)
        filled = model.filled()
        for (x, z, w, d), index in zip(stage["goals"], filled):
            view.draw(self.frame, pos=(x, 0.02, z), scale=(w, 1, d), color=GOAL if index is None else GOAL_FILLED)
        for x, z, w, d in stage.get("walls", ()):
            view.draw(self.cube, pos=(x, WALL_HEIGHT / 2, z), scale=(w, WALL_HEIGHT, d), color=WALL)
        target = model.target()
        for i, cargo in enumerate(model.cargo):
            base = model.lift if i == model.carrying else 0.0
            color = CARGO_DENIED if i == denied else CARGO_READY if i == target or i in filled else CARGO_PLAIN
            rot = (0, cargo.angle, 0)
            view.draw(self.cube, pos=(cargo.x, base + PALLET_HEIGHT / 2, cargo.z), rot=rot,
                      scale=(fl.CARGO, PALLET_HEIGHT, fl.CARGO), color=PALLET)
            height = fl.CARGO_HEIGHT - PALLET_HEIGHT
            view.draw(self.crate, pos=(cargo.x, base + PALLET_HEIGHT + height / 2, cargo.z), rot=rot,
                      scale=(fl.CARGO * 0.9, height, fl.CARGO * 0.9), color=color)
            if i == model.carrying:
                view.shadow((cargo.x, 0.0, cargo.z), radius=0.62, strength=0.45)
        rot = (0, model.angle, 0)
        for parts, lift in ((BODY_PARTS, 0.0), (LIFT_PARTS, model.lift)):
            for r, y, f, w, h, d, color in parts:
                x, z = world(model.x, model.z, model.angle, f, r)
                view.draw(self.cube, pos=(x, y + lift, z), rot=rot, scale=(w, h, d), color=color)
        view.show()
