import sys
import sprites
import world as w
from rgbkit import HEIGHT, WIDTH, Game
from world import World
TITLE = "title"
GAME = "game"
GAME_OVER_LOCK = 1.0
SOUNDS = {
    "shot": ("sounds/shot.wav", 0.45),
    "hit": ("sounds/hit.wav", 0.6),
    "ufo_hit": ("sounds/ufo_hit.wav", 0.6),
    "player_hit": ("sounds/player.wav", 0.9),
    "march1": ("sounds/march1.wav", 0.7),
    "march2": ("sounds/march2.wav", 0.7),
    "march3": ("sounds/march3.wav", 0.7),
    "march4": ("sounds/march4.wav", 0.7),
    "extra": ("sounds/extra.wav", 0.6),
    "clear": ("sounds/clear.wav", 0.6),
    "over": ("sounds/over.wav", 0.7),
    "ufo": ("sounds/ufo.wav", 0.3),
}
WHITE = (240, 240, 240)
GRAY = (150, 150, 160)
ACCENT = (110, 200, 255)
GROUND = (110, 230, 150)
SHADE = (0, 0, 0, 150)
class Invaders(Game):
    title = "インベーダー"
    background = (8, 10, 20)
    step_seconds = w.STEP
    uses_3d = False
    web_keyboard = {}
    web_touch_layout = {}
    web_sound_band = (300, 6000)
    def controls(self):
        return {"dpad", "left_stick", "a", "b", "start"}
    def start(self):
        try:
            self.hi = max(0, int(self.load_json("hiscore.json", {})["hi"]))
        except (KeyError, TypeError, ValueError):
            self.hi = 0
        self.world = World()
        self.scene = TITLE
        self.clock = 0.0
        self.over_time = 0.0
        self.new_record = False
        self.move = 0
        self._make_sprites()
        for path, _ in SOUNDS.values():
            self.sound.load(path)
    def _make_sprites(self):
        gfx, dot = self.gfx, sprites.DOT
        self.sp_invaders = [[gfx.sprite(frame, color, dot) for frame in frames]
                            for frames, color in zip(sprites.INVADERS, sprites.INVADER_COLORS)]
        self.sp_player = gfx.sprite(sprites.PLAYER, sprites.PLAYER_COLOR, dot)
        self.sp_life = gfx.sprite(sprites.PLAYER, sprites.PLAYER_COLOR, 2)
        self.sp_player_blast = [gfx.sprite(frame, sprites.PLAYER_COLOR, dot) for frame in sprites.PLAYER_BLAST]
        self.sp_ufo = gfx.sprite(sprites.UFO, sprites.UFO_COLOR, dot)
        self.sp_blast = gfx.sprite(sprites.BLAST, sprites.BLAST_COLOR, dot)
        self.sp_enemy_shot = [gfx.sprite(frame, sprites.ENEMY_SHOT_COLOR, dot) for frame in sprites.ENEMY_SHOT]
        self.sp_shields = [gfx.sprite(shield.dots, sprites.SHIELD_COLOR, dot) for shield in self.world.shields]
    def start_game(self):
        self.world.new_game()
        self.scene = GAME
        self.over_time = 0.0
        self.new_record = False
        self.move = 0
        self.log("game: start")
    def to_title(self):
        self._keep_hi()
        self.scene = TITLE
        self.sound.stop()
    def _keep_hi(self):
        if self.scene == GAME and self.world.score > self.hi:
            self.hi = self.world.score
            self.save_json("hiscore.json", {"hi": self.hi})
            return True
        return False
    def menu_items(self):
        if self.scene == TITLE:
            return []
        if self.world.phase == w.OVER:
            return [("タイトルに戻る", self.to_title)]
        return [("タイトルに戻る", self.ask_title)]
    def ask_title(self):
        self.confirm("タイトルに戻りますか？", self.to_title, lines=["いまのゲームは終わります"])
    def update(self, dt):
        inp = self.input
        self.clock += dt
        self.move = 0
        if self.scene == TITLE:
            if inp.tapped("a"):
                self.start_game()
        elif self.world.phase == w.OVER:
            self.over_time += dt
            if self.over_time >= GAME_OVER_LOCK and inp.tapped("a"):
                self.to_title()
        elif inp.only("left", "right", "a"):
            self.move = inp.direction()[0]
    def step(self):
        world = self.world
        if self.scene != GAME or world.phase == w.OVER:
            return
        inp = self.input
        fire = world.phase == w.PLAY and inp.pressed("a") and inp.only("left", "right", "a")
        wave = world.wave
        world.step(self.move, fire)
        if world.wave != wave:
            self.log("game: wave %d" % world.wave)
        for name in world.events:
            self._play(name)
        world.events.clear()
        path, volume = SOUNDS["ufo"]
        self.sound.hold(path, bool(world.ufo) and world.phase == w.PLAY, volume)
        if world.phase == w.OVER:
            self._play("over")
            self.over_time = 0.0
            self.new_record = self._keep_hi()
            self.log("game: over score=%d wave=%d" % (world.score, world.wave))
    def _play(self, name):
        path, volume = SOUNDS[name]
        self.sound.play(path, volume)
    def draw(self, gfx):
        if self.scene == TITLE:
            self._draw_title(gfx)
            return
        world = self.world
        self._draw_hud(gfx, world.score, world.wave)
        self._draw_world(gfx, world)
        if world.phase == w.READY:
            gfx.text(WIDTH // 2, 440, "WAVE %d" % world.wave, 40, WHITE, align="center")
        elif world.phase == w.OVER:
            self._draw_game_over(gfx, world)
    def _draw_hud(self, gfx, score, wave):
        gfx.text(24, 4, "SCORE", 18, GRAY)
        gfx.text(24, 24, "%05d" % score, 26, WHITE)
        gfx.text(WIDTH // 2, 4, "HI-SCORE", 18, GRAY, align="center")
        gfx.text(WIDTH // 2, 24, "%05d" % max(self.hi, score), 26, WHITE, align="center")
        gfx.text(WIDTH - 24, 4, "WAVE", 18, GRAY, align="right")
        gfx.text(WIDTH - 24, 24, "%d" % wave, 26, WHITE, align="right")
    def _draw_world(self, gfx, world):
        frame = world.march_frame
        for kind, x, y, _ in world.invaders():
            gfx.blit(self.sp_invaders[kind][frame], x, y)
        for x, y, _ in world.blasts:
            gfx.blit(self.sp_blast, x, y)
        if world.ufo:
            gfx.blit(self.sp_ufo, world.ufo[0], w.UFO_Y)
        for x, y, text, _ in world.popups:
            gfx.text(x, y - 4, text, 22, sprites.UFO_COLOR, align="center")
        for shield, sprite in zip(world.shields, self.sp_shields):
            if shield.dirty:
                gfx.sprite_update(sprite, shield.dots, sprites.SHIELD_COLOR)
                shield.dirty = False
            gfx.blit(sprite, shield.x, shield.y)
        if world.shot:
            gfx.rect(world.shot[0], world.shot[1], w.SHOT_W, w.SHOT_H, sprites.PLAYER_SHOT_COLOR)
        flicker = int(self.clock * 12) % 2
        for x, y in world.enemy_shots:
            gfx.blit(self.sp_enemy_shot[flicker], x, y)
        if world.phase == w.DYING or (world.phase == w.OVER and world.lives <= 0):
            gfx.blit(self.sp_player_blast[int(self.clock * 10) % 2], world.player_x, w.PLAYER_Y)
        else:
            gfx.blit(self.sp_player, world.player_x, w.PLAYER_Y)
        gfx.rect(0, w.GROUND_Y, WIDTH, 2, GROUND)
        for i in range(min(world.lives, 8)):
            gfx.blit(self.sp_life, 24 + i * 36, 690)
    def _draw_game_over(self, gfx, world):
        gfx.rect(0, 0, WIDTH, HEIGHT, SHADE)
        gfx.text(WIDTH // 2, 250, "GAME OVER", 64, WHITE, align="center")
        gfx.text(WIDTH // 2, 350, "SCORE  %d" % world.score, 34, WHITE, align="center")
        if self.new_record:
            gfx.text(WIDTH // 2, 404, "ハイスコア更新", 28, ACCENT, align="center")
        if self.over_time >= GAME_OVER_LOCK:
            gfx.text(WIDTH // 2, 480, "A: タイトルへ   START: メニュー", 22, GRAY, align="center")
    def _draw_title(self, gfx):
        gfx.text(WIDTH // 2, 110, "インベーダー", 72, WHITE, align="center")
        gfx.text(WIDTH // 2, 226, "HI-SCORE  %05d" % self.hi, 28, ACCENT, align="center")
        frame = int(self.clock * 2) % 2
        y = 310
        gfx.blit(self.sp_ufo, 258, y + 1)
        gfx.text(336, y - 8, "=  ? 点", 26, WHITE)
        for kind, points in enumerate(w.KIND_SCORE):
            y += 52
            sprite = self.sp_invaders[kind][frame]
            gfx.blit(sprite, 282 - sprite.w // 2, y)
            gfx.text(336, y - 8, "=  %d 点" % points, 26, WHITE)
        if int(self.clock * 2) % 2 == 0:
            gfx.text(WIDTH // 2, 560, "A: スタート", 32, WHITE, align="center")
        gfx.text(WIDTH // 2, HEIGHT - 76, "左右: 動かす   A: 撃つ   START: メニュー", 20, GRAY, align="center")
    def save(self):
        self._keep_hi()
        self.save_json("hiscore.json", {"hi": self.hi})
        self.log("saved: hi=%d" % self.hi)
    def hidden_command(self, name):
        if name not in ("play", "over"):
            raise ValueError("隠しコマンド %s: 用意している場面は play / over" % name)
        self.start_game()
        self.world.phase = w.PLAY if name == "play" else w.OVER
    def debug_state(self):
        world = self.world
        return {"scene": self.scene, "phase": world.phase, "x": round(world.player_x), "shots": world.shots,
                "score": world.score, "lives": world.lives, "wave": world.wave, "hi": self.hi}
if __name__ == "__main__":
    sys.exit(Invaders().run())
