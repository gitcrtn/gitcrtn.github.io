import random
STEP = 1.0 / 60
READY = "ready"
PLAY = "play"
DYING = "dying"
CLEAR = "clear"
OVER = "over"
STAGING = 1.5
DOT = 3
FIELD_L, FIELD_R = 24, 696
TOP = 60
GROUND_Y = 676
PLAYER_W, PLAYER_H = 39, 24
PLAYER_Y = 636
PLAYER_SPEED = 240
SHOT_W, SHOT_H = 3, 15
SHOT_SPEED = 720
LIVES = 3
EXTRA_LIFE_SCORE = 1500
COLS, ROWS = 11, 5
CELL_W, CELL_H = 36, 24
PITCH_X, PITCH_Y = 48, 42
KIND_OF_ROW = (0, 1, 1, 2, 2)
KIND_W = (24, 33, 36)
KIND_SCORE = (30, 20, 10)
MARCH_X = 6
MARCH_DROP = 24
MARCH_PER_INVADER = 0.016
MARCH_MIN = 0.03
FORMATION_Y = 120
FORMATION_Y_STEP = 24
FORMATION_Y_MAX_STEPS = 4
ENEMY_SHOT_W, ENEMY_SHOT_H = 6, 15
ENEMY_SHOT_MAX = 3
ENEMY_FIRE_INTERVAL = 0.9
ENEMY_FIRE_INTERVAL_STEP = 0.05
ENEMY_FIRE_INTERVAL_MIN = 0.5
ENEMY_SHOT_SPEED = 240
ENEMY_SHOT_SPEED_STEP = 15
ENEMY_SHOT_SPEED_MAX = 330
UFO_W, UFO_H = 48, 21
UFO_Y = 72
UFO_SPEED = 120
UFO_WAIT = (20.0, 30.0)
UFO_MIN_INVADERS = 8
UFO_SCORES = (50, 100, 150, 300)
SHIELD_COLS, SHIELD_ROWS = 22, 16
SHIELD_W, SHIELD_H = SHIELD_COLS * DOT, SHIELD_ROWS * DOT
SHIELD_Y = 540
SHIELD_XS = (105, 253, 401, 549)
BLAST_TIME = 0.25
POPUP_TIME = 1.0
def overlap(ax, ay, aw, ah, bx, by, bw, bh):
    return ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah
class Shield:
    def __init__(self, x):
        self.x = x
        self.y = SHIELD_Y
        self.dots = [bytearray(self._solid(col, row) for col in range(SHIELD_COLS)) for row in range(SHIELD_ROWS)]
        self.dirty = True
    @staticmethod
    def _solid(col, row):
        if row < 4 and (col < 4 - row or col >= SHIELD_COLS - (4 - row)):
            return 0
        if row >= 10 and abs(col - (SHIELD_COLS - 1) / 2) < min(row - 8, 5):
            return 0
        return 1
    def _span(self, x, y, w, h):
        if not overlap(x, y, w, h, self.x, self.y, SHIELD_W, SHIELD_H):
            return None
        c0 = max(0, int((x - self.x) // DOT))
        c1 = min(SHIELD_COLS - 1, int((x + w - 1 - self.x) // DOT))
        r0 = max(0, int((y - self.y) // DOT))
        r1 = min(SHIELD_ROWS - 1, int((y + h - 1 - self.y) // DOT))
        return c0, c1, r0, r1
    def hit(self, x, y, w, h, going_down, rng):
        span = self._span(x, y, w, h)
        if not span:
            return False
        c0, c1, r0, r1 = span
        rows = range(r0, r1 + 1) if going_down else range(r1, r0 - 1, -1)
        for row in rows:
            for col in range(c0, c1 + 1):
                if self.dots[row][col]:
                    self._blast(col, row, 1 if going_down else -1, rng)
                    return True
        return False
    def _blast(self, col, row, direction, rng):
        for depth in range(-1, 4):
            for side in range(-2, 3):
                if (abs(side) == 2 or depth == 3) and rng.random() < 0.5:
                    continue
                r, c = row + depth * direction, col + side
                if 0 <= r < SHIELD_ROWS and 0 <= c < SHIELD_COLS and self.dots[r][c]:
                    self.dots[r][c] = 0
        self.dirty = True
    def erase(self, x, y, w, h):
        span = self._span(x, y, w, h)
        if not span:
            return
        c0, c1, r0, r1 = span
        for row in range(r0, r1 + 1):
            if any(self.dots[row][c0:c1 + 1]):
                self.dots[row][c0:c1 + 1] = bytes(c1 - c0 + 1)
                self.dirty = True
class World:
    def __init__(self, rng=None):
        self.rng = rng or random
        self.new_game()
    def new_game(self):
        self.score = 0
        self.lives = LIVES
        self.wave = 1
        self.extra_given = False
        self.shots = 0
        self.events = []
        self.march_note = 0
        self.player_x = float((FIELD_L + FIELD_R - PLAYER_W) // 2)
        self._setup_wave()
    def _setup_wave(self):
        self.alive = [[True] * COLS for _ in range(ROWS)]
        self.count = COLS * ROWS
        self.form_x = float((FIELD_L + FIELD_R - ((COLS - 1) * PITCH_X + CELL_W)) // 2)
        self.form_y = float(FORMATION_Y + FORMATION_Y_STEP * min(self.wave - 1, FORMATION_Y_MAX_STEPS))
        self.march_dir = 1
        self.march_timer = 0.0
        self.march_frame = 0
        self.shields = [Shield(x) for x in SHIELD_XS]
        self.shot = None
        self.enemy_shots = []
        self.enemy_fire_timer = self._enemy_fire_wait()
        self.ufo = None
        self.ufo_timer = self.rng.uniform(*UFO_WAIT)
        self.blasts = []
        self.popups = []
        self.phase = READY
        self.timer = STAGING
    def _enemy_fire_wait(self):
        interval = max(ENEMY_FIRE_INTERVAL_MIN, ENEMY_FIRE_INTERVAL - ENEMY_FIRE_INTERVAL_STEP * (self.wave - 1))
        return interval * self.rng.uniform(0.5, 1.5)
    def _enemy_shot_speed(self):
        return min(ENEMY_SHOT_SPEED_MAX, ENEMY_SHOT_SPEED + ENEMY_SHOT_SPEED_STEP * (self.wave - 1))
    def invaders(self):
        for row in range(ROWS):
            kind = KIND_OF_ROW[row]
            width = KIND_W[kind]
            y = self.form_y + row * PITCH_Y
            for col in range(COLS):
                if self.alive[row][col]:
                    yield kind, self.form_x + col * PITCH_X + (CELL_W - width) // 2, y, width
    def step(self, move=0, fire=False):
        self._tick_effects()
        if self.phase == PLAY:
            self._play(move, fire)
        elif self.phase in (READY, DYING, CLEAR):
            self.timer -= STEP
            if self.timer <= 0:
                self._end_staging()
    def _end_staging(self):
        if self.phase == READY:
            self.phase = PLAY
        elif self.phase == DYING:
            self.phase = OVER if self.lives <= 0 else PLAY
        elif self.phase == CLEAR:
            self.wave += 1
            self._setup_wave()
    def _tick_effects(self):
        for blast in self.blasts:
            blast[2] -= STEP
        self.blasts = [b for b in self.blasts if b[2] > 0]
        for popup in self.popups:
            popup[3] -= STEP
        self.popups = [p for p in self.popups if p[3] > 0]
    def _play(self, move, fire):
        self.player_x = max(FIELD_L, min(FIELD_R - PLAYER_W, self.player_x + move * PLAYER_SPEED * STEP))
        if fire and self.shot is None:
            self.shot = [self.player_x + (PLAYER_W - SHOT_W) // 2, PLAYER_Y - SHOT_H]
            self.shots += 1
            self.events.append("shot")
        self._march()
        if self.phase != PLAY:
            return
        self._move_ufo()
        self._enemy_fire()
        self._move_shot()
        self._move_enemy_shots()
        if self.phase == PLAY and self.count == 0:
            self.shot = None
            self.enemy_shots = []
            self.ufo = None
            self.phase = CLEAR
            self.events.append("clear")
            self.timer = STAGING
    def _march(self):
        self.march_timer += STEP
        if self.march_timer < max(MARCH_MIN, self.count * MARCH_PER_INVADER):
            return
        self.march_timer = 0.0
        self.march_frame ^= 1
        self.events.append("march%d" % (self.march_note + 1))
        self.march_note = (self.march_note + 1) % 4
        cols = [c for c in range(COLS) if any(self.alive[r][c] for r in range(ROWS))]
        if not cols:
            return
        left = self.form_x + cols[0] * PITCH_X
        right = self.form_x + cols[-1] * PITCH_X + CELL_W
        if (self.march_dir > 0 and right + MARCH_X > FIELD_R) or (self.march_dir < 0 and left - MARCH_X < FIELD_L):
            self.form_y += MARCH_DROP
            self.march_dir = -self.march_dir
        else:
            self.form_x += MARCH_X * self.march_dir
        bottom_row = max(r for r in range(ROWS) if any(self.alive[r]))
        bottom = self.form_y + bottom_row * PITCH_Y + CELL_H
        if bottom >= PLAYER_Y:
            self.phase = OVER
            return
        if bottom > SHIELD_Y:
            for _, x, y, width in self.invaders():
                for shield in self.shields:
                    shield.erase(x, y, width, CELL_H)
    def _enemy_fire(self):
        self.enemy_fire_timer -= STEP
        if self.enemy_fire_timer > 0 or len(self.enemy_shots) >= ENEMY_SHOT_MAX:
            return
        self.enemy_fire_timer = self._enemy_fire_wait()
        cols = [c for c in range(COLS) if any(self.alive[r][c] for r in range(ROWS))]
        if not cols:
            return
        col = self.rng.choice(cols)
        row = max(r for r in range(ROWS) if self.alive[r][col])
        self.enemy_shots.append([self.form_x + col * PITCH_X + (CELL_W - ENEMY_SHOT_W) // 2,
                                 self.form_y + row * PITCH_Y + CELL_H])
    def _move_ufo(self):
        if self.ufo:
            self.ufo[0] += UFO_SPEED * STEP * self.ufo[1]
            if self.ufo[0] < -UFO_W or self.ufo[0] > 720:
                self.ufo = None
            return
        self.ufo_timer -= STEP
        if self.ufo_timer <= 0:
            self.ufo_timer = self.rng.uniform(*UFO_WAIT)
            if self.count >= UFO_MIN_INVADERS:
                direction = self.rng.choice((-1, 1))
                self.ufo = [float(-UFO_W if direction > 0 else 720), direction]
    def _add_score(self, points):
        self.score += points
        if not self.extra_given and self.score >= EXTRA_LIFE_SCORE:
            self.extra_given = True
            self.lives += 1
            self.events.append("extra")
    def _move_shot(self):
        if self.shot is None:
            return
        self.shot[1] -= SHOT_SPEED * STEP
        x, y = self.shot
        if y < TOP:
            self.shot = None
            return
        for enemy in self.enemy_shots:
            if overlap(x, y, SHOT_W, SHOT_H, enemy[0], enemy[1], ENEMY_SHOT_W, ENEMY_SHOT_H):
                self.enemy_shots.remove(enemy)
                self.shot = None
                return
        for shield in self.shields:
            if shield.hit(x, y, SHOT_W, SHOT_H, False, self.rng):
                self.shot = None
                return
        if self.ufo and overlap(x, y, SHOT_W, SHOT_H, self.ufo[0], UFO_Y, UFO_W, UFO_H):
            points = self.rng.choice(UFO_SCORES)
            self._add_score(points)
            self.popups.append([self.ufo[0] + UFO_W // 2, UFO_Y, str(points), POPUP_TIME])
            self.events.append("ufo_hit")
            self.ufo = None
            self.shot = None
            return
        for row in range(ROWS - 1, -1, -1):
            iy = self.form_y + row * PITCH_Y
            if not overlap(x, y, SHOT_W, SHOT_H, x, iy, SHOT_W, CELL_H):
                continue
            kind = KIND_OF_ROW[row]
            width = KIND_W[kind]
            for col in range(COLS):
                ix = self.form_x + col * PITCH_X + (CELL_W - width) // 2
                if self.alive[row][col] and overlap(x, y, SHOT_W, SHOT_H, ix, iy, width, CELL_H):
                    self.alive[row][col] = False
                    self.count -= 1
                    self._add_score(KIND_SCORE[kind])
                    self.blasts.append([self.form_x + col * PITCH_X, iy, BLAST_TIME])
                    self.events.append("hit")
                    self.shot = None
                    return
    def _move_enemy_shots(self):
        speed = self._enemy_shot_speed()
        kept = []
        hit_player = False
        for shot in self.enemy_shots:
            shot[1] += speed * STEP
            x, y = shot
            if y + ENEMY_SHOT_H >= GROUND_Y:
                continue
            if any(shield.hit(x, y, ENEMY_SHOT_W, ENEMY_SHOT_H, True, self.rng) for shield in self.shields):
                continue
            if overlap(x, y, ENEMY_SHOT_W, ENEMY_SHOT_H, self.player_x, PLAYER_Y, PLAYER_W, PLAYER_H):
                hit_player = True
                continue
            kept.append(shot)
        self.enemy_shots = kept
        if hit_player:
            self.lives -= 1
            self.events.append("player_hit")
            self.shot = None
            self.enemy_shots = []
            self.phase = DYING
            self.timer = STAGING
