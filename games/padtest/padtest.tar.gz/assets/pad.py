import math
from rgbkit import g3d
PAD_W = 6.0
PAD_D = 3.2
PAD_H = 0.5
TOP = PAD_H
PAD_SIDES = 48
PAD_COLOR = (52, 57, 70)
BASE_COLOR = (34, 37, 46)
BUTTON_COLOR = (104, 111, 128)
DPAD_COLOR = (96, 103, 120)
SHOULDER_COLOR = (88, 95, 112)
STICK_COLOR = (98, 105, 122)
LIT_COLOR = (255, 212, 60)
TONES = {
    "up": 523, "down": 587, "left": 659, "right": 698,
    "a": 784, "b": 880, "x": 988, "y": 1047,
    "l1": 392, "l2": 440, "r1": 1175, "r2": 1319,
    "start": 1568,
}
FACE_CENTER = (1.8, 0.35)
FACE_GAP = 0.42
FACE = {
    "x": (FACE_CENTER[0], FACE_CENTER[1] + FACE_GAP),
    "b": (FACE_CENTER[0], FACE_CENTER[1] - FACE_GAP),
    "y": (FACE_CENTER[0] - FACE_GAP, FACE_CENTER[1]),
    "a": (FACE_CENTER[0] + FACE_GAP, FACE_CENTER[1]),
}
FACE_RADIUS = 0.17
BUTTON_H = 0.16
BUTTON_PRESS = BUTTON_H * 0.6
DPAD_CENTER = (-1.8, 0.35)
DPAD_LONG = 0.95
DPAD_WIDE = 0.32
DPAD_H = 0.14
DPAD_TILT = 8.0
DPAD_ARMS = {"up": (0, 1), "down": (0, -1), "left": (-1, 0), "right": (1, 0)}
START = (1.0, 0.95)
START_RADIUS = 0.11
START_STRETCH = 1.8
STICKS = {"left": (-1.0, -0.75), "right": (1.0, -0.75)}
STICK_BASE_RADIUS = 0.42
STICK_RADIUS = 0.3
STICK_H = 0.22
STICK_TILT = 25.0
STICK_SHIFT = 0.12
SHOULDERS = {"l1": -2.2, "l2": -1.35, "r2": 1.35, "r1": 2.2}
SHOULDER_W = 0.62
SHOULDER_H = 0.26
SHOULDER_D = 0.36
SHOULDER_PRESS = 0.12
RADIUS = PAD_D / 2
STRAIGHT = PAD_W - PAD_D
def edge_z(x):
    beyond = max(0.0, abs(x) - STRAIGHT / 2)
    return math.sqrt(max(0.0, RADIUS ** 2 - beyond ** 2))
def shoulder_pos(name):
    x = SHOULDERS[name]
    return (x, PAD_H * 0.6, edge_z(x) + SHOULDER_D * 0.4)
def body_shape():
    shape = g3d.Shape([], [])
    shape.add(g3d.box(STRAIGHT, PAD_H, PAD_D), pos=(0, PAD_H / 2, 0), color=PAD_COLOR)
    for side in (-1, 1):
        shape.add(g3d.cylinder(RADIUS, PAD_H, sides=PAD_SIDES), pos=(side * STRAIGHT / 2, PAD_H / 2, 0), color=PAD_COLOR)
    for x, z in STICKS.values():
        shape.add(g3d.cylinder(STICK_BASE_RADIUS, 0.04, sides=24), pos=(x, TOP + 0.02, z), color=BASE_COLOR)
    return shape
def dpad_arm_shape(direction):
    dx, dz = DPAD_ARMS[direction]
    length = (DPAD_LONG - DPAD_WIDE) / 2
    offset = (DPAD_WIDE + length) / 2
    size = (length, DPAD_H, DPAD_WIDE) if dx else (DPAD_WIDE, DPAD_H, length)
    return g3d.Shape([], []).add(g3d.box(*size), pos=(dx * offset, 0, dz * offset))
def dpad_tilt(pressed):
    tilt_x = DPAD_TILT * (("up" in pressed) - ("down" in pressed))
    tilt_z = DPAD_TILT * (("left" in pressed) - ("right" in pressed))
    return (tilt_x, 0, tilt_z)
