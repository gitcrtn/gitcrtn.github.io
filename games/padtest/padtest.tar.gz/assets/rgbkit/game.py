import argparse
import copy
import json
import math
import os
import random
import re
import shutil
import sys
import tempfile
import time
from . import backend
from .gfx import HEIGHT, WIDTH
from .input import AXIS_NAMES, STICK_DEAD, STICK_FULL, Input
from .sound import Sound
from .ui import Confirm, Menu, Message
SCRIPT_STEP_FRAMES = 6
SCRIPT_TAP_FRAMES = 2
SCRIPT_UNTIL_FRAMES = 600
_UNTIL = re.compile(r"^([A-Za-z_]\w*)(<=|>=|!=|<|>|=)(.*)$")
_UNTIL_ORDER = {"<": lambda a, b: a < b, ">": lambda a, b: a > b, "<=": lambda a, b: a <= b, ">=": lambda a, b: a >= b}
def _until_met(state, key, how, want):
    if key not in state:
        return False
    got = state[key]
    if how in _UNTIL_ORDER:
        return type(got) in (int, float) and _UNTIL_ORDER[how](got, float(want))
    same = want in (str(got), json.dumps(got, ensure_ascii=False))
    if not same and type(got) in (int, float):
        try:
            same = got == float(want)
        except ValueError:
            pass
    return same if how == "=" else not same
def parse_command(text):
    values = {}
    for item in text.replace(",", " ").split():
        name, _, value = item.partition("=")
        if name:
            values[name] = value
    return values
def format_time(seconds, places=1):
    unit = 10 ** places
    total = int(max(0.0, seconds) * unit + 0.5)
    minutes, rest = divmod(total, 60 * unit)
    if places:
        return "%d:%02d.%0*d" % (minutes, rest // unit, places, rest % unit)
    return "%d:%02d" % (minutes, rest)
def _fits(value, spec):
    kind, low, high = spec if isinstance(spec, tuple) else (spec, None, None)
    if kind is bool:
        return type(value) is bool
    if kind is int:
        ok = type(value) is int
    elif kind is float:
        ok = type(value) in (int, float) and math.isfinite(value)
    elif kind is str:
        ok = isinstance(value, str)
    else:
        raise ValueError("schema の書き方が違います: %r（int / float / str / bool か、(型, 下限, 上限)、[型]）" % (spec,))
    return ok and (low is None or value >= low) and (high is None or value <= high)
class CommandValues:
    def __init__(self, text, log):
        self.values = parse_command(text)
        self._log = log
        self._read = set()
        self._bad = []
    def _number(self, name, low, high, convert):
        self._read.add(name)
        if name not in self.values:
            return None
        try:
            value = convert(self.values[name])
        except ValueError:
            value = None
        if value is None or value != value or (low is not None and value < low) or (high is not None and value > high):
            self._bad.append("%s=%s" % (name, self.values[name]))
            return None
        return value
    def int(self, name, low=None, high=None):
        return self._number(name, low, high, int)
    def float(self, name, low=None, high=None):
        return self._number(name, low, high, float)
    def flag(self, name):
        self._read.add(name)
        return name in self.values
    def text(self, name):
        self._read.add(name)
        return self.values.get(name)
    def report(self):
        unknown = self._bad + sorted(name if not value else "%s=%s" % (name, value)
                                     for name, value in self.values.items() if name not in self._read)
        if unknown:
            self._log("command: unknown %s" % " ".join(unknown))
        return unknown
def _parse_script(text):
    events = {}
    cursor = 0
    end = 0
    def add(frame, name, is_down):
        events.setdefault(frame, []).append((name, is_down))
    def bad(item, why):
        return ValueError("--script の書き方が違います: %r（%s）" % (item, why))
    for item in (part.strip() for part in text.split(",")):
        if not item:
            continue
        if item.startswith("until:"):
            condition, colon, limit = item[len("until:"):].partition(":")
            found = _UNTIL.match(condition)
            if not found or (colon and (not limit.endswith("f") or not limit[:-1].isdigit() or int(limit[:-1]) < 1)):
                raise bad(item, "until:名前=値（例: until:scene=goal、until:y>32）。上限を付けるなら until:scene=goal:900f")
            key, how, value = found.groups()
            if how in _UNTIL_ORDER:
                try:
                    float(value)
                except ValueError:
                    raise bad(item, "< > <= >= のあとは、数")
            add(cursor, "until", (key, how, value, int(limit[:-1]) if colon else SCRIPT_UNTIL_FRAMES))
            end = max(end, cursor + 1)
            continue
        body, at_sign, at = item.partition("@")
        if "=" in body:
            name, _, text = body.partition("=")
            try:
                value = float(text)
            except ValueError:
                value = None
            if name not in AXIS_NAMES or value is None or not -1 <= value <= 1 or (at_sign and not at.isdigit()):
                raise bad(item, "スティックは、lx / ly / rx / ry に、-1〜1 の数（例: ly=-1、rx=0.5@36）")
            add(int(at) if at_sign else cursor, name, value)
            if at_sign:
                end = max(end, int(at) + 1)
            else:
                cursor += SCRIPT_STEP_FRAMES
                end = max(end, cursor)
            continue
        body, colon, count = body.partition(":")
        mode, name = (body[0], body[1:]) if body[:1] in ("+", "-") else ("", body)
        if not name or (at_sign and not at.isdigit()):
            raise bad(item, "名前、または @ のあとのフレームの数が、ありません")
        in_frames = count.endswith("f")
        number = count[:-1] if in_frames else count
        if colon and (not number.isdigit() or int(number) < 1):
            raise bad(item, ": のあとは、1 以上の数（フレームで書くなら、数のあとに f）")
        start = int(at) if at_sign else cursor
        if name == "wait":
            if mode or at_sign:
                raise bad(item, "wait に、+ - @ は付けられません")
            length = SCRIPT_STEP_FRAMES if not colon else int(number) * (1 if in_frames else SCRIPT_STEP_FRAMES)
        elif mode:
            if colon:
                raise bad(item, "+ と - に、長さは付けられません")
            add(start, name, mode == "+")
            length = SCRIPT_STEP_FRAMES
        else:
            if colon and not in_frames:
                raise bad(item, "押す長さは、フレームで書きます（例: a:12f）。回数を書けるのは wait:数 だけ")
            hold = int(number) if colon else SCRIPT_TAP_FRAMES
            add(start, name, True)
            add(start + hold, name, False)
            length = hold + SCRIPT_STEP_FRAMES - SCRIPT_TAP_FRAMES
        if at_sign:
            end = max(end, start + (length if not mode else 1))
        else:
            cursor += length
            end = max(end, cursor)
    return events, end
CONTROL_NAMES = ("dpad", "a", "b", "x", "y", "l1", "l2", "r1", "r2", "start", "left_stick", "right_stick")
COPYRIGHT_FILE = "copyright.txt"
COPYRIGHT_COLOR = (160, 160, 160)
def _copyright_text(game_dir):
    import configparser
    folder = os.path.abspath(game_dir)
    for _ in range(4):
        folder = os.path.dirname(folder)
        config = os.path.join(folder, "config.ini")
        if os.path.isdir(os.path.join(folder, "gamekit")) and os.path.isfile(config):
            parser = configparser.ConfigParser(interpolation=None)
            try:
                parser.read(config, encoding="utf-8")
                return parser.get("project", "copyright", fallback="").strip()
            except (configparser.Error, UnicodeDecodeError):
                return ""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), COPYRIGHT_FILE), encoding="utf-8") as f:
            return f.read().strip()
    except (OSError, UnicodeDecodeError):
        return ""
def _parse_frames(text):
    try:
        return {int(part) for part in text.split(",") if part.strip()}
    except ValueError:
        raise ValueError("--state-at の書き方が違います: %r（例: 40,100,140）" % text)
class _Timed:
    __slots__ = ("name", "spent", "worst", "count", "_start")
    def __init__(self, name):
        self.name, self.spent, self.worst, self.count, self._start = name, 0.0, 0.0, 0, 0.0
    def __enter__(self):
        self._start = time.perf_counter()
        return self
    def __exit__(self, *_):
        spent = time.perf_counter() - self._start
        self.spent += spent
        self.count += 1
        if spent > self.worst:
            self.worst = spent
        return False
FRAMES_START = 60
class _Frames:
    def __init__(self, last):
        self.last = last
        self.count = self.late = 0
        self.spent = self.worst = self.spent_update = self.spent_draw = 0.0
        self.worst_at = (0, None, 0.0, 0.0)
        self.later, self.later_at = 0.0, 0
        self.late_scenes = {}
class Game:
    title = "game"
    fps = 60
    background = (16, 18, 28)
    pause_on_start = True
    web_keyboard = None
    web_touch_layout = None
    web_sound_band = None
    pause_sound = True
    step_seconds = None
    max_steps = 5
    font_path = None
    save_with_command = True
    log_scenes = False
    scene = None
    entered = 0.0
    def __init__(self, argv=None, game_dir=None):
        parser = argparse.ArgumentParser()
        parser.add_argument("--windowed", action="store_true")
        parser.add_argument("--frames", type=int, default=None)
        parser.add_argument("--screenshot", default=None)
        parser.add_argument("--screenshot-at", default="")
        parser.add_argument("--script", default="")
        parser.add_argument("--state-at", default="")
        parser.add_argument("--save-dir", default=None)
        parser.add_argument("--fast", action="store_true")
        parser.add_argument("--seed", type=int, default=None)
        parser.add_argument("--command", default=None)
        parser.add_argument("--scene", default=None)
        parser.add_argument("--web-info", action="store_true")
        self.args = parser.parse_args(sys.argv[1:] if argv is None else argv)
        self.command = next((text for text in (self.args.command, self.args.scene,
                                               os.environ.get("RGBMENU_HIDDEN_COMMAND")) if text), "")
        self.game_dir = (game_dir or os.environ.get("RGBMENU_GAME_DIR")
                         or os.path.dirname(os.path.abspath(sys.argv[0])))
        self.copyright = _copyright_text(self.game_dir)
        self._script, self._script_end = _parse_script(self.args.script)
        self._script_list = sorted(((at, seq, name, value) for at, items in self._script.items()
                                    for seq, (name, value) in enumerate(items)), key=lambda item: item[:2])
        self._script_next = 0
        self._script_pos = 0
        self._until_frames = 0
        self._exit_code = 0
        self._values = None
        self._save_skipped = False
        self._state_at = _parse_frames(self.args.state_at)
        self._shot_at = _parse_frames(self.args.screenshot_at)
        if self._shot_at and not self.args.screenshot:
            parser.error("--screenshot-at は、--screenshot と一緒に使います（ファイルの名前を、そこから作る）")
        self.checking = self.args.frames is not None or self._script_end > 0
        self._last_frame = self.args.frames if self.args.frames is not None else (self._script_end or None)
        self._temp_save = None
        self.save_dir = self.args.save_dir or os.environ.get("RGBMENU_SAVE_DIR")
        if not self.save_dir and self.checking:
            self.save_dir = self._temp_save = tempfile.mkdtemp(prefix="rgbkit-save-")
        self.save_dir = self.save_dir or os.path.join(self.game_dir, "save")
        self.gfx = None
        self.input = None
        self.sound = None
        self.running = False
        self.quit_reason = ""
        self.frame = 0
        self.overlays = []
        self._term = False
        self._acc = 0.0
        self._measured = {}
        self._closers = []
        self._backend = None
        self._started = False
        self._stats = None
    def start(self):
        pass
    def update(self, dt):
        handler = getattr(self, "update_%s" % self.scene, None) if self.scene else None
        if handler:
            handler(dt)
    def step(self):
        handler = getattr(self, "step_%s" % self.scene, None) if self.scene else None
        if handler:
            handler()
    def draw(self, gfx):
        self.draw_scene(gfx)
    def draw_scene(self, gfx):
        handler = getattr(self, "draw_%s" % self.scene, None) if self.scene else None
        if handler:
            handler(gfx)
    def save(self):
        pass
    def debug_state(self):
        return None
    def hidden_command(self, text):
        pass
    def debug_scene(self, name):
        pass
    def menu_items(self):
        return []
    def enter(self, scene):
        if self.log_scenes:
            self.log("scene: %s -> %s" % (self.scene or "-", scene))
        self.scene = scene
        self.entered = self.input.now() if self.input else 0.0
    @property
    def scene_time(self):
        return self.input.now() - self.entered if self.input else 0.0
    def command_values(self):
        if self._values is None:
            self._values = CommandValues(self.command, self.log)
        return self._values
    def measure(self, name):
        timer = self._measured.get(name)
        if timer is None:
            timer = self._measured[name] = _Timed(name)
        return timer
    def add_closer(self, close):
        self._closers.append(close)
        return close
    def quit(self, reason="game"):
        if self.running:
            self.running = False
            self.quit_reason = reason
    def open(self, overlay):
        self.overlays.append(overlay)
        return overlay
    def close(self, overlay=None):
        if overlay is None:
            if self.overlays:
                self.overlays.pop()
        elif overlay in self.overlays:
            self.overlays.remove(overlay)
    @property
    def paused(self):
        return bool(self.overlays)
    def open_menu(self):
        items = [("ゲームに戻る", None)] + list(self.menu_items()) + [("終了", self.ask_quit)]
        return self.open(Menu(self, "メニュー", items))
    def ask_quit(self):
        return self.open(Confirm(self, "ゲームを終了しますか？", lambda: self.quit("menu"), yes="終了する"))
    def confirm(self, title, on_yes, lines=(), yes="はい", no="いいえ", danger=False):
        return self.open(Confirm(self, title, on_yes, lines, yes, no, danger))
    def message(self, title, lines=(), on_close=None):
        return self.open(Message(self, title, lines, on_close))
    def save_path(self, name):
        return os.path.join(self.save_dir, name)
    def load_json(self, name, default=None, schema=None, migrate=None):
        try:
            with open(self.save_path(name), encoding="utf-8") as f:
                data = json.load(f)
        except OSError:
            return default
        except ValueError:
            self.log("save: %s is broken (starting from the defaults)" % name)
            return default
        if migrate:
            data = migrate(data)
        if schema is None:
            return data
        result = copy.deepcopy(default) if default is not None else {}
        if not isinstance(data, dict):
            self.log("save: %s is not in the expected form (starting from the defaults)" % name)
            return result
        bad = []
        for key, value in data.items():
            spec = schema.get(key)
            if spec is None:
                result[key] = value
            elif isinstance(spec, list) or (isinstance(spec, tuple) and isinstance(spec[0], list)):
                spec, length = (spec, None) if isinstance(spec, list) else spec
                if isinstance(value, list):
                    items = [item if item is None or _fits(item, spec[0]) else None for item in value]
                    bad += ["%s[%d]" % (key, i) for i, item in enumerate(value)
                            if item is not None and not _fits(item, spec[0])]
                    if length is not None:
                        start = result.get(key) if isinstance(result.get(key), list) else []
                        items = (items + [copy.deepcopy(item) for item in start[len(items):]] + [None] * length)[:length]
                    result[key] = items
                else:
                    bad.append(key)
            elif _fits(value, spec):
                result[key] = value
            else:
                bad.append(key)
        if bad:
            self.log("save: %s: reset %s (not in the expected form)" % (name, " ".join(bad)))
        return result
    def save_json(self, name, data, always=False):
        if self.command and not self.save_with_command and not always:
            if not self._save_skipped:
                self._save_skipped = True
                self.log("save: skipped (started with a hidden command)")
            return False
        os.makedirs(self.save_dir, exist_ok=True)
        path = self.save_path(name)
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(path + ".tmp", path)
        if self._backend is not None:
            self._backend.persist(self.save_dir)
        return True
    def log(self, *values):
        print(*values, flush=True)
    def _run_script(self):
        items = self._script_list
        while self._script_next < len(items) and items[self._script_next][0] <= self._script_pos:
            _, _, name, value = items[self._script_next]
            if name == "until":
                key, how, want, limit = value
                if self.frame == 0:
                    return
                state = self._state()
                if _until_met(state, key, how, want):
                    self._until_frames = 0
                elif self._until_frames >= limit:
                    self.log("script: until %s%s%s did not happen in %d frames (%s=%s)" % (
                        key, how, want, limit, key, json.dumps(state.get(key), ensure_ascii=False, default=str)))
                    self._exit_code = 1
                    self.quit("until")
                    return
                else:
                    self._until_frames += 1
                    return
            elif name in AXIS_NAMES:
                far = STICK_DEAD + abs(value) * (STICK_FULL - STICK_DEAD) if value else 0
                self.input.set_axis(AXIS_NAMES[name], far if value > 0 else -far)
            else:
                self.input.set(name, value)
            self._script_next += 1
        self._script_pos += 1
    def _run_steps(self, dt):
        step = self.step_seconds
        self._acc = min(self._acc + dt, step * self.max_steps)
        count = int(self._acc / step + 1e-6)
        if count == 0 and self.input.has_edges():
            count = 1
        self._acc -= count * step
        for _ in range(count):
            self.step()
            self.input.clear_edges()
            if not self.running or self.overlays:
                break
    def _run_command(self):
        cls = type(self)
        if cls.hidden_command is not Game.hidden_command:
            self.log("command: %s" % self.command)
            self.hidden_command(self.command)
            if self._values is not None:
                self._values.report()
        elif cls.debug_scene is not Game.debug_scene:
            self.log("command: %s" % self.command)
            self.debug_scene(self.command)
        else:
            self.log("command: %s is not handled" % self.command)
    def _state(self):
        state = dict(self.debug_state() or {})
        if self.scene is not None:
            state.setdefault("scene", self.scene)
        state["overlays"] = [type(overlay).__name__ for overlay in self.overlays]
        return state
    def _log_state(self, label="state"):
        state = self._state()
        self.log("%s: %s" % (label, json.dumps(state, ensure_ascii=False, sort_keys=True, default=str)))
    def controls(self):
        raise NotImplementedError("%s に controls() がありません（使う操作の名前を返します。gamekit/README.md の「Web 版」）"
                                  % type(self).__name__)
    def web_info(self):
        names = self.controls()
        if isinstance(names, str) or not all(isinstance(name, str) for name in names):
            raise ValueError("controls() は、名前の集まりを返します（%r）" % (names,))
        unknown = sorted(set(names) - set(CONTROL_NAMES))
        if unknown:
            raise ValueError("controls() に、知らない名前があります: %s（使える名前: %s）" % (" ".join(unknown), " ".join(CONTROL_NAMES)))
        missing = [name for name in ("web_keyboard", "web_touch_layout", "web_sound_band") if getattr(self, name) is None]
        if missing:
            raise NotImplementedError("%s に %s がありません（Web 版の設定。どれも必須。gamekit/README.md の「Web 版」）"
                                      % (type(self).__name__, "、".join(missing)))
        return {"controls": sorted(set(names), key=CONTROL_NAMES.index), "pause_on_start": bool(self.pause_on_start),
                "keyboard": dict(self.web_keyboard), "touch_layout": {k: list(v) for k, v in self.web_touch_layout.items()},
                "sound_band": list(self.web_sound_band)}
    def run(self):
        if self.args.web_info:
            print("rgbkit-web-info " + json.dumps(self.web_info(), ensure_ascii=False))
            return 0
        if not self._open():
            return 1
        try:
            self._begin()
            while self.running:
                frame_start = self._frame()
                spare = 1.0 / self.fps - (time.monotonic() - frame_start)
                if spare > 0.001 and not self.args.fast:
                    self._backend.delay(spare)
            if self.checking:
                self._log_state()
        finally:
            self._finish()
        return self._exit_code
    async def run_async(self):
        import asyncio
        if not self._open():
            return 1
        try:
            self._begin()
            while self.running:
                self._frame()
                await asyncio.sleep(0)
            if self.checking:
                self._log_state()
        finally:
            self._finish()
        return self._exit_code
    def _open(self):
        self._backend = backend.current()
        self._backend.on_terminate(lambda: setattr(self, "_term", True))
        windowed = self.args.windowed or sys.platform != "linux"
        self.log("start: api=%s save=%s%s" % (os.environ.get("RGBMENU_API", "-"), self.save_dir,
                                              "（一時フォルダ。終わったら消す）" if self._temp_save else ""))
        try:
            self.gfx = self._backend.Gfx(self.title, windowed, self.font_path, vsync=not self.args.fast)
            self.input = Input()
        except (RuntimeError, OSError) as e:
            self.log("cannot start: %s" % e)
            return False
        self.sound = Sound(self.game_dir, self.log)
        if self.checking:
            self.input.now = lambda: self.frame / self.fps
        self.sound.clock = lambda: self.input.now()
        if self.args.seed is not None:
            random.seed(self.args.seed)
        self.running = True
        self._started = False
        return True
    def _begin(self):
        self.start()
        if self.command:
            self._run_command()
        self._started = True
        self._stats = _Frames(time.monotonic())
    def _frame(self):
        st = self._stats
        frame_start = time.monotonic()
        timed = not self.overlays and not self.checking
        work_start = time.perf_counter()
        dt = min(frame_start - st.last, 0.1)
        st.last = frame_start
        if self.checking:
            dt = 1.0 / self.fps
        self.input.poll()
        if self._script_end:
            self._run_script()
        if self._term:
            self.quit("sigterm")
        elif self.input.quit_requested:
            self.quit("window")
        elif self.overlays:
            self.overlays[-1].update(self.input)
        elif self.pause_on_start and self.input.tapped("start"):
            self.open_menu()
        else:
            self.update(dt)
            if self.step_seconds:
                self._run_steps(dt)
        if self.pause_sound:
            self.sound.set_paused(self.paused)
        updated = time.perf_counter()
        self.gfx.clear(self.background)
        self.draw(self.gfx)
        if self.copyright and self.scene == "title":
            self.gfx.text(WIDTH // 2, HEIGHT - 12, "(c) " + self.copyright, 20, COPYRIGHT_COLOR, align="center", valign="bottom",
                          shadow=(0, 0, 0))
        for overlay in self.overlays:
            overlay.draw(self.gfx)
        if timed and not self.overlays:
            drawn = time.perf_counter()
            work = drawn - work_start
            st.count += 1
            st.spent += work
            if work > st.worst:
                st.worst, st.worst_at = work, (st.count, self.scene, updated - work_start, drawn - updated)
            if st.count > FRAMES_START and work > st.later:
                st.later, st.later_at = work, st.count
            st.spent_update += updated - work_start
            st.spent_draw += drawn - updated
            if work > 1.0 / self.fps:
                st.late += 1
                if self.scene is not None:
                    st.late_scenes[self.scene] = st.late_scenes.get(self.scene, 0) + 1
        self.frame += 1
        if self.frame in self._state_at:
            self._log_state("state@%d" % self.frame)
        if self.frame in self._shot_at:
            base, ext = os.path.splitext(self.args.screenshot)
            self.gfx.screenshot("%s@%d%s" % (base, self.frame, ext))
        if self.args.frames is None and self._script_end:
            done = self._script_pos >= self._script_end
        else:
            done = self._last_frame and self.frame >= self._last_frame
        if done and self.running:
            if self.args.screenshot:
                self.gfx.screenshot(self.args.screenshot)
            self.quit("frames" if self.args.frames is not None else "script")
        self.gfx.present()
        return frame_start
    def _finish(self):
        started = self._started
        try:
            if started:
                self.save()
                self._backend.persist(self.save_dir)
        finally:
            self.log("quit: %s" % (self.quit_reason or "error"))
            st = self._stats if started else None
            if st and st.count:
                count = st.count
                self.log("frames: count=%d average=%.1fms worst=%.1fms update=%.1fms draw=%.1fms late=%d" % (
                    count, st.spent / count * 1000, st.worst * 1000, st.spent_update / count * 1000,
                    st.spent_draw / count * 1000, st.late))
                where = ["frames: worst_frame=%d" % st.worst_at[0]]
                if st.worst_at[1] is not None:
                    where.append("worst_scene=%s" % st.worst_at[1])
                where.append("worst_update=%.1fms worst_draw=%.1fms" % (st.worst_at[2] * 1000, st.worst_at[3] * 1000))
                if st.later_at:
                    where.append("later_worst=%.1fms later_frame=%d" % (st.later * 1000, st.later_at))
                if st.late_scenes:
                    where.append("late_scenes=%s" % ",".join("%s:%d" % item for item in sorted(st.late_scenes.items())))
                self.log(" ".join(where))
            if started and self._measured and not self.checking:
                self.log("measure: " + "; ".join("%s average=%.2fms worst=%.2fms count=%d" % (
                    t.name, t.spent / t.count * 1000, t.worst * 1000, t.count) for t in self._measured.values() if t.count))
            for close in reversed(self._closers):
                close()
            self.sound.close()
            self.gfx.close()
            if self._temp_save:
                shutil.rmtree(self._temp_save, ignore_errors=True)
