import math
import sys
from rgbkit import WIDTH, Game, g3d
import pad
BACKGROUND = (104, 146, 192)
TEXT_SIZE = 22
TEXT_COLOR = (255, 255, 255)
TEXT_SHADOW = (30, 45, 70)
TEXT_Y = (630, 664)
LABELS = (("up", "↑"), ("down", "↓"), ("left", "←"), ("right", "→"), ("a", "A"), ("b", "B"), ("x", "X"), ("y", "Y"),
          ("l1", "L1"), ("l2", "L2"), ("r1", "R1"), ("r2", "R2"), ("start", "START"))
VIEW_SIZE = 320
CAMERA_DISTANCE = 6.3
CAMERA_TILT = 30
LOOK_AT = (0.0, pad.TOP, 0.3)
BUTTONS = ("a", "b", "x", "y", "l1", "l2", "r1", "r2", "start")
DIRECTIONS = ("up", "down", "left", "right")
SOUND_VOLUME = 0.5
STICK_PARTS = {"left": "lstick", "right": "rstick"}
class Padtest(Game):
    title = "PAD TEST"
    background = BACKGROUND
    web_keyboard = {}
    web_touch_layout = {}
    web_sound_band = (300, 6000)
    def start(self):
        view = self.view = g3d.View(self, size=VIEW_SIZE)
        view.background(BACKGROUND)
        view.light((0.35, -1.0, 0.55), ambient=0.45)
        self.body = view.mesh(pad.body_shape())
        self.cylinder = view.mesh(g3d.cylinder(sides=20))
        self.cylinder_lit = view.mesh(g3d.cylinder(sides=20), lit=False)
        self.cube = view.mesh(g3d.box())
        self.cube_lit = view.mesh(g3d.box(), lit=False)
        self.dpad_center = view.mesh(g3d.box(pad.DPAD_WIDE, pad.DPAD_H, pad.DPAD_WIDE))
        self.dpad_arms = {d: view.mesh(pad.dpad_arm_shape(d)) for d in DIRECTIONS}
        self.dpad_arms_lit = {d: view.mesh(pad.dpad_arm_shape(d), lit=False) for d in DIRECTIONS}
        tilt = math.radians(CAMERA_TILT)
        self.eye = (LOOK_AT[0], LOOK_AT[1] + CAMERA_DISTANCE * math.cos(tilt),
                    LOOK_AT[2] - CAMERA_DISTANCE * math.sin(tilt))
        for name in pad.TONES:
            self.sound.load(self.sound_path(name))
        self.input.left_stick_counts = False
        self.lit = set()
        self.sticks = {side: (0.0, 0.0) for side in STICK_PARTS}
        self.enter("test")
    def controls(self):
        return {"dpad", "a", "b", "x", "y", "l1", "l2", "r1", "r2", "start", "left_stick", "right_stick"}
    def update_test(self, dt):
        inp = self.input
        lit = {name for name in BUTTONS if inp.down(name)}
        lit |= {d for d in DIRECTIONS if inp.down(d, stick=False)}
        self.sticks = {side: inp.stick(side) for side in STICK_PARTS}
        lit |= {STICK_PARTS[side] for side, (x, y) in self.sticks.items() if (x, y) != (0, 0)}
        self.lit = lit
        pressed = [name for name in BUTTONS if inp.pressed(name)]
        pressed += [d for d in DIRECTIONS if inp.pressed(d, stick=False)]
        for name in pressed:
            self.sound.play(self.sound_path(name), volume=SOUND_VOLUME)
    @staticmethod
    def sound_path(name):
        return "sounds/%s.wav" % name
    def open_menu(self):
        self.lit = set()
        self.sticks = {side: (0.0, 0.0) for side in STICK_PARTS}
        return super().open_menu()
    def draw_test(self, gfx):
        view = self.view
        lit = self.lit
        view.camera(eye=self.eye, look_at=LOOK_AT)
        view.draw(self.body)
        for name, (x, z) in pad.FACE.items():
            sink = pad.BUTTON_PRESS if name in lit else 0
            d = pad.FACE_RADIUS * 2
            self.part(name, self.cylinder, self.cylinder_lit, pad.BUTTON_COLOR,
                      pos=(x, pad.TOP + pad.BUTTON_H / 2 - sink, z), scale=(d, pad.BUTTON_H, d))
        x, z = pad.START
        sink = pad.BUTTON_PRESS / 2 if "start" in lit else 0
        self.part("start", self.cylinder, self.cylinder_lit, pad.BUTTON_COLOR,
                  pos=(x, pad.TOP + pad.BUTTON_H / 4 - sink, z),
                  scale=(pad.START_RADIUS * 2 * pad.START_STRETCH, pad.BUTTON_H / 2, pad.START_RADIUS * 2))
        x, z = pad.DPAD_CENTER
        center = (x, pad.TOP + pad.DPAD_H / 2, z)
        rot = pad.dpad_tilt(lit)
        view.draw(self.dpad_center, pos=center, rot=rot, color=pad.DPAD_COLOR)
        for d in DIRECTIONS:
            self.part(d, self.dpad_arms[d], self.dpad_arms_lit[d], pad.DPAD_COLOR, pos=center, rot=rot)
        for side, (x, z) in pad.STICKS.items():
            sx, sy = self.sticks[side]
            d = pad.STICK_RADIUS * 2
            self.part(STICK_PARTS[side], self.cylinder, self.cylinder_lit, pad.STICK_COLOR,
                      pos=(x + sx * pad.STICK_SHIFT, pad.TOP + 0.04 + pad.STICK_H / 2, z - sy * pad.STICK_SHIFT),
                      rot=(-sy * pad.STICK_TILT, 0, -sx * pad.STICK_TILT), scale=(d, pad.STICK_H, d))
        for name in pad.SHOULDERS:
            x, y, z = pad.shoulder_pos(name)
            if name in lit:
                z -= pad.SHOULDER_PRESS
            self.part(name, self.cube, self.cube_lit, pad.SHOULDER_COLOR, pos=(x, y, z),
                      scale=(pad.SHOULDER_W, pad.SHOULDER_H, pad.SHOULDER_D))
        view.show()
        (lx, ly), (rx, ry) = self.sticks["left"], self.sticks["right"]
        lines = ("L x=%+.2f y=%+.2f   R x=%+.2f y=%+.2f" % (lx, ly, rx, ry), self.pressed_text())
        for y, line in zip(TEXT_Y, lines):
            gfx.text(WIDTH // 2, y, line, TEXT_SIZE, TEXT_COLOR, align="center", valign="middle", shadow=TEXT_SHADOW)
    def pressed_text(self):
        return " ".join(label for name, label in LABELS if name in self.lit)
    def part(self, name, mesh, lit_mesh, color, **place):
        if name in self.lit:
            self.view.draw(lit_mesh, color=pad.LIT_COLOR, **place)
        else:
            self.view.draw(mesh, color=color, **place)
    def debug_state(self):
        rounded = {side: [round(v, 2) for v in xy] for side, xy in self.sticks.items()}
        return {"scene": self.scene, "lit": sorted(self.lit), "lstick": rounded["left"], "rstick": rounded["right"],
                "pressed_text": self.pressed_text(),
                "sfx": self.sound.history[-4:], "sfx_count": self.sound.played}
if __name__ == "__main__":
    sys.exit(Padtest().run())
