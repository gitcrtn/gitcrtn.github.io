from rgbkit import anim
VOLUMES = {
    "nitro": 0.7, "nitro2": 0.75, "nitro3": 0.8, "land": 0.9, "tank": 0.5, "wall": 0.7, "bump": 0.6, "spin": 0.5, "rocket": 0.6,
    "count": 0.6, "go": 0.7, "lap": 0.6, "final": 0.6, "goal": 0.7, "record": 0.7, "credit": 0.6, "gp": 0.7,
    "select": 0.4, "decide": 0.5, "back": 0.5, "buy": 0.6, "deny": 0.5,
}
LOOPS = ("engine_low", "engine_mid", "engine_high", "tire", "jet", "wind")
ENGINE_BANDS = (0.34, 0.68)
ENGINE_BACK = 0.04
ENGINE_VOLUME = (0.22, 0.38)
TIRE_VOLUME = 0.4
JET_VOLUME = 0.55
WIND_VOLUME = 0.3
HIT_GAP = 0.3
MUSIC = "music/race.ogg"
MUSIC_RACE = 0.5
MUSIC_MENU = 0.22
def path(name):
    return "sounds/%s.wav" % name
def name(path):
    return path.rsplit("/", 1)[-1].rsplit(".", 1)[0]
class Audio:
    def __init__(self, sound):
        self.sound = sound
        for each in tuple(VOLUMES) + LOOPS:
            sound.load(path(each))
        self.engines = [path(each) for each in LOOPS[:3]]
        self.changes = anim.Watch()
    def play(self, name, every=0.0):
        self.sound.play(path(name), volume=VOLUMES[name], every=every)
    def music(self, level):
        if level is None:
            self.sound.stop_music()
        elif self.sound.music != (MUSIC, level):
            self.sound.play_music(MUSIC, volume=level)
    def quiet(self):
        self.sound.stop_held()
        self.changes.reset()
    def drive(self, level, accel, drifting=False, boost=False, draft=False):
        self.sound.band(self.engines, level, edges=ENGINE_BANDS, back=ENGINE_BACK, volume=ENGINE_VOLUME[1 if accel else 0])
        self.sound.hold(path("tire"), drifting, volume=TIRE_VOLUME)
        self.sound.hold(path("jet"), boost, volume=JET_VOLUME)
        self.sound.hold(path("wind"), draft, volume=WIND_VOLUME)
    def watch(self, tanks, boost, hits, bumps, kind=1, landings=0):
        rose = self.changes.rose
        used, filled, wall, bump = rose("boost", boost), rose("tanks", tanks), rose("hits", hits), rose("bumps", bumps)
        if used:
            self.play({2: "nitro2", 3: "nitro3"}.get(kind, "nitro"))
        elif filled:
            self.play("tank")
        if rose("landings", landings):
            self.play("land")
        if wall:
            self.play("wall", every=HIT_GAP)
        elif bump:
            self.play("bump", every=HIT_GAP)
    def state(self):
        sound = self.sound
        return {"sfx": [name(each) for each in sound.history], "sfx_count": sound.played,
                "held": sorted(name(each) for each in sound.held()),
                "music": sound.music[1] if sound.music else None, "music_starts": sound.music_starts}
