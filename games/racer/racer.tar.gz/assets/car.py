import math
import random
from rgbkit import anim, g3dtop
from course import HALF_WIDTH, WALL_SIDE, wrap
LENGTH = 4.0
WIDTH = 1.8
MAX_SPEED = 65.0
ACCEL = 30.0
BRAKE = 45.0
COAST = 8.0
REVERSE_MAX = 8.0
REVERSE_ACCEL = 10.0
STEER_TIME = 0.15
TURN = 55.0
TURN_SPEED = 8.0
GRIP = 34.0
WALL_LOSS = 0.3
WALL_ANGLE = 3.0
WALL_CLEAR = 0.4
SIDE_LIMIT = WALL_SIDE - WIDTH / 2 - 0.2
GRASS_SPEED = 22.0
GRASS_DRAG = 25.0
DRIFT_MIN_SPEED = 30.0
DRIFT_END_SPEED = 20.0
DRIFT_TURN = 110.0
DRIFT_FOLLOW = 3.0
DRIFT_GRIP = 60.0
SLIP_MAX = 60.0
SLIP_DRAG = 6.0
SLIP_END = 5.0
END_TIME = 0.2
TANKS = 3
NITRO_CHARGE = 0.65
NITRO_TIME = 2.5
NITRO_BONUS = 17.0
NITRO_SPEED = MAX_SPEED + NITRO_BONUS
NITRO_SHOTS = {1: (NITRO_TIME, NITRO_BONUS), 2: (4.0, 22.0), 3: (5.5, 27.0)}
NITRO_ACCEL = 45.0
OVER_DRAG = 6.0
DRAFT_SPEED = 6.0
DRAFT_ACCEL = 8.0
DRAFT_MIN_SPEED = 30.0
DRAFT_TIME = 0.3
LAUNCH_TIME = 1.2
LAUNCH_ACCEL = 12.0
SPIN_TIME = 1.0
SPIN_GRIP = 0.4
GRAVITY = 25.0
AIR_REST = 0.3
EDGE_HIT = 1.0
FALL_LOSS = 0.5
SLOPE_PULL = 9.8
class Car:
    def __init__(self, course, spec=None):
        self.course = course
        self.equip(spec)
        self.place(0.0)
    def equip(self, spec):
        self.max_speed = spec.max_speed if spec else MAX_SPEED
        self.accel = spec.accel if spec else ACCEL
        self.drift_turn = spec.drift_turn if spec else DRIFT_TURN
        self.drift_follow = spec.drift_follow if spec else DRIFT_FOLLOW
        self.nitro_speed = self.max_speed + NITRO_BONUS
    def place(self, dist, side=0.0, speed=0.0):
        self.x, self.z, self.angle, self.segment = self.course.place(dist, side)
        self.travel = self.angle
        self.drifting = False
        self.settled = 0.0
        self.tanks = 0
        self.gauge = 0.0
        self.boost = 0.0
        self.kind = 0
        self.shot = NITRO_TIME
        self.boosts = 0
        self.draft = False
        self.behind = 0.0
        self.launch = 0.0
        self.spin = 0.0
        self.speed = speed
        self.steer = 0.0
        self.dist = dist % self.course.total
        self.side = side
        self.touching = False
        self.hits = 0
        self.y = self.course.height(self.dist)
        self.vy = 0.0
        self.air = False
        self.landings = 0
        self.rest = 0.0
        self.grade = self.course.slope(self.dist)
        self.flight = 0.0
        self.peak = 0.0
        self.falls = 0
        self.last = (self.x, self.z, self.segment, self.dist, self.side)
        self.pitch = 0.0
    def start(self, kind):
        self.launch = LAUNCH_TIME if kind == "rocket" else 0.0
        self.spin = SPIN_TIME if kind == "spin" else 0.0
    def box(self):
        return (self.x, self.z, LENGTH / 2, WIDTH / 2, self.angle)
    @property
    def grass(self):
        return abs(self.side) > HALF_WIDTH
    @property
    def slip(self):
        return wrap(self.angle - self.travel)
    def step(self, dt, steer, accel, brake, drift=False, nitro=False, behind=False, reverse=False):
        self.last = (self.x, self.z, self.segment, self.dist, self.side)
        count = 0 if reverse or self.speed < 0.0 else int(nitro)
        if count and self.tanks >= count and self.boost <= 0.0:
            self.tanks -= count
            self.shot, bonus = NITRO_SHOTS[count]
            self.boost, self.kind = self.shot, count
            self.nitro_speed = self.max_speed + bonus
            self.boosts += 1
        self.behind = self.behind + dt if behind and self.speed >= DRAFT_MIN_SPEED and not self.grass else 0.0
        self.draft = self.behind >= DRAFT_TIME - 1e-9
        self.launch = max(0.0, self.launch - dt)
        self.spin = max(0.0, self.spin - dt)
        thrust = self.boost > 0.0
        self.boost = max(0.0, self.boost - dt)
        if self.boost <= 0.0:
            self.kind = 0
        surface = self.course.surface
        self.steer = anim.approach(self.steer, steer, dt / STEER_TIME)
        if self.air:
            self.x, self.z = g3dtop.world(self.x, self.z, self.travel, self.speed * dt, 0.0)
            hit, pushed = self._walls()
            if pushed:
                self.drifting = False
            if not self.drifting:
                self.angle = self.travel
            self._rise(dt)
            return hit
        if drift and not reverse and not self.drifting and steer and self.speed >= surface.drift_min:
            self.drifting, self.settled = True, 0.0
        if self.grass and self.speed > GRASS_SPEED:
            self.speed = max(GRASS_SPEED, self.speed - GRASS_DRAG * dt)
            accel = thrust = False
        top = (self.nitro_speed if thrust else self.max_speed) * surface.speed + (DRAFT_SPEED if self.draft else 0.0)
        if reverse:
            if self.speed > 0.0:
                self.speed = max(0.0, self.speed - BRAKE * dt)
            else:
                self.speed = max(-REVERSE_MAX, self.speed - REVERSE_ACCEL * dt)
        elif self.speed < 0.0:
            self.speed = min(0.0, self.speed + (BRAKE if (accel or brake or thrust) else COAST) * dt)
        elif brake:
            self.speed = max(0.0, self.speed - BRAKE * dt)
        elif thrust or accel:
            if self.speed > top:
                self.speed = max(top, self.speed - OVER_DRAG * dt)
            else:
                push = (NITRO_ACCEL if thrust else self.accel) * surface.accel * max(0.0, 1.05 - self.speed / top)
                if self.spin > 0.0:
                    push *= SPIN_GRIP
                elif self.launch > 0.0:
                    push += LAUNCH_ACCEL
                self.speed = min(top, self.speed + (push + (DRAFT_ACCEL if self.draft else 0.0)) * dt)
        else:
            self.speed = max(0.0, self.speed - COAST * dt)
        if self.course.hilly and self.speed >= 0.0:
            before = self.speed
            self.speed = max(0.0, self.speed - SLOPE_PULL * self.course.slope(self.dist) * dt)
            if self.speed > before:
                self.speed = min(self.speed, max(before, top))
        if self.drifting:
            self._drift(dt)
        else:
            turn = TURN * min(1.0, self.speed / TURN_SPEED)
            if self.speed > 1.0:
                turn = min(turn, math.degrees(surface.grip / self.speed))
            self.travel = (self.travel + self.steer * turn * dt) % 360.0
        self.x, self.z = g3dtop.world(self.x, self.z, self.travel, self.speed * dt, 0.0)
        hit, pushed = self._walls()
        if pushed:
            self.drifting = False
        if not self.drifting:
            self.angle = self.travel
        self._rise(dt)
        return hit
    def _rise(self, dt):
        course = self.course
        hole = course.hole(self.dist)
        ground = course.floor if hole else course.height(self.dist)
        grade, before = course.slope(self.dist), self.grade
        self.grade = grade
        self.rest = max(0.0, self.rest - dt)
        if self.air:
            self.y += self.vy * dt - 0.5 * GRAVITY * dt * dt
            self.vy -= GRAVITY * dt
            self.flight += dt
            self.peak = max(self.peak, self.y - ground)
            if not hole and self.y < ground - EDGE_HIT and course.hole(self.last[3]):
                self.x, self.z, self.segment, self.dist, self.side = self.last
                self.speed = 0.0
            elif self.y <= ground:
                if hole:
                    self._fall()
                self.y, self.air, self.vy = ground, False, 0.0
                self.landings += 1
                self.rest = AIR_REST
        elif hole:
            self.air, self.vy = True, before * self.speed
            self.flight, self.peak = 0.0, 0.0
        elif course.hilly and self.rest <= 0.0 and (before - grade) * self.speed > GRAVITY * dt:
            self.air = True
            self.vy = before * self.speed
            self.y = ground
            self.flight, self.peak = 0.0, 0.0
        else:
            self.y, self.vy = ground, grade * self.speed
        self.pitch = math.degrees(math.atan2(self.vy, max(1.0, self.speed))) if self.air \
            else math.degrees(math.atan(self.course.slope(self.dist)))
    def _fall(self):
        course = self.course
        self.x, self.z, self.segment, self.dist, self.side, _, _ = course.clamp(self.x, self.z, SIDE_LIMIT, course.lower_segment)
        self.travel = self.angle = random.uniform(0.0, 360.0)
        self.speed *= FALL_LOSS
        self.drifting = False
        self.grade = course.slope(self.dist)
        self.falls += 1
    def _drift(self, dt):
        slip = self.slip + self.steer * self.drift_turn * dt
        follow = min(abs(slip) * self.drift_follow * self.course.surface.follow, math.degrees(DRIFT_GRIP / self.speed)) * dt
        follow = min(follow, abs(slip))
        self.travel = (self.travel + (follow if slip > 0 else -follow)) % 360.0
        slip = max(-SLIP_MAX, min(SLIP_MAX, slip - (follow if slip > 0 else -follow)))
        self.angle = (self.travel + slip) % 360.0
        self.speed = max(0.0, self.speed - SLIP_DRAG * abs(slip) / SLIP_MAX * dt)
        if self.boost <= 0.0 and not self.grass and self.tanks < TANKS:
            self.gauge += NITRO_CHARGE * abs(slip) / SLIP_MAX * min(1.0, self.speed / self.max_speed) * dt
            if self.gauge >= 1.0:
                self.tanks += 1
                self.gauge = self.gauge - 1.0 if self.tanks < TANKS else 0.0
        self.settled = self.settled + dt if abs(slip) < SLIP_END else 0.0
        if self.settled >= END_TIME or self.speed < DRIFT_END_SPEED:
            self.drifting = False
    def _walls(self):
        self.x, self.z, self.segment, self.dist, self.side, heading, over = self.course.clamp(
            self.x, self.z, SIDE_LIMIT, self.segment)
        if over <= 0.0:
            if abs(self.side) < SIDE_LIMIT - WALL_CLEAR:
                self.touching = False
            return False, False
        sign = 1.0 if self.side > 0 else -1.0
        back = 180.0 if self.speed < 0.0 else 0.0
        motion = self.travel + back
        along = heading if abs(wrap(motion - heading)) <= 90.0 else heading + 180.0
        toward = wrap(motion - along) * sign * (1.0 if along == heading else -1.0)
        if toward > -WALL_ANGLE:
            away = -sign if along == heading else sign
            self.travel = (along + away * WALL_ANGLE - back) % 360.0
        if self.touching:
            return False, True
        self.touching = True
        self.hits += 1
        self.speed *= 1.0 - WALL_LOSS
        return True, True
