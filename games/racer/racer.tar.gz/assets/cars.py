from rgbkit import g3d
BODY, GLASS, DARK = (255, 255, 255), (70, 90, 120), (40, 40, 45)
class Spec:
    def __init__(self, name, price, max_speed, accel, drift_turn, drift_follow, color, parts, note):
        self.name, self.price = name, price
        self.max_speed = max_speed
        self.accel = accel
        self.drift_turn = drift_turn
        self.drift_follow = drift_follow
        self.color = color
        self.parts = parts
        self.note = note
    def shape(self):
        whole = g3d.Shape([], [])
        for center, size, color in self.parts:
            whole.add(g3d.box(*size), pos=center, color=color)
        return whole
def wheels(side, front, back, size=(0.25, 0.60, 0.75)):
    return [((x, size[1] / 2, z), size, DARK) for z in (front, back) for x in (-side, side)]
CARS = [
    Spec("ルーキー", 0, 65.0, 30.0, 110.0, 3.0, (225, 50, 45), [
        ((0.0, 0.50, 0.0), (1.8, 0.50, 4.0), BODY),
        ((0.0, 0.95, -0.3), (1.5, 0.42, 1.9), GLASS),
        ((0.0, 0.80, -1.85), (1.8, 0.10, 0.5), DARK),
    ] + wheels(0.85, 1.25, -1.25), "くせの無い、最初の車"),
    Spec("スライダー", 5000, 66.0, 33.0, 140.0, 2.2, (245, 200, 40), [
        ((0.0, 0.55, 0.0), (1.7, 0.55, 3.4), BODY),
        ((0.0, 1.07, -0.45), (1.5, 0.50, 2.1), GLASS),
        ((0.0, 1.36, -1.40), (1.5, 0.08, 0.35), BODY),
    ] + wheels(0.80, 1.05, -1.05), "すべりやすい。ニトロが、たまりやすい"),
    Spec("ダッシュ", 12000, 68.0, 44.0, 90.0, 3.8, (50, 110, 235), [
        ((0.0, 0.44, 0.0), (1.95, 0.40, 4.0), BODY),
        ((0.0, 0.80, -0.15), (1.5, 0.32, 1.6), GLASS),
        ((0.0, 0.70, -1.80), (1.95, 0.08, 0.45), DARK),
    ] + wheels(0.93, 1.30, -1.30, (0.28, 0.56, 0.75)), "加速が、するどい。すべりにくい"),
    Spec("ファントム", 25000, 72.0, 38.0, 125.0, 2.6, (120, 70, 190), [
        ((0.0, 0.50, -0.90), (1.85, 0.50, 2.2), BODY),
        ((0.0, 0.40, 1.05), (1.85, 0.30, 1.9), BODY),
        ((0.0, 0.90, -0.65), (1.4, 0.32, 1.5), GLASS),
        ((-0.75, 0.95, -1.80), (0.10, 0.40, 0.25), DARK), ((0.75, 0.95, -1.80), (0.10, 0.40, 0.25), DARK),
        ((0.0, 1.18, -1.80), (1.95, 0.08, 0.60), DARK),
    ] + wheels(0.88, 1.30, -1.25), "最高速が、いちばん高い"),
]
class Part:
    def __init__(self, key, name, count, button, lines):
        self.key, self.name, self.count, self.button, self.lines = key, name, count, button, lines
PARTS = [
    Part("double", "ダブルニトロ", 2, "R2", ["2 本を、まとめて使う", "4.0 秒　+22 m/s", "（1 本は 2.5 秒 +17）", "どの車でも、使える"]),
    Part("triple", "トリプルニトロ", 3, "L2", ["3 本を、まとめて使う", "5.5 秒　+27 m/s", "長い直線で使う", "ダブルニトロが要る"]),
]
