import bisect
import math
import random
from rgbkit import g3d, g3dpath
import courses
from rgbkit.g3dpath import wrap
HALF_WIDTH = 7.0
WALL_SIDE = 14.0
GROUND_Y = -0.2
WALL_HEIGHT = 1.2
SPACING = 5.0
CHUNK = 30
ROAD_TILE = 10.0
WALL_TILE = 10.0
SKIRT_MIN, SKIRT_SLOPE = 3.0, 1.4
CONCRETE = (172, 170, 164)
LAYOUT = courses.CITY_LAYOUT
class Course(g3dpath.Path):
    def __init__(self, layout=LAYOUT, surface=None, profile=None, cross=None):
        built = g3dpath.Path.from_parts(layout, spacing=SPACING)
        self.surface = surface or courses.PAVED
        super().__init__(built.points)
        self.layout = built.parts
        self.gap, self.turned = built.gap, built.turned
        points = profile or [(0.0, 0.0), (1.0, 0.0)]
        self.profile = [(point[0] * self.total, point[1]) for point in points]
        self.corners = [len(point) > 2 and point[2] == courses.EDGE for point in points]
        self.marks = [dist for dist, _ in self.profile]
        self.hilly = any(height for _, height in self.profile)
        self.cross = cross
        if cross:
            lx, lz, _, self.lower_segment = self.place(cross[1], 0.0)
            self.floor = self.height(cross[1])
    def hole(self, dist):
        if not self.cross:
            return False
        off = abs(dist % self.total - self.cross[0])
        return min(off, self.total - off) < self.cross[2]
    def ground(self, dist):
        return self.floor if self.hole(dist) else self.height(dist)
    def over(self, i):
        return self.hole(self.start[i % self.count])
    def _span(self, dist):
        dist %= self.total
        k = max(0, min(len(self.profile) - 2, bisect.bisect_right(self.marks, dist) - 1))
        (d0, h0), (d1, h1) = self.profile[k], self.profile[k + 1]
        shape = (1 if self.corners[k + 1] else 0) + (2 if self.corners[k] else 0)
        return h0, h1 - h0, d1 - d0, (dist - d0) / (d1 - d0), shape
    def height(self, dist):
        h0, rise, _, u, shape = self._span(dist)
        return h0 + rise * (u * u * (3.0 - 2.0 * u), u * u, u * (2.0 - u), u)[shape]
    def bend(self, dist):
        _, rise, length, u, shape = self._span(dist)
        return rise * (6.0 * (1.0 - 2.0 * u), 2.0, -2.0, 0.0)[shape] / (length * length)
    def slope(self, dist):
        _, rise, length, u, shape = self._span(dist)
        return rise * (6.0 * u * (1.0 - u), 2.0 * u, 2.0 * (1.0 - u), 1.0)[shape] / length
    def edges(self, i, side):
        x, z, heading = self.points[i % self.count]
        a = math.radians(heading)
        return x + math.cos(a) * side, z - math.sin(a) * side
    def chunks(self):
        result = []
        for first in range(0, self.count, CHUNK):
            last = min(first + CHUNK, self.count)
            road_v, road_f, road_uv = [], [], []
            wall_v, wall_f, wall_uv = [], [], []
            along = 0.0
            side_v, side_f = [], []
            for i in range(first, last + 1):
                lx, lz = self.edges(i, -HALF_WIDTH)
                rx, rz = self.edges(i, HALF_WIDTH)
                wlx, wlz = self.edges(i, -WALL_SIDE)
                wrx, wrz = self.edges(i, WALL_SIDE)
                y = self.height(self.start[i % self.count])
                v = along / ROAD_TILE
                road_v += [(lx, y, lz), (rx, y, rz)]
                road_uv += [(0.0, -v), (1.0, -v)]
                u = along / WALL_TILE
                wall_v += [(wlx, y + GROUND_Y, wlz), (wlx, y + WALL_HEIGHT, wlz), (wrx, y + GROUND_Y, wrz), (wrx, y + WALL_HEIGHT, wrz)]
                if self.hilly:
                    reach = WALL_SIDE + SKIRT_MIN + y * SKIRT_SLOPE
                    flx, flz = self.edges(i, -reach)
                    frx, frz = self.edges(i, reach)
                    low = y + GROUND_Y
                    side_v += [(flx, GROUND_Y, flz), (wlx, low, wlz), (lx, low, lz),
                               (rx, low, rz), (wrx, low, wrz), (frx, GROUND_Y, frz)]
                wall_uv += [(u, 1.0), (u, 0.0), (-u, 1.0), (-u, 0.0)]
                along += self.length[i % self.count]
            for k in range(last - first):
                if self.over(first + k) or self.over(first + k + 1):
                    continue
                a, b = k * 2, k * 2 + 2
                road_f.append((a, a + 1, b + 1, b))
                a, b = k * 4, k * 4 + 4
                wall_f.append((a, b, b + 1, a + 1))
                wall_f.append((b + 2, a + 2, a + 3, b + 3))
                if self.hilly:
                    a, b = k * 6, k * 6 + 6
                    for n in (0, 1, 3, 4):
                        side_f.append((a + n, a + n + 1, b + n + 1, b + n))
            side = g3d.Shape(side_v, side_f) if side_f else None
            result.append((g3d.Shape(road_v, road_f, uvs=road_uv), g3d.Shape(wall_v, wall_f, uvs=wall_uv), side))
        return result
    def bridge(self):
        if not self.cross:
            return None
        shape = g3d.Shape([], [])
        for i in range(self.count):
            if self.over(i) == self.over(i + 1):
                continue
            end = i if self.over(i + 1) else i + 1
            y = self.height(self.start[end % self.count])
            reach = WALL_SIDE + SKIRT_MIN + y * SKIRT_SLOPE
            (lx, lz), (wlx, wlz) = self.edges(end, -reach), self.edges(end, -WALL_SIDE)
            (wrx, wrz), (rx, rz) = self.edges(end, WALL_SIDE), self.edges(end, reach)
            top = y + GROUND_Y
            face = g3d.Shape([(lx, GROUND_Y, lz), (wlx, top, wlz), (wrx, top, wrz), (rx, GROUND_Y, rz)],
                             [(0, 1, 2, 3), (3, 2, 1, 0)])
            shape.add(face, color=CONCRETE)
        return shape
    def scenery(self, seed=7, style=None):
        style = style or courses.CITY_SCENERY
        rng = random.Random(seed)
        palette = style["palette"]
        groups = {}
        def add(group, x, y, z, w, h, d, heading, color):
            groups.setdefault(group, g3d.Shape([], [])).add(_box(w, h, d), pos=(x, y, z), rot=(0, heading, 0), color=color)
        dist, turn = 40.0, 0
        while dist < self.total - 20.0:
            side = (1 if turn % 2 else -1) * (WALL_SIDE + rng.uniform(14.0, 28.0))
            w, h, d = rng.uniform(*style["size"]), rng.uniform(*style["height"]), rng.uniform(*style["size"])
            x, z, heading, i = self.place(dist, side)
            reach = math.hypot(w, d) / 2 + WALL_SIDE + 3.0
            if all(math.hypot(px - x, pz - z) > reach for px, pz, _ in self.points):
                add(i // CHUNK, x, h / 2, z, w, h, d, heading, rng.choice(palette))
            dist += rng.uniform(35.0, 60.0)
            turn += 1
        x, z, heading = self.points[0]
        for side in (-WALL_SIDE - 0.6, WALL_SIDE + 0.6):
            add(0, x + side, 3.5, z, 1.0, 7.0, 1.0, heading, (230, 230, 235))
        add(0, x, 7.6, z, WALL_SIDE * 2 + 2.2, 1.4, 1.0, heading, style["gate"])
        add(0, x, 0.005, z, HALF_WIDTH * 2, 0.01, 1.2, heading, (245, 245, 245))
        return list(groups.values())
def _box(w, h, d):
    box = g3d.box(w, h, d)
    box.faces = box.faces[:5]
    return box
