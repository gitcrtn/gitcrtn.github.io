EDGE = "edge"
class Surface:
    def __init__(self, name, grip, drift_min, follow, speed, accel, rival_grip, dust):
        self.name = name
        self.grip = grip
        self.drift_min = drift_min
        self.follow = follow
        self.speed = speed
        self.accel = accel
        self.rival_grip = rival_grip
        self.dust = dust
PAVED = Surface("paved", 34.0, 30.0, 1.0, 1.0, 1.0, 40.0, False)
DIRT = Surface("dirt", 26.0, 24.0, 0.8, 0.92, 0.9, 30.0, True)
class Track:
    def __init__(self, index, name, layout, surface, sky, ground, road, wall, scenery, note, profile=None, cross=None):
        self.index, self.name, self.layout, self.surface = index, name, layout, surface
        self.profile = profile
        self.cross = cross
        self.sky, self.ground = sky, ground
        self.road = road
        self.wall = wall
        self.scenery = scenery
        self.note = note
CITY_LAYOUT = [
    ("s", 250.0),
    ("c", 110.0, 90.0),
    ("s", 120.0),
    ("c", 70.0, 90.0),
    ("s", 350.0),
    ("c", 50.0, -90.0),
    ("s", None),
    ("c", 32.0, 180.0),
    ("s", 180.0),
    ("c", 60.0, -60.0),
    ("c", 60.0, 60.0),
    ("s", 150.0),
    ("c", 90.0, 90.0),
    ("s", None),
]
DIRT_LAYOUT = [
    ("s", 230.0),
    ("c", 60.0, 100.0),
    ("s", 90.0),
    ("c", 40.0, -110.0),
    ("s", 140.0),
    ("c", 52.0, 190.0),
    ("s", None),
    ("c", 34.0, -80.0),
    ("s", 100.0),
    ("c", 62.0, 170.0),
    ("s", None),
    ("c", 80.0, 90.0),
]
CROSS_LAYOUT = [
    ("s", 200.0),
    ("c", 100.0, 90.0),
    ("s", 60.0),
    ("c", 100.0, 90.0),
    ("s", 460.0),
    ("c", 100.0, -90.0),
    ("s", 200.0),
    ("c", 100.0, -90.0),
    ("s", 60.0),
    ("c", 100.0, -90.0),
    ("s", 460.0),
    ("c", 100.0, 90.0),
]
MOUNTAIN_LAYOUT = [
    ("s", 240.0),
    ("c", 60.0, 90.0),
    ("s", 420.0),
    ("c", 60.0, 90.0),
    ("s", 300.0),
    ("c", 30.0, 180.0),
    ("s", 200.0),
    ("c", 30.0, -180.0),
    ("s", 200.0),
    ("c", 30.0, 180.0),
    ("s", 100.0),
    ("c", 50.0, -90.0),
    ("s", None),
    ("c", 50.0, -90.0),
    ("s", None),
    ("c", 60.0, 180.0),
    ("s", 80.0),
]
MOUNTAIN_PROFILE = [(0.0, 0.0), (0.03, 0.0), (0.30, 35.0), (0.315, 36.5), (0.334, 38.5, EDGE), (0.353, 36.5),
                    (0.55, 24.0), (0.75, 10.0), (0.95, 0.0), (1.0, 0.0)]
DIRT_LENGTH = 1963.7
DIRT_GROUND = [(0, 0.0), (240, 0.0), (330, 1.5), (430, 1.5), (500, 3.0), (650, 3.0), (800, 1.0), (1190, 1.0),
               (1230, 2.0), (1340, 2.0), (1510, 0.5), (1850, 0.5), (1960, 0.0)]
DIRT_BUMPS = [(150, 1.0), (375, 1.0), (565, 1.2), (870, 1.0), (990, 1.2), (1110, 1.0), (1285, 1.0),
              (1570, 1.2), (1680, 1.0), (1770, 1.0)]
def with_bumps(ground, bumps, length):
    points = [(dist, height) for dist, height in ground]
    for top, rise in bumps:
        base = [height for dist, height in ground if dist <= top][-1]
        reach = rise / 0.059
        points += [(top - reach, base), (top, base + rise, EDGE), (top + reach, base)]
    points.sort(key=lambda point: point[0])
    return [(point[0] / length,) + tuple(point[1:]) for point in points] + [(1.0, 0.0)]
DIRT_PROFILE = with_bumps(DIRT_GROUND, DIRT_BUMPS, DIRT_LENGTH)
CROSS_LENGTH = 2382.4
CROSS_UPPER, CROSS_LOWER = 2065.3, 874.1
JUMP_GAP = 15.0
JUMP_LIP, JUMP_LAND = CROSS_UPPER - JUMP_GAP, CROSS_UPPER + JUMP_GAP
CROSS_PROFILE = [(point[0] / CROSS_LENGTH,) + tuple(point[1:]) for point in [
    (0.0, 0.0), (JUMP_LIP - 240.0, 0.0), (JUMP_LIP, 12.0, EDGE), (JUMP_LAND, 9.5, EDGE), (JUMP_LAND + 160.0, 0.0),
    (CROSS_LENGTH, 0.0)]]
CITY_ROAD = (["ww" + "a" * 13 + "ww" + "a" * 13 + "ww"] * 8 + ["ww" + "b" * 28 + "ww"] * 8,
             {"a": (88, 90, 98), "b": (80, 82, 90), "w": (225, 225, 220)})
DIRT_ROAD = (["eaaabbaaaaaaaaaaaaaaaaaaaabbaaae", "eaaabbaaaaaacaaaaaaaaaaaaabbaaae"] * 4
             + ["eaaabbaaaaaaaaaaaaaacaaaaabbaaae", "eaaabbaaaaaaaaaaaaaaaaaaaabbaaae"] * 4,
             {"a": (150, 112, 74), "b": (124, 90, 58), "c": (170, 132, 92), "e": (110, 96, 64)})
CITY_WALL = (["rrrrwwww"] * 8, {"r": (210, 60, 50), "w": (235, 235, 235)})
DIRT_WALL = (["kkkkkkkk", "ffffffff", "ffffffff", "kkkkkkkk", "ffffffff", "ffffffff", "kkkkkkkk", "pfffffff"],
             {"k": (96, 64, 40), "f": (150, 110, 70), "p": (80, 52, 32)})
HIGHWAY_WALL = (["cccccccc", "cccccccc", "yyyykkkk", "cccccccc", "cccccccc", "cccccccc", "dddddddd", "dddddddd"],
                {"c": (196, 192, 184), "d": (150, 146, 140), "y": (240, 190, 60), "k": (60, 60, 64)})
MOUNTAIN_WALL = (["wwwwwwww", "ssssssss", "wwwwwwww", "kkkkkkkk"] * 2, {"w": (220, 224, 228), "s": (150, 156, 164), "k": (90, 96, 104)})
CITY_SCENERY = {"palette": [(150, 160, 175), (190, 180, 160), (120, 135, 160), (170, 150, 140), (200, 200, 205)],
                "size": (10.0, 18.0), "height": (8.0, 34.0), "gate": (220, 60, 50)}
CROSS_SCENERY = {"palette": [(110, 96, 110), (150, 120, 110), (90, 90, 112), (170, 140, 120), (126, 110, 128)],
                 "size": (12.0, 22.0), "height": (12.0, 46.0), "gate": (240, 150, 50)}
MOUNTAIN_SCENERY = {"palette": [(96, 116, 92), (110, 124, 104), (128, 132, 128), (84, 104, 80)],
                    "size": (24.0, 44.0), "height": (18.0, 60.0), "gate": (60, 120, 200)}
DIRT_SCENERY = {"palette": [(96, 120, 70), (120, 104, 80), (84, 104, 64), (140, 124, 96)],
                "size": (6.0, 14.0), "height": (3.0, 12.0), "gate": (150, 100, 50)}
TRACKS = {
    0: Track(0, "シティサーキット", CITY_LAYOUT, PAVED, (150, 195, 235), (86, 140, 82), CITY_ROAD, CITY_WALL, CITY_SCENERY,
             "平ら。ヘアピンと、S 字"),
    1: Track(1, "クロスハイウェイ", CROSS_LAYOUT, PAVED, (236, 168, 120), (96, 110, 78), CITY_ROAD, HIGHWAY_WALL, CROSS_SCENERY,
             "立体交差と、ジャンプ台", CROSS_PROFILE, cross=(CROSS_UPPER, CROSS_LOWER, JUMP_GAP)),
    2: Track(2, "マウンテンパス", MOUNTAIN_LAYOUT, PAVED, (138, 186, 236), (92, 128, 90), CITY_ROAD, MOUNTAIN_WALL, MOUNTAIN_SCENERY,
             "高低差 40 m。つづら折り", MOUNTAIN_PROFILE),
    3: Track(3, "ダートトレイル", DIRT_LAYOUT, DIRT, (226, 206, 168), (150, 132, 92), DIRT_ROAD, DIRT_WALL, DIRT_SCENERY,
             "土の道。すべりやすい", DIRT_PROFILE),
}
ORDER = sorted(TRACKS)
COUNT = 4
