import math
from rgbkit import anim, g3dfx, g3dtop, gfxfx
SMOKE_EVERY = 2
WHEEL_BACK = -1.25
WHEEL_SIDE = 0.85
NOZZLE = -2.05
NOZZLE_HEIGHT = 0.55
def flame(view):
    return g3dfx.Jet(view, [(0.9, 0.42, 1.5, 0.6, (255, 140, 30)), (0.5, 0.26, 2.4, 1.0, (255, 240, 170))])
def draw_flame(jet, car, time):
    if car.boost > 0.0:
        x, z = g3dtop.world(car.x, car.z, car.angle, NOZZLE, 0.0)
        jet.draw((x, getattr(car, "y", 0.0) + NOZZLE_HEIGHT, z), car.angle, time)
def wind():
    return gfxfx.SpeedLines(count=16, center=(360, 330), inner=150, outer=520, speed=1100.0, length=(40, 140),
                            color=(255, 255, 255), thick=0.4, width=2)
class Smoke:
    def __init__(self, view):
        self.puffs = g3dfx.Puffs(view, life=0.6, limit=40, rise=1.6, vary=(0.6, 1.3),
                                 size=anim.Curve([(0.0, 0.5), (0.6, 1.7), (1.0, 0.0)]),
                                 color=anim.Curve([(0.0, (240, 240, 245)), (1.0, (190, 190, 195))]))
        self.count = 0
    def __len__(self):
        return len(self.puffs)
    def clear(self):
        self.puffs.clear()
    def step(self, dt, car):
        self.puffs.step(dt)
        if not (car.drifting or car.spin > 0.0):
            return
        self.count += 1
        if self.count % SMOKE_EVERY:
            return
        size = 0.55 + 0.6 * min(1.0, abs(car.slip) / 40.0)
        for side in (-WHEEL_SIDE, WHEEL_SIDE):
            x, z = g3dtop.world(car.x, car.z, car.angle, WHEEL_BACK, side)
            self.puffs.emit((x, getattr(car, "y", 0.0) + 0.25, z), size=size, spread=0.3)
    def burst(self, car):
        for front in (WHEEL_BACK, -WHEEL_BACK):
            for side in (-WHEEL_SIDE, WHEEL_SIDE):
                x, z = g3dtop.world(car.x, car.z, car.angle, front, side)
                self.puffs.emit((x, getattr(car, "y", 0.0) + 0.2, z), size=0.9, spread=0.5)
    def draw(self):
        self.puffs.draw()
DUST_SPEED = 30.0
DUST_EVERY = 4
SHAKE = 0.05
class Dust:
    def __init__(self, view):
        self.puffs = g3dfx.Puffs(view, life=0.9, limit=40, rise=0.8, vary=(0.7, 1.4),
                                 size=anim.Curve([(0.0, 0.4), (0.5, 1.1), (1.0, 0.0)]),
                                 color=anim.Curve([(0.0, (196, 164, 118)), (1.0, (172, 146, 108))]))
        self.count = 0
    def __len__(self):
        return len(self.puffs)
    def clear(self):
        self.puffs.clear()
    def step(self, dt, car, surface):
        self.puffs.step(dt)
        if not surface.dust or car.speed < DUST_SPEED:
            return
        self.count += 1
        if self.count % DUST_EVERY:
            return
        size = 0.5 + (0.4 if car.drifting else 0.0)
        for side in (-WHEEL_SIDE, WHEEL_SIDE):
            x, z = g3dtop.world(car.x, car.z, car.angle, WHEEL_BACK, side)
            self.puffs.emit((x, getattr(car, "y", 0.0) + 0.2, z), size=size, spread=0.4)
    def burst(self, car):
        for front in (WHEEL_BACK, -WHEEL_BACK):
            for side in (-WHEEL_SIDE, WHEEL_SIDE):
                x, z = g3dtop.world(car.x, car.z, car.angle, front, side)
                self.puffs.emit((x, getattr(car, "y", 0.0) + 0.2, z), size=0.9, spread=0.5)
    def draw(self):
        self.puffs.draw()
def shake(time, speed, top):
    amount = SHAKE * min(1.0, speed / top)
    return amount * (math.sin(time * 31.0) * 0.6 + math.sin(time * 53.0 + 1.3) * 0.4)
