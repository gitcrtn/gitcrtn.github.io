from rgbkit import Inventory
REWARDS = (1000, 600, 400, 250, 150, 100)
LIMIT = 999999
CARS = 4
FILE = "garage.json"
NAMES = ["car%d" % n for n in range(CARS)]
PARTS = [("double", 3000), ("triple", 8000, "double")]
GP_WORST = 6
EMPTY = {"money": 0, "owned": [], "using": [], "gp_best": 0}
SCHEMA = {"money": (int, 0, LIMIT), "owned": [str], "using": [str], "gp_best": (int, 0, GP_WORST)}
def reward(rank):
    return REWARDS[rank - 1] if 1 <= rank <= len(REWARDS) else 0
def migrate(data):
    if not isinstance(data, dict) or "money" in data:
        return data
    flags = data.get("owned")
    if not (set(data) & {"credits", "car", "double", "triple"} or (isinstance(flags, list) and any(isinstance(flag, bool) for flag in flags))):
        return data
    owned = [NAMES[n] for n, flag in enumerate(flags[:CARS]) if flag is True] if isinstance(flags, list) else []
    owned += [part for part in ("double", "triple") if data.get(part) is True]
    car = data.get("car")
    using = [NAMES[car]] if isinstance(car, int) and not isinstance(car, bool) and 0 <= car < CARS else []
    return {"money": data.get("credits", 0), "owned": owned, "using": using}
class Garage:
    def __init__(self, data=None, prices=None, game=None):
        prices = list(prices or [0] * CARS)
        data = dict(data or {})
        best = data.get("gp_best", 0)
        self.gp_best = best if isinstance(best, int) and not isinstance(best, bool) and 0 <= best <= GP_WORST else 0
        self.inv = Inventory(game, list(zip(NAMES, prices)) + PARTS, name=FILE, owned=[NAMES[0]], groups={"car": NAMES},
                             limit=LIMIT, data=migrate(data))
    @property
    def credits(self):
        return self.inv.money
    @credits.setter
    def credits(self, value):
        self.inv.money = max(0, min(LIMIT, int(value)))
    @property
    def owned(self):
        return [self.inv.owned(name) for name in NAMES]
    @property
    def car(self):
        return NAMES.index(self.inv.using("car"))
    @property
    def double(self):
        return self.inv.owned("double")
    @property
    def triple(self):
        return self.inv.owned("triple")
    def data(self):
        return dict(self.inv.data(), gp_best=self.gp_best)
    def save(self):
        return self.inv.game.save_json(FILE, self.data())
    def record_gp(self, place):
        if self.gp_best and self.gp_best <= place:
            return False
        self.gp_best = place
        return True
    def with_all_cars(self):
        data = self.data()
        prices = [self.inv.price(name) for name in NAMES]
        return Garage(dict(data, owned=NAMES + [name for name in data["owned"] if name not in NAMES]), prices, self.inv.game)
    def can_buy(self, index):
        return self.inv.can_buy(NAMES[index])
    def buy(self, index):
        return self.inv.buy(NAMES[index])
    def ride(self, index):
        return self.inv.use("car", NAMES[index])
    def has(self, key):
        return self.inv.owned(key)
    def can_buy_part(self, key):
        return self.inv.can_buy(key)
    def buy_part(self, key):
        return self.inv.buy(key, use=False)
    def price(self, key):
        return self.inv.price(key)
    def needs(self, key):
        return [need for need in self.inv.items[key][1] if not self.inv.owned(need)]
    def with_parts(self, count):
        data = self.data()
        keep = [name for name in data["owned"] if name in NAMES]
        prices = [self.inv.price(name) for name in NAMES]
        return Garage(dict(data, owned=keep + ["double", "triple"][:count]), prices, self.inv.game)
    def earn(self, amount):
        return self.inv.earn(amount)
