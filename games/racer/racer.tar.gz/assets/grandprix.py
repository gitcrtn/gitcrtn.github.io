POINTS = (10, 7, 5, 3, 2, 1)
MULTIPLIERS = (1.0, 1.5, 2.0, 3.0)
ORDER = (0, 1, 2, 3)
RACES = len(ORDER)
PLAYER = "YOU"
NAMES = ("ブルー", "イエロー", "グリーン", "ホワイト", "パープル")
def points(rank):
    return POINTS[rank - 1] if 1 <= rank <= len(POINTS) else 0
def multiplier(race):
    return MULTIPLIERS[race - 1]
def credits(base, race):
    return int(round(base * multiplier(race)))
def name(car):
    return PLAYER if car == 0 else NAMES[(car - 1) % len(NAMES)]
def places(mine, rivals):
    order = sorted(range(len(rivals)), key=lambda n: (-rivals[n], n))
    free = [place for place in range(1, len(rivals) + 2) if place != mine]
    ranks = [mine] + [0] * len(rivals)
    for place, n in zip(free, order):
        ranks[n + 1] = place
    return ranks
class GrandPrix:
    def __init__(self, cars, race=1):
        self.cars = cars
        self.race = race
        self.totals = [0] * cars
        self.gained = [0] * cars
        self.last = [None] * cars
        self.scored = False
    @property
    def course(self):
        return ORDER[self.race - 1]
    @property
    def final(self):
        return self.race >= RACES
    @property
    def next_course(self):
        return None if self.final else ORDER[self.race]
    def score(self, ranks):
        if self.scored:
            return
        self.scored = True
        self.gained = [points(rank) for rank in ranks]
        self.totals = [total + gain for total, gain in zip(self.totals, self.gained)]
        self.last = list(ranks)
    def standings(self):
        return sorted(range(self.cars), key=lambda car: (-self.totals[car], self.last[car] or self.cars + 1, car))
    def place(self, car=0):
        return self.standings().index(car) + 1
    def advance(self):
        if self.final:
            return False
        self.race += 1
        self.gained = [0] * self.cars
        self.scored = False
        return True
