from rgbkit import gfx as gfxlib
from rgbkit import gfxfx
GEAR_TOPS = (16.0, 28.0, 42.0, 56.0, 82.0)
SHIFT_DOWN = 0.85
IDLE = 0.1
RED_ZONE = 0.85
NEEDLE_FOLLOW = 6.0
SIZE = 192
RED, WHITE, YELLOW = (230, 60, 50), (255, 255, 255), (255, 225, 90)
class Tachometer:
    def __init__(self):
        self.gauge = gfxfx.Gauge(size=SIZE, start=135, sweep=270, ticks=11, zones=[(RED_ZONE, 1.0, RED)],
                                 needle_from=50, needle_to=88, follow=NEEDLE_FOLLOW, value=IDLE)
        self.tops = GEAR_TOPS
        self.reset()
    def set_top(self, top):
        self.tops = GEAR_TOPS[:-1] + (max(GEAR_TOPS[-2] + 1.0, float(top)),)
    def reset(self):
        self.gear = 1
        self.rpm = IDLE
        self.gauge.jump(IDLE)
    @property
    def needle(self):
        return self.gauge.value
    def update(self, speed, dt):
        while self.gear < len(self.tops) and speed > self.tops[self.gear - 1]:
            self.gear += 1
        while self.gear > 1 and speed < self.tops[self.gear - 2] * SHIFT_DOWN:
            self.gear -= 1
        self.rpm = max(IDLE, min(1.0, speed / self.tops[self.gear - 1]))
        self.gauge.set(self.rpm, dt)
    def rev(self, value, dt):
        self.gear = 1
        self.rpm = max(IDLE, min(1.0, value))
        self.gauge.set(self.rpm, dt, rate=NEEDLE_FOLLOW * 2)
    def draw(self, gfx, cx, cy, speed):
        self.gauge.draw(gfx, cx, cy)
        gfx.text(cx, cy - 34, "%d" % self.gear, 26, YELLOW, align="center", valign="middle")
        gfx.text(cx, cy + 6, "%d" % round(speed * 3.6), 48, WHITE, align="center", valign="middle")
        gfx.text(cx, cy + 44, "km/h", 20, WHITE, align="center", valign="middle")
MAP_BACK = (0, 0, 0, 140)
MAP_LINE = (240, 240, 240)
MAP_START = (255, 225, 90)
MAP_RIM = (255, 255, 255)
class CourseMap:
    def __init__(self, course, x, y, size=150, margin=14.0, pad=8, line=3, every=2):
        self.x, self.y, self.size = x, y, size
        self.fit = course.fit(x, y, size, margin=margin, pad=pad)
        self.scale = self.fit.scale
        points = self.fit.outline(every)
        self.outline = gfxlib.pack([], MAP_LINE)
        for (x1, y1), (x2, y2) in zip(points, points[1:] + points[:1]):
            self.outline += gfxlib.pack(gfxlib.line_points(x1, y1, x2, y2, line), MAP_LINE)
        sx, sy = self.at(course.points[0][0], course.points[0][1])
        self.outline += gfxlib.pack(gfxlib.line_points(sx - 6, sy, sx + 6, sy, 3), MAP_START)
    def at(self, x, z):
        return self.fit.at(x, z)
    def draw_outline(self, gfx):
        gfx.rect(self.x, self.y, self.size, self.size, MAP_BACK)
        gfx.packed(self.outline)
    def draw(self, gfx, me, color, others=()):
        gfx.rect(self.x, self.y, self.size, self.size, MAP_BACK)
        gfx.packed(self.outline)
        for x, z, tint in others:
            px, py = self.at(x, z)
            gfx.rect(px - 3, py - 3, 6, 6, tint)
        px, py = self.at(me[0], me[1])
        gfx.rect(px - 5, py - 5, 10, 10, MAP_RIM)
        gfx.rect(px - 3, py - 3, 6, 6, color)
