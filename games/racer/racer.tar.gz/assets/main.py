import asyncio
import importlib
import importlib.util
import os
import sys
import traceback
import pygame
HERE = os.path.dirname(os.path.abspath(__file__))
GAME_MAIN = "rgbweb_game_main.py"
def page():
    import platform
    return getattr(platform, "window", None)
class ToConsole:
    def __init__(self, stream, level):
        self.stream = stream
        self.level = level
        self.pending = ""
    def write(self, text):
        self.stream.write(text)
        self.pending += text
        while "\n" in self.pending:
            line, self.pending = self.pending.split("\n", 1)
            window = page()
            if window is not None:
                getattr(window.console, self.level)("[py] " + line)
        return len(text)
    def flush(self):
        self.stream.flush()
def status(text):
    print("rgbweb: " + text)
def game_class(module, base):
    found = [value for value in vars(module).values()
             if isinstance(value, type) and issubclass(value, base) and value is not base and value.__module__ == module.__name__]
    leaves = [cls for cls in found if not any(other is not cls and issubclass(other, cls) for other in found)]
    if len(leaves) != 1:
        raise RuntimeError("%s の中に、Game のサブクラスが %d 個あります（1 つにしてください）: %s" % (
            GAME_MAIN, len(leaves), " ".join(cls.__name__ for cls in leaves)))
    return leaves[0]
def game_id():
    with open(os.path.join(HERE, "game.cfg"), encoding="utf-8-sig") as f:
        for line in f:
            key, _, value = line.strip().partition("=")
            if key.strip() == "id":
                return value.strip()
    return "game"
async def restore_saves():
    save_dir = "/rgbweb/save/" + game_id()
    os.environ["RGBMENU_SAVE_DIR"] = save_dir
    window = page()
    bridge = getattr(window, "rgbweb", None) if window is not None else None
    if bridge is None:
        return
    for _ in range(100):
        if bool(bridge.savesReady()):
            break
        await asyncio.sleep(0.05)
    status("saves %s restored to %s" % (int(bridge.restoreSaves(save_dir)), save_dir))
async def start_programs():
    window = page()
    bridge = getattr(window, "rgbweb", None) if window is not None else None
    if bridge is None or not int(bridge.startPrograms(HERE)):
        return
    for _ in range(600):
        if bool(bridge.programsReady()):
            status("programs ready")
            return
        failure = str(bridge.programsError())
        if failure:
            raise RuntimeError("Go のプログラムを用意できません: " + failure)
        await asyncio.sleep(0.05)
    raise RuntimeError("Go のプログラムの用意が、30 秒で終わりませんでした")
async def main():
    sys.stdout = ToConsole(sys.stdout, "log")
    sys.stderr = ToConsole(sys.stderr, "error")
    try:
        status("start (%s, Python %s)" % (HERE, sys.version.split()[0]))
        os.environ["RGBWEB_FONT"] = os.path.join(HERE, "rgbweb-font.otf")
        await restore_saves()
        await start_programs()
        sys.argv = [os.path.join(HERE, "main.py")]
        if HERE not in sys.path:
            sys.path.insert(0, HERE)
        rgbkit = importlib.import_module("rgbkit")
        importlib.import_module("rgbkit.backend").use("web")
        status("rgbkit %s" % rgbkit.VERSION)
        spec = importlib.util.spec_from_file_location("rgbweb_game_main", os.path.join(HERE, GAME_MAIN))
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        cls = game_class(module, rgbkit.Game)
        status("game %s" % cls.__name__)
        code = await cls().run_async()
        status("finished %s" % code)
        window = page()
        if window is not None and getattr(window, "rgbweb", None) is not None:
            window.rgbweb.finished(code)
    except BaseException:
        text = traceback.format_exc()
        print(text, file=sys.stderr)
        window = page()
        if window is not None and getattr(window, "rgbweb", None) is not None:
            window.rgbweb.failed(text)
        raise
asyncio.run(main())
