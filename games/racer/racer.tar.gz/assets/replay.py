import math
from rgbkit import timeline
from course import WALL_SIDE, wrap
EVERY = 2
OWN = ["x", "z", ("angle", "angle"), ("travel", "angle"), "speed", ("drift", "flag"), ("boost", "flag"), ("spin", "flag")]
CAMERA_SPACING = 150.0
CAMERA_SIDE = WALL_SIDE + 3.0
CAMERA_HEIGHT = 5.0
def fields(rivals, heights=False):
    runs = ["run%d" % n for n in range(rivals)]
    return OWN + runs + (["y"] + ["y%d" % n for n in range(rivals)] if heights else [])
class Recorder:
    def __init__(self):
        self.clear()
    def clear(self, rivals=0, dt=1 / 60, tape=None, heights=False):
        self.rivals = rivals
        self.tape = tape or timeline.Recorder(fields(rivals, heights), interval=dt * EVERY)
        self.heights = len(self.tape.fields) > len(fields(rivals))
        self.steps = 0
        self.laps = []
    def __len__(self):
        return len(self.tape)
    @property
    def data(self):
        return self.tape.data
    @property
    def interval(self):
        return self.tape.interval
    @property
    def duration(self):
        return self.tape.duration
    def add(self, car, rivals, force=False):
        self.steps += 1
        if (self.steps - 1) % EVERY and not force:
            return
        self.tape.add([car.x, car.z, car.angle, car.travel, car.speed, car.drifting, car.boost > 0, car.spin > 0]
                      + [rival.run for rival in rivals] + ([car.y] + [rival.y for rival in rivals] if self.heights else []))
    def lap(self, t):
        return 1 + sum(1 for end in self.laps if t >= end)
class Shot:
    def __init__(self):
        self.x = self.z = self.angle = self.travel = self.speed = 0.0
        self.y = self.dist = self.pitch = 0.0
        self.drifting = False
        self.boost = self.spin = 0.0
        self.rivals = []
    @property
    def slip(self):
        return wrap(self.angle - self.travel)
class ShotRival:
    def __init__(self, side, color):
        self.side, self.color = side, color
        self.x = self.z = self.angle = self.run = self.y = 0.0
class Player:
    def __init__(self, recorder, course, sides):
        self.recorder, self.course = recorder, course
        self.shot = Shot()
        self.shot.rivals = [ShotRival(side, color) for side, color in sides[:recorder.rivals]]
        self.segment = None
        self.dist = 0.0
    def at(self, t):
        shot = self.shot
        values = self.recorder.tape.at(t)
        if values is None:
            return shot
        shot.x, shot.z, shot.angle, shot.travel, shot.speed, shot.drifting, boost, spin = values[:len(OWN)]
        shot.boost, shot.spin = (1.0 if boost else 0.0), (1.0 if spin else 0.0)
        count = len(shot.rivals)
        runs = values[len(OWN):len(OWN) + count]
        heights = values[len(OWN) + count:]
        for n, (rival, run) in enumerate(zip(shot.rivals, runs)):
            rival.run = run
            rival.x, rival.z, rival.angle, _ = self.course.place(run, rival.side)
            rival.y = heights[1 + n] if heights else self.course.height(run)
        self.segment, self.dist, _, _ = self.course.locate(shot.x, shot.z, self.segment)
        shot.dist = self.dist
        shot.y = heights[0] if heights else self.course.height(self.dist)
        shot.pitch = math.degrees(math.atan(self.course.slope(self.dist))) if self.course.hilly else 0.0
        return shot
class Cameras:
    def __init__(self, course, spacing=CAMERA_SPACING, side=CAMERA_SIDE, height=CAMERA_HEIGHT):
        self.count = max(2, round(course.total / spacing))
        self.spacing = course.total / self.count
        self.height = height
        self.spots = []
        self.heights = []
        for k in range(self.count):
            x, z, _, _ = course.place((k + 0.5) * self.spacing, side if k % 2 else -side)
            self.spots.append((x, z))
            self.heights.append(course.height((k + 0.5) * self.spacing) + height)
    def pick(self, dist):
        return int(dist / self.spacing) % self.count
OLD_FORMAT = 1
EMPTY = dict(timeline.EMPTY, format=0, course=0, rank=0, cars=0, time=0.0, laps=[], rivals=0, sides=[], colors=[], car=0, track=0)
SCHEMA = dict(timeline.SCHEMA, format=int, course=int, rank=(int, 0, 99), cars=(int, 0, 99), time=(float, 0.0, None),
              laps=[(float, 0.0, None)], rivals=(int, 0, 16), interval=(float, 0.0, 1.0), sides=[float],
              colors=[(int, 0, 255)], car=(int, 0, 99), track=(int, 0, 9))
def pack(recorder, course, rank, cars, time, sides, car=0, track=0):
    return dict(recorder.tape.pack(), format=0, course=int(round(course.total)), rank=int(rank), cars=int(cars), time=float(time),
                laps=[float(lap) for lap in recorder.laps], rivals=recorder.rivals,
                sides=[float(side) for side, _ in sides[:recorder.rivals]],
                colors=[int(part) for _, color in sides[:recorder.rivals] for part in color], car=int(car), track=int(track))
def _old_tape(saved):
    import base64
    import sys
    import zlib
    from array import array
    try:
        numbers = array("f")
        numbers.frombytes(zlib.decompress(base64.b64decode(saved["data"], validate=True)))
    except (KeyError, TypeError, ValueError, zlib.error):
        return None
    if sys.byteorder == "big":
        numbers.byteswap()
    size = 6 + saved["rivals"]
    if len(numbers) % size:
        return None
    tape = timeline.Recorder(fields(saved["rivals"]), interval=saved["interval"])
    for a in range(0, len(numbers), size):
        flags = int(numbers[a + 5])
        tape.add(list(numbers[a:a + 5]) + [flags & 1, flags & 2, flags & 4] + list(numbers[a + 6:a + size]))
    return tape
def unpack(saved, course):
    try:
        if (saved["course"] != int(round(course.total)) or not saved["data"] or saved["interval"] <= 0
                or len(saved["sides"]) != saved["rivals"] or len(saved["colors"]) != saved["rivals"] * 3):
            return None
        old = saved["format"] == OLD_FORMAT and not saved["timeline"]
        tape = _old_tape(saved) if old else (timeline.Recorder.unpack(saved, fields=fields(saved["rivals"], heights=True))
                                             or timeline.Recorder.unpack(saved, fields=fields(saved["rivals"])))
    except (KeyError, TypeError, ValueError):
        return None
    if tape is None or len(tape) < 2:
        return None
    recorder = Recorder()
    recorder.clear(saved["rivals"], tape=tape)
    recorder.laps = [lap for lap in saved["laps"] if lap is not None]
    colors = saved["colors"]
    return recorder, [(saved["sides"][n], tuple(colors[n * 3:n * 3 + 3])) for n in range(saved["rivals"])]
