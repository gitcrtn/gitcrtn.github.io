import bisect
import math
class Curve:
    def __init__(self, points):
        self.points = sorted((float(t), value) for t, value in points)
        if not self.points:
            raise ValueError("点が、ありません")
        self._ts = [t for t, _ in self.points]
        kinds = {isinstance(value, (tuple, list)) for _, value in self.points}
        if len(kinds) != 1:
            raise ValueError("値は、すべて数か、すべて同じ長さの組にします")
        self.many = kinds.pop()
        if self.many and len({len(value) for _, value in self.points}) != 1:
            raise ValueError("値は、すべて数か、すべて同じ長さの組にします")
    def at(self, t):
        points = self.points
        i = bisect.bisect_right(self._ts, t)
        if i == 0:
            return points[0][1]
        if i == len(points):
            return points[-1][1]
        (t0, a), (t1, b) = points[i - 1], points[i]
        k = (t - t0) / (t1 - t0)
        if self.many:
            return tuple(x + (y - x) * k for x, y in zip(a, b))
        return a + (b - a) * k
    def table(self, steps, whole=False):
        values = [self.at(i / steps) for i in range(steps + 1)]
        if not whole:
            return values
        if self.many:
            return [tuple(int(round(x)) for x in value) for value in values]
        return [int(round(value)) for value in values]
def approach(value, target, amount):
    if value < target:
        return min(target, value + amount)
    return max(target, value - amount)
def wrap(angle):
    return (angle + 180.0) % 360.0 - 180.0
def approach_angle(value, target, amount):
    back = (target - value + 180.0) % 360.0 - 180.0
    return (value + max(-amount, min(amount, back))) % 360.0
def follow(value, target, rate, dt):
    return value + (target - value) * min(1.0, rate * dt)
def follow_angle(value, target, rate, dt):
    return (value + ((target - value + 180.0) % 360.0 - 180.0) * min(1.0, rate * dt)) % 360.0
def flicker(time, values, rate):
    return values[int(time * rate) % len(values)]
class Timer:
    def __init__(self, seconds):
        self.seconds = float(seconds)
        self.left = 0.0
    def start(self):
        self.left = self.seconds
    def stop(self):
        self.left = 0.0
    def update(self, dt):
        if self.left > 0.0:
            self.left = max(0.0, self.left - dt)
    @property
    def active(self):
        return self.left > 0.0
    @property
    def t(self):
        return 1.0 - self.left / self.seconds if self.seconds > 0 else 1.0
class Countdown:
    def __init__(self, seconds=3.0, each=1.0):
        self.seconds, self.each = float(seconds), float(each)
        self.elapsed = None
        self._told = None
    def start(self):
        self.elapsed = 0.0
        self._told = None
    def stop(self):
        self.elapsed = None
    @property
    def done(self):
        return self.elapsed is not None and self.elapsed >= self.seconds - 1e-9
    @property
    def number(self):
        if self.elapsed is None or self.done:
            return 0
        return max(1, int(math.ceil((self.seconds - self.elapsed) / self.each - 1e-9)))
    @property
    def since_go(self):
        return self.elapsed - self.seconds if self.done else 0.0
    def update(self, dt):
        if self.elapsed is None:
            return None
        now = "go" if self.done else self.number
        self.elapsed += dt
        if now == self._told:
            return None
        self._told = now
        return now
class Watch:
    def __init__(self):
        self._seen = {}
    def rose(self, name, value):
        before = self._seen.get(name)
        self._seen[name] = value
        return before is not None and value > before
    def reset(self):
        self._seen = {}
