import importlib
TARGETS = ("native", "web")
_name = "native"
_module = None
def use(name):
    global _name
    if name not in TARGETS:
        raise ValueError("ターゲットの名前が違います: %r（使える名前: %s）" % (name, " ".join(TARGETS)))
    if _module is not None and name != _name:
        raise RuntimeError("ターゲットは、もう %s に決まっています" % _name)
    _name = name
def name():
    return _name
def current():
    global _module
    if _module is None:
        _module = importlib.import_module("." + _name, __name__)
    return _module
