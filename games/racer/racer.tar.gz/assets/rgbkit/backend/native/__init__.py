import os
import platform
import signal
import subprocess
import sys
from ... import sdl
from .events import Events
from .gfx import Gfx
from .sound import Mixer
__all__ = ["Events", "Gfx", "Mixer", "delay", "on_terminate", "persist", "program", "spawn"]
def program(game_dir, folder, device, host):
    on_device = sys.platform == "linux" and platform.machine() in ("aarch64", "arm64")
    for name in ([device] if on_device else []) + [host]:
        path = os.path.join(game_dir, folder, name)
        if os.path.isfile(path):
            return path
    return None
def spawn(args, cwd):
    return subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, bufsize=0, cwd=cwd)
def delay(seconds):
    sdl.Delay(int(seconds * 1000))
def persist(save_dir):
    pass
def on_terminate(callback):
    signal.signal(signal.SIGTERM, lambda signum, frame: callback())
