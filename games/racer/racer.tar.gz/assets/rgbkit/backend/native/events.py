import ctypes
import os
import struct
import sys
from ... import sdl
_BUTTONS = {0: "a", 1: "b", 2: "x", 3: "y", 4: "select", 6: "start", 9: "l1", 10: "r1",
            11: "up", 12: "down", 13: "left", 14: "right"}
_TRIGGERS = {4: "l2", 5: "r2"}
_TRIGGER_ON = 16000
_KEYS = {0x40000052: "up", 0x40000051: "down", 0x40000050: "left", 0x4000004F: "right",
         13: "a", ord("z"): "a", ord("x"): "b", ord("c"): "x", ord("v"): "y",
         ord("q"): "l1", ord("w"): "r1", 27: "start", 9: "select"}
_STICK_KEYS = {ord("e"): (1, -1), ord("d"): (1, 1), ord("s"): (0, -1), ord("f"): (0, 1),
               ord("i"): (3, -1), ord("k"): (3, 1), ord("j"): (2, -1), ord("l"): (2, 1)}
def default_swap_ab():
    value = os.environ.get("RGBKIT_SWAP_AB")
    if value in ("0", "1"):
        return value == "1"
    return sys.platform == "linux"
class Events:
    def __init__(self, swap_ab=None):
        self.swap_ab = default_swap_ab() if swap_ab is None else swap_ab
        self._event = ctypes.create_string_buffer(sdl.EVENT_SIZE)
        self._stick_keys = set()
        self.open_controllers()
    def open_controllers(self):
        for i in range(sdl.NumJoysticks()):
            if sdl.IsGameController(i):
                sdl.GameControllerOpen(i)
    def read(self, inp):
        buf = self._event
        while sdl.PollEvent(buf):
            etype = struct.unpack_from("<I", buf, 0)[0]
            if etype == sdl.QUIT:
                inp.quit_requested = True
            elif etype in (sdl.CONTROLLERBUTTONDOWN, sdl.CONTROLLERBUTTONUP):
                name = _BUTTONS.get(struct.unpack_from("<B", buf, 12)[0])
                if self.swap_ab and name in ("a", "b"):
                    name = "b" if name == "a" else "a"
                if name:
                    inp.set(name, etype == sdl.CONTROLLERBUTTONDOWN)
            elif etype == sdl.CONTROLLERAXISMOTION:
                axis = struct.unpack_from("<B", buf, 12)[0]
                value = struct.unpack_from("<h", buf, 16)[0]
                if axis in _TRIGGERS:
                    inp.set(_TRIGGERS[axis], value > _TRIGGER_ON)
                elif axis < 4:
                    inp.set_axis(axis, value)
            elif etype in (sdl.KEYDOWN, sdl.KEYUP):
                key = struct.unpack_from("<i", buf, 20)[0]
                name = _KEYS.get(key)
                if struct.unpack_from("<B", buf, 13)[0]:
                    pass
                elif name:
                    inp.set(name, etype == sdl.KEYDOWN)
                elif key in _STICK_KEYS:
                    (self._stick_keys.add if etype == sdl.KEYDOWN else self._stick_keys.discard)(key)
                    axis = _STICK_KEYS[key][0]
                    inp.set_axis(axis, 32767 * sum(sign for held in self._stick_keys
                                                   for a, sign in (_STICK_KEYS[held],) if a == axis))
            elif etype == sdl.CONTROLLERDEVICEADDED:
                self.open_controllers()
