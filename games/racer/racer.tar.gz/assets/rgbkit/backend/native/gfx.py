import ctypes
import os
import struct
import zlib
from ctypes import byref, c_char, c_int, c_void_p
from ... import sdl
from ...gfx import (FONT_CANDIDATES, HEIGHT, SHAPE_CACHE_MAX, TEXT_CACHE_MAX, WIDTH, Sprite, line_points, pack,
                    ring_points, rows_to_rgba)
try:
    _SetTextureScaleMode = sdl.bind(sdl.lib, "SDL_SetTextureScaleMode", c_int, c_void_p, c_int)
except AttributeError:
    _SetTextureScaleMode = None
class Gfx:
    def __init__(self, title="game", windowed=False, font_path=None, vsync=True):
        if sdl.Init(sdl.INIT_VIDEO | sdl.INIT_GAMECONTROLLER) != 0:
            raise sdl.error("SDL_Init")
        if sdl.TTF_Init() != 0:
            raise sdl.error("TTF_Init")
        flags = sdl.WINDOW_SHOWN | (0 if windowed else sdl.WINDOW_FULLSCREEN_DESKTOP)
        self.window = sdl.CreateWindow(title.encode("utf-8"), sdl.WINDOWPOS_CENTERED, sdl.WINDOWPOS_CENTERED,
                                       WIDTH, HEIGHT, flags)
        if not self.window:
            raise sdl.error("SDL_CreateWindow")
        self.renderer = sdl.CreateRenderer(self.window, -1, sdl.RENDERER_ACCELERATED
                                           | (sdl.RENDERER_PRESENTVSYNC if vsync else 0)) \
            or sdl.CreateRenderer(self.window, -1, 0)
        if not self.renderer:
            raise sdl.error("SDL_CreateRenderer")
        sdl.RenderSetLogicalSize(self.renderer, WIDTH, HEIGHT)
        sdl.SetRenderDrawBlendMode(self.renderer, sdl.BLENDMODE_BLEND)
        candidates = ([font_path] if font_path else []) + FONT_CANDIDATES
        self.font_path = next((p for p in candidates if p and os.path.exists(p)), None)
        self._fonts = {}
        self._texts = {}
        self._sprites = []
        self._shapes = {}
    def close(self):
        self._drop_texts()
        for sprite in self._sprites:
            sdl.DestroyTexture(sprite.tex)
        self._sprites = []
        for font in self._fonts.values():
            sdl.TTF_CloseFont(font)
        self._fonts = {}
        if self.renderer:
            sdl.DestroyRenderer(self.renderer)
            self.renderer = None
        if self.window:
            sdl.DestroyWindow(self.window)
            self.window = None
        sdl.TTF_Quit()
        sdl.Quit()
    def _color(self, color):
        sdl.SetRenderDrawColor(self.renderer, color[0], color[1], color[2], color[3] if len(color) > 3 else 255)
    def clear(self, color=(0, 0, 0)):
        self._color(color)
        sdl.RenderClear(self.renderer)
    def rect(self, x, y, w, h, color, fill=True):
        self._color(color)
        r = sdl.Rect(int(x), int(y), int(w), int(h))
        (sdl.RenderFillRect if fill else sdl.RenderDrawRect)(self.renderer, byref(r))
    def line(self, x1, y1, x2, y2, color, width=1):
        if width > 1:
            key = (x1, y1, x2, y2, width, tuple(color))
            data = self._shapes.get(key)
            if data is None:
                data = self._remember(key, pack(line_points(x1, y1, x2, y2, width), color))
            self.packed(data)
            return
        self._color(color)
        sdl.RenderDrawLine(self.renderer, int(x1), int(y1), int(x2), int(y2))
    def circle(self, cx, cy, radius, color, fill=True):
        self.ring(cx, cy, radius, radius if fill else 1, color)
    def ring(self, cx, cy, radius, width, color, start=0.0, end=360.0):
        key = (cx, cy, radius, width, tuple(color), start, end)
        data = self._shapes.get(key)
        if data is None:
            data = self._remember(key, pack(ring_points(cx, cy, radius, width, start, end), color))
        self.packed(data)
    def _remember(self, key, data):
        if len(self._shapes) >= SHAPE_CACHE_MAX:
            self._shapes = {}
        self._shapes[key] = data
        return data
    def triangles(self, points, color):
        self.packed(pack(points, color))
    def packed(self, data):
        if not data:
            return
        if sdl.RenderGeometryRaw is None:
            raise RuntimeError("太い線と円には、SDL 2.0.18 以上が要ります")
        sdl.RenderGeometryRaw(self.renderer, None, data.xy, 8, data.colors, 4, None, 0, len(data), None, 0, 0)
    def text(self, x, y, text, size=28, color=(255, 255, 255), align="left", valign="top", shadow=None, offset=2,
             outline=None, outline_width=3):
        if not text:
            return 0
        tex, w, h = self._text_texture(text, size, color)
        if align == "center":
            x -= w // 2
        elif align == "right":
            x -= w
        if valign == "middle":
            y -= h // 2
        elif valign == "bottom":
            y -= h
        if outline is not None and outline_width > 0:
            pad = int(outline_width)
            if shadow is not None:
                under, uw, uh = self._text_texture(text, size, shadow, pad)
                sdl.RenderCopy(self.renderer, under, None, byref(sdl.Rect(int(x) - pad + offset, int(y) - pad + offset, uw, uh)))
            ring, rw, rh = self._text_texture(text, size, outline, pad)
            sdl.RenderCopy(self.renderer, ring, None, byref(sdl.Rect(int(x) - pad, int(y) - pad, rw, rh)))
        elif shadow is not None:
            under = self._text_texture(text, size, shadow)[0]
            sdl.RenderCopy(self.renderer, under, None, byref(sdl.Rect(int(x) + offset, int(y) + offset, w, h)))
        sdl.RenderCopy(self.renderer, tex, None, byref(sdl.Rect(int(x), int(y), w, h)))
        return w
    def text_size(self, text, size=28):
        w, h = c_int(), c_int()
        sdl.TTF_SizeUTF8(self._font(size), text.encode("utf-8"), byref(w), byref(h))
        return w.value, h.value
    def present(self):
        sdl.RenderPresent(self.renderer)
    def sprite(self, rows, color, scale=1):
        if not rows or not len(rows[0]):
            raise ValueError("ドット絵が空です")
        cols = len(rows[0])
        tex = sdl.CreateTexture(self.renderer, sdl.PIXELFORMAT_RGBA32, sdl.TEXTUREACCESS_STATIC, cols, len(rows))
        if not tex:
            raise sdl.error("SDL_CreateTexture")
        sdl.SetTextureBlendMode(tex, sdl.BLENDMODE_BLEND)
        sprite = Sprite(tex, cols, len(rows), scale)
        self._sprites.append(sprite)
        self.sprite_update(sprite, rows, color)
        return sprite
    def sprite_update(self, sprite, rows, color):
        if len(rows) != sprite.rows or any(len(row) != sprite.cols for row in rows):
            raise ValueError("ドット絵の行の長さが、そろっていません（または、作ったときと大きさが違います）")
        data = rows_to_rgba(rows, color)
        if sdl.UpdateTexture(sprite.tex, None, data, sprite.cols * 4) != 0:
            raise sdl.error("SDL_UpdateTexture")
    def blit(self, sprite, x, y):
        sdl.RenderCopy(self.renderer, sprite.tex, None, byref(sdl.Rect(int(x), int(y), sprite.w, sprite.h)))
    def stream(self, w, h):
        return Stream(self, w, h)
    def screenshot(self, path):
        w, h = c_int(), c_int()
        sdl.GetRendererOutputSize(self.renderer, byref(w), byref(h))
        w, h = w.value, h.value
        buf = ctypes.create_string_buffer(w * h * 4)
        if sdl.RenderReadPixels(self.renderer, None, sdl.PIXELFORMAT_RGBA32, buf, w * 4) != 0:
            raise sdl.error("SDL_RenderReadPixels")
        raw = b"".join(b"\x00" + buf.raw[y * w * 4:(y + 1) * w * 4] for y in range(h))
        def chunk(kind, data):
            body = kind + data
            return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)
        with open(path, "wb") as f:
            f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
                    + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))
    def _font(self, size, outline=0):
        font = self._fonts.get((size, outline))
        if not font:
            if not self.font_path:
                raise RuntimeError("使えるフォントがありません（Gfx の font_path で指定してください）")
            font = sdl.TTF_OpenFont(self.font_path.encode("utf-8"), size)
            if not font:
                raise sdl.error("TTF_OpenFont(%s)" % self.font_path)
            if outline:
                sdl.TTF_SetFontOutline(font, outline)
            self._fonts[(size, outline)] = font
        return font
    def _text_texture(self, text, size, color, outline=0):
        key = (text, size, tuple(color[:3]), outline)
        hit = self._texts.get(key)
        if hit:
            return hit
        if len(self._texts) >= TEXT_CACHE_MAX:
            self._drop_texts()
        surface = sdl.TTF_RenderUTF8_Blended(self._font(size, outline), text.encode("utf-8"),
                                             sdl.Color(color[0], color[1], color[2], 255))
        if not surface:
            raise sdl.error("TTF_RenderUTF8_Blended")
        tex = sdl.CreateTextureFromSurface(self.renderer, surface)
        sdl.FreeSurface(surface)
        if not tex:
            raise sdl.error("SDL_CreateTextureFromSurface")
        w, h = c_int(), c_int()
        sdl.QueryTexture(tex, None, None, byref(w), byref(h))
        self._texts[key] = (tex, w.value, h.value)
        return self._texts[key]
    def _drop_texts(self):
        for tex, _, _ in self._texts.values():
            sdl.DestroyTexture(tex)
        self._texts = {}
class Stream:
    def __init__(self, gfx, w, h):
        self.gfx = gfx
        self.w, self.h = w, h
        self._source = None
        self._buffer = None
        self._tex = sdl.CreateTexture(gfx.renderer, sdl.PIXELFORMAT_RGBA32, sdl.TEXTUREACCESS_STREAMING, w, h)
        if not self._tex:
            raise sdl.error("SDL_CreateTexture")
        if _SetTextureScaleMode:
            _SetTextureScaleMode(self._tex, 0)
    def update(self, pixels):
        if pixels is not self._source:
            self._source = pixels
            self._buffer = (c_char * len(pixels)).from_buffer(pixels)
        if sdl.UpdateTexture(self._tex, None, self._buffer, self.w * 4) != 0:
            raise sdl.error("SDL_UpdateTexture")
    def draw(self, x, y, w, h):
        sdl.RenderCopy(self.gfx.renderer, self._tex, None, byref(sdl.Rect(int(x), int(y), int(w), int(h))))
    def close(self):
        if self._tex:
            sdl.DestroyTexture(self._tex)
            self._tex = None
        self._source = self._buffer = None
