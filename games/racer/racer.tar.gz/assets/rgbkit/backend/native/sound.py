import ctypes
from ctypes import c_char_p, c_int, c_uint16, c_uint32, c_void_p
from ... import sdl
class Mixer:
    def __init__(self):
        self._mix = None
        self._buffers = []
    def open(self, rate, channels):
        mix = sdl.load_library("SDL2_mixer")
        bind = sdl.bind
        self._OpenAudio = bind(mix, "Mix_OpenAudio", c_int, c_int, c_uint16, c_int, c_int)
        self._CloseAudio = bind(mix, "Mix_CloseAudio", None)
        self._AllocateChannels = bind(mix, "Mix_AllocateChannels", c_int, c_int)
        self._LoadWAV_RW = bind(mix, "Mix_LoadWAV_RW", c_void_p, c_void_p, c_int)
        self._QuickLoad_RAW = bind(mix, "Mix_QuickLoad_RAW", c_void_p, c_void_p, c_uint32)
        self._FreeChunk = bind(mix, "Mix_FreeChunk", None, c_void_p)
        self._PlayChannelTimed = bind(mix, "Mix_PlayChannelTimed", c_int, c_int, c_void_p, c_int, c_int)
        self._Volume = bind(mix, "Mix_Volume", c_int, c_int, c_int)
        self._HaltChannel = bind(mix, "Mix_HaltChannel", c_int, c_int)
        self._Pause = bind(mix, "Mix_Pause", None, c_int)
        self._Resume = bind(mix, "Mix_Resume", None, c_int)
        self._Playing = bind(mix, "Mix_Playing", c_int, c_int)
        self._GetChunk = bind(mix, "Mix_GetChunk", c_void_p, c_int)
        self._LoadMUS = bind(mix, "Mix_LoadMUS", c_void_p, c_char_p)
        self._FreeMusic = bind(mix, "Mix_FreeMusic", None, c_void_p)
        self._PlayMusic = bind(mix, "Mix_PlayMusic", c_int, c_void_p, c_int)
        self._HaltMusic = bind(mix, "Mix_HaltMusic", c_int)
        self._VolumeMusic = bind(mix, "Mix_VolumeMusic", c_int, c_int)
        self._PauseMusic = bind(mix, "Mix_PauseMusic", None)
        self._ResumeMusic = bind(mix, "Mix_ResumeMusic", None)
        if sdl.InitSubSystem(sdl.INIT_AUDIO) != 0:
            raise sdl.error("SDL_InitSubSystem(AUDIO)")
        if self._OpenAudio(rate, sdl.AUDIO_S16SYS, 2, 1024) != 0:
            err = sdl.error("Mix_OpenAudio")
            sdl.QuitSubSystem(sdl.INIT_AUDIO)
            raise err
        self._AllocateChannels(channels)
        self._mix = mix
        driver = sdl.GetCurrentAudioDriver()
        return driver.decode("utf-8", "replace") if driver else "?"
    def error(self, what):
        return sdl.error(what)
    def load_wav(self, path):
        rw = sdl.RWFromFile(path.encode("utf-8"), b"rb")
        return self._LoadWAV_RW(rw, 1) if rw else None
    def load_raw(self, data):
        buffer = ctypes.create_string_buffer(data, len(data))
        chunk = self._QuickLoad_RAW(buffer, len(data))
        if chunk:
            self._buffers.append(buffer)
        return chunk
    def play(self, chunk, loop):
        return self._PlayChannelTimed(-1, chunk, -1 if loop else 0, -1)
    def volume(self, channel, value):
        self._Volume(channel, value)
    def halt(self, channel):
        self._HaltChannel(channel)
    def pause(self, channel):
        self._Pause(channel)
    def resume(self, channel):
        self._Resume(channel)
    def playing(self, channel, chunk):
        return bool(self._Playing(channel)) and self._GetChunk(channel) == chunk
    def free(self, chunk):
        self._FreeChunk(chunk)
    def load_music(self, path):
        return self._LoadMUS(path.encode("utf-8"))
    def play_music(self, music, loop):
        return self._PlayMusic(music, -1 if loop else 0) == 0
    def halt_music(self):
        self._HaltMusic()
    def free_music(self, music):
        self._FreeMusic(music)
    def volume_music(self, value):
        self._VolumeMusic(value)
    def pause_music(self):
        self._PauseMusic()
    def resume_music(self):
        self._ResumeMusic()
    def close(self):
        self._CloseAudio()
        self._buffers = []
        sdl.QuitSubSystem(sdl.INIT_AUDIO)
