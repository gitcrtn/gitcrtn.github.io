import pygame
from . import js
from .events import Events
from .gfx import Gfx
from .process import WebProcess
from .sound import Mixer
__all__ = ["Events", "Gfx", "Mixer", "delay", "on_terminate", "persist", "program", "spawn"]
PREFIX = "rgbweb:"
def program(game_dir, folder, device, host):
    bridge = js.rgbweb()
    if bridge is not None and bool(bridge.hasProgram(folder)):
        return PREFIX + folder
    return None
def spawn(args, cwd):
    if not args[0].startswith(PREFIX):
        raise OSError("Web 版では、ページの Go のプログラムしか動かせません（%s）" % args[0])
    bridge = js.rgbweb()
    if bridge is None:
        raise OSError("ページのつなぎ（rgbweb）がありません")
    return WebProcess(bridge, args[0][len(PREFIX):], args[1:], cwd)
def delay(seconds):
    pygame.time.wait(int(seconds * 1000))
def persist(save_dir):
    bridge = js.rgbweb()
    if bridge is not None:
        bridge.persistSaves(save_dir)
def on_terminate(callback):
    pass
