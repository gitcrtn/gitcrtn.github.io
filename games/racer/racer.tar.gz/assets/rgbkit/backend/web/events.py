import pygame
from . import js
BUTTONS = ("a", "b", "x", "y", "l1", "r1", "l2", "r2", "start", "up", "down", "left", "right")
FULL = 32767
class Events:
    def __init__(self, swap_ab=None):
        self._buttons = 0
        self._axes = [0, 0, 0, 0]
        self._log = print
    def read(self, inp):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                inp.quit_requested = True
        bridge = js.rgbweb()
        if bridge is None:
            return
        self._take_stderr(bridge)
        controller = getattr(bridge, "controller", None)
        if controller is None:
            return
        parts = str(controller.snapshot()).split()
        if len(parts) != 5:
            return
        buttons = int(parts[0])
        changed = buttons ^ self._buttons
        if changed:
            for bit, name in enumerate(BUTTONS):
                if changed >> bit & 1:
                    inp.set(name, bool(buttons >> bit & 1))
            self._buttons = buttons
        for axis in range(4):
            value = max(-FULL, min(FULL, int(round(float(parts[axis + 1]) * FULL))))
            if value != self._axes[axis]:
                self._axes[axis] = value
                inp.set_axis(axis, value)
    def _take_stderr(self, bridge):
        text = str(bridge.takeStderr())
        if text:
            for line in text.split("\n"):
                self._log(line)
