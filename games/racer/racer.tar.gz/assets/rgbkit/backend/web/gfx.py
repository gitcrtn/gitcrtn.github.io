import os
from array import array
import pygame
from ...gfx import HEIGHT, SHAPE_CACHE_MAX, TEXT_CACHE_MAX, WIDTH, Sprite, line_points, pack, ring_points, rows_to_rgba
BLEND_CACHE_MAX = 32
class Gfx:
    def __init__(self, title="game", windowed=False, font_path=None, vsync=True):
        pygame.display.init()
        pygame.font.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(title)
        candidates = [font_path, os.environ.get("RGBWEB_FONT")]
        self.font_path = next((p for p in candidates if p and os.path.exists(p)), None)
        self._fonts = {}
        self._texts = {}
        self._shapes = {}
        self._blends = {}
    def close(self):
        self._texts = {}
        self._fonts = {}
        self._blends = {}
    def clear(self, color=(0, 0, 0)):
        self.screen.fill(color[:3])
    def rect(self, x, y, w, h, color, fill=True):
        x, y, w, h = int(x), int(y), int(w), int(h)
        if w <= 0 or h <= 0:
            return
        if len(color) > 3 and color[3] < 255:
            if not fill:
                self._blend_outline(x, y, w, h, color)
                return
            key = (w, h, tuple(color))
            surface = self._blends.get(key)
            if surface is None:
                if len(self._blends) >= BLEND_CACHE_MAX:
                    self._blends = {}
                surface = self._blends[key] = pygame.Surface((w, h), pygame.SRCALPHA)
                surface.fill(color)
            self.screen.blit(surface, (x, y))
            return
        pygame.draw.rect(self.screen, color[:3], (x, y, w, h), 0 if fill else 1)
    def _blend_outline(self, x, y, w, h, color):
        surface = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(surface, color, (0, 0, w, h), 1)
        self.screen.blit(surface, (x, y))
    def line(self, x1, y1, x2, y2, color, width=1):
        if width > 1:
            key = (x1, y1, x2, y2, width, tuple(color))
            data = self._shapes.get(key)
            if data is None:
                data = self._remember(key, pack(line_points(x1, y1, x2, y2, width), color))
            self.packed(data)
            return
        if len(color) > 3 and color[3] < 255:
            left, top = int(min(x1, x2)), int(min(y1, y2))
            surface = pygame.Surface((int(abs(x2 - x1)) + 1, int(abs(y2 - y1)) + 1), pygame.SRCALPHA)
            pygame.draw.line(surface, color, (int(x1) - left, int(y1) - top), (int(x2) - left, int(y2) - top))
            self.screen.blit(surface, (left, top))
            return
        pygame.draw.line(self.screen, color[:3], (int(x1), int(y1)), (int(x2), int(y2)))
    def circle(self, cx, cy, radius, color, fill=True):
        self.ring(cx, cy, radius, radius if fill else 1, color)
    def ring(self, cx, cy, radius, width, color, start=0.0, end=360.0):
        key = (cx, cy, radius, width, tuple(color), start, end)
        data = self._shapes.get(key)
        if data is None:
            data = self._remember(key, pack(ring_points(cx, cy, radius, width, start, end), color))
        self.packed(data)
    def _remember(self, key, data):
        if len(self._shapes) >= SHAPE_CACHE_MAX:
            self._shapes = {}
        self._shapes[key] = data
        return data
    def triangles(self, points, color):
        self.packed(pack(points, color))
    def packed(self, data):
        if not data:
            return
        xy = array("f")
        xy.frombytes(data.xy)
        colors = data.colors
        count = len(xy) // 6
        i = 0
        while i < count:
            color = tuple(colors[i * 12:i * 12 + 4])
            j = i + 1
            while j < count and colors[j * 12:j * 12 + 4] == colors[i * 12:i * 12 + 4]:
                j += 1
            triangles = [((xy[k * 6], xy[k * 6 + 1]), (xy[k * 6 + 2], xy[k * 6 + 3]), (xy[k * 6 + 4], xy[k * 6 + 5]))
                         for k in range(i, j)]
            self._fill_triangles(triangles, color)
            i = j
    def _fill_triangles(self, triangles, color):
        if color[3] >= 255:
            for triangle in triangles:
                pygame.draw.polygon(self.screen, color[:3], triangle)
            return
        if color[3] == 0:
            return
        xs = [p[0] for t in triangles for p in t]
        ys = [p[1] for t in triangles for p in t]
        left, top = int(min(xs)), int(min(ys))
        w, h = int(max(xs)) - left + 2, int(max(ys)) - top + 2
        surface = pygame.Surface((w, h), pygame.SRCALPHA)
        for triangle in triangles:
            pygame.draw.polygon(surface, color, [(x - left, y - top) for x, y in triangle])
        self.screen.blit(surface, (left, top))
    def text(self, x, y, text, size=28, color=(255, 255, 255), align="left", valign="top", shadow=None, offset=2,
             outline=None, outline_width=3):
        if not text:
            return 0
        surface = self._text_surface(text, size, color)
        w, h = surface.get_size()
        if align == "center":
            x -= w // 2
        elif align == "right":
            x -= w
        if valign == "middle":
            y -= h // 2
        elif valign == "bottom":
            y -= h
        if outline is not None and outline_width > 0:
            pad = int(outline_width)
            if shadow is not None:
                self.screen.blit(self._text_surface(text, size, shadow, pad), (int(x) - pad + offset, int(y) - pad + offset))
            self.screen.blit(self._text_surface(text, size, outline, pad), (int(x) - pad, int(y) - pad))
        elif shadow is not None:
            self.screen.blit(self._text_surface(text, size, shadow), (int(x) + offset, int(y) + offset))
        self.screen.blit(surface, (int(x), int(y)))
        return w
    def text_size(self, text, size=28):
        return self._font(size).size(text)
    def present(self):
        pygame.display.flip()
    def sprite(self, rows, color, scale=1):
        if not rows or not len(rows[0]):
            raise ValueError("ドット絵が空です")
        sprite = Sprite(None, len(rows[0]), len(rows), scale)
        self.sprite_update(sprite, rows, color)
        return sprite
    def sprite_update(self, sprite, rows, color):
        if len(rows) != sprite.rows or any(len(row) != sprite.cols for row in rows):
            raise ValueError("ドット絵の行の長さが、そろっていません（または、作ったときと大きさが違います）")
        small = pygame.image.frombuffer(rows_to_rgba(rows, color), (sprite.cols, sprite.rows), "RGBA")
        sprite.tex = pygame.transform.scale(small, (sprite.w, sprite.h))
    def blit(self, sprite, x, y):
        self.screen.blit(sprite.tex, (int(x), int(y)))
    def stream(self, w, h):
        return Stream(self, w, h)
    def screenshot(self, path):
        pygame.image.save(self.screen, path)
    def _font(self, size, outline=0):
        font = self._fonts.get((size, outline))
        if not font:
            if not self.font_path:
                raise RuntimeError("使えるフォントがありません（Gfx の font_path か、環境変数 RGBWEB_FONT で指定してください）")
            font = pygame.font.Font(self.font_path, size)
            if outline:
                font.outline = outline
            self._fonts[(size, outline)] = font
        return font
    def _text_surface(self, text, size, color, outline=0):
        key = (text, size, tuple(color[:3]), outline)
        hit = self._texts.get(key)
        if hit:
            return hit
        if len(self._texts) >= TEXT_CACHE_MAX:
            self._texts = {}
        surface = self._font(size, outline).render(text, True, color[:3])
        self._texts[key] = surface
        return surface
class Stream:
    def __init__(self, gfx, w, h):
        self.gfx = gfx
        self.w, self.h = w, h
        self._source = None
        self._surface = None
        self._scaled = {}
    def update(self, pixels):
        if pixels is not self._source:
            self._source = pixels
            self._surface = pygame.image.frombuffer(pixels, (self.w, self.h), "RGBX")
            self._scaled = {}
    def draw(self, x, y, w, h):
        if self._surface is None:
            return
        x, y, w, h = int(x), int(y), int(w), int(h)
        target = self._scaled.get((w, h))
        if target is None:
            target = self._scaled[(w, h)] = pygame.Surface((w, h), 0, self._surface)
        pygame.transform.scale(self._surface, (w, h), target)
        self.gfx.screen.blit(target, (x, y))
    def close(self):
        self._source = self._surface = None
        self._scaled = {}
