WINDOW = None
def window():
    if WINDOW is not None:
        return WINDOW
    import platform
    return getattr(platform, "window", None)
def rgbweb():
    page = window()
    return getattr(page, "rgbweb", None) if page is not None else None
