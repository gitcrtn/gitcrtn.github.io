import ctypes
import json
import subprocess
RUNNING = -999
def address(buffer):
    return ctypes.addressof((ctypes.c_char * len(buffer)).from_buffer(buffer))
class _Stdin:
    def __init__(self, proc):
        self._proc = proc
    def write(self, data):
        data = bytes(data)
        if not data:
            return 0
        pointer = ctypes.c_char_p(data)
        addr = ctypes.cast(pointer, ctypes.c_void_p).value
        if not int(self._proc.bridge.write(self._proc.id, addr, len(data))):
            raise BrokenPipeError("Go のプログラムは、もう終わっています（%s）" % self._proc.name)
        return len(data)
    def close(self):
        self._proc.bridge.closeStdin(self._proc.id)
class _Stdout:
    def __init__(self, proc):
        self._proc = proc
    def readinto(self, buffer):
        if not len(buffer):
            return 0
        return max(0, int(self._proc.bridge.readInto(self._proc.id, address(buffer), len(buffer), -1)))
    def read(self, size=-1):
        buffer = bytearray(size if size and size > 0 else 65536)
        count = self.readinto(buffer)
        return bytes(buffer[:count])
    def close(self):
        pass
class WebProcess:
    def __init__(self, bridge, name, args, cwd):
        self.bridge = bridge
        self.name = name
        self.args = [name] + list(args)
        self.returncode = None
        self.id = int(bridge.spawn(name, json.dumps(self.args), json.dumps(["PWD=" + cwd])))
        if self.id < 0:
            raise OSError("Go のプログラム（%s）を動かせません: %s" % (name, bridge.lastError))
        self.stdin = _Stdin(self)
        self.stdout = _Stdout(self)
    def poll(self):
        code = int(self.bridge.poll(self.id))
        if code != RUNNING:
            self.returncode = code
        return self.returncode
    def wait(self, timeout=None):
        code = int(self.bridge.wait(self.id, -1 if timeout is None else int(timeout * 1000)))
        if code == RUNNING:
            raise subprocess.TimeoutExpired(self.args, timeout)
        self.returncode = code
        return code
    def kill(self):
        self.bridge.kill(self.id)
