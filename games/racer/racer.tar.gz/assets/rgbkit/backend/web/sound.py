import pygame
class Mixer:
    def __init__(self):
        self._channels = []
    def open(self, rate, channels):
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(rate, -16, 2, 1024)
            pygame.mixer.set_num_channels(channels)
        except pygame.error as e:
            raise RuntimeError("pygame.mixer: %s" % e)
        self._channels = [pygame.mixer.Channel(i) for i in range(channels)]
        return "web"
    def error(self, what):
        return RuntimeError("%s: %s" % (what, pygame.get_error() or "?"))
    def load_wav(self, path):
        try:
            return pygame.mixer.Sound(path)
        except (pygame.error, OSError, FileNotFoundError):
            return None
    def load_raw(self, data):
        try:
            return pygame.mixer.Sound(buffer=bytes(data))
        except pygame.error:
            return None
    def play(self, chunk, loop):
        for number, channel in enumerate(self._channels):
            if not channel.get_busy():
                channel.play(chunk, loops=-1 if loop else 0)
                return number
        return -1
    def volume(self, channel, value):
        self._channels[channel].set_volume(value / 128)
    def halt(self, channel):
        if channel < 0:
            pygame.mixer.stop()
        else:
            self._channels[channel].stop()
    def pause(self, channel):
        if channel < 0:
            pygame.mixer.pause()
        else:
            self._channels[channel].pause()
    def resume(self, channel):
        if channel < 0:
            pygame.mixer.unpause()
        else:
            self._channels[channel].unpause()
    def playing(self, channel, chunk):
        target = self._channels[channel]
        return target.get_busy() and target.get_sound() is chunk
    def free(self, chunk):
        pass
    def load_music(self, path):
        try:
            pygame.mixer.music.load(path)
        except (pygame.error, OSError, FileNotFoundError):
            return None
        return path
    def play_music(self, music, loop):
        try:
            pygame.mixer.music.play(-1 if loop else 0)
        except pygame.error:
            return False
        return True
    def halt_music(self):
        pygame.mixer.music.stop()
    def free_music(self, music):
        pass
    def volume_music(self, value):
        pygame.mixer.music.set_volume(value / 128)
    def pause_music(self):
        pygame.mixer.music.pause()
    def resume_music(self):
        pygame.mixer.music.unpause()
    def close(self):
        pygame.mixer.stop()
        pygame.mixer.music.stop()
