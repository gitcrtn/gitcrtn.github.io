COPYRIGHT = '2026 Carotene'
