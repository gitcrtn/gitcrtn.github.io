import json
import struct
import subprocess
from . import backend
DIR = "engine"
DEVICE = "engine-linux-arm64"
HOST = ".engine-host"
CLOSE_WAIT = 0.5
MAGIC = b"RGBE"
PROTOCOL = 1
HOW_TO_BUILD = "gamekit/build-engine.sh を実行してください（ソースは、プロジェクトの直下の engine/）"
class EngineError(RuntimeError):
    pass
def open(game):
    return Engine(game)
def path(game_dir):
    return backend.current().program(game_dir, DIR, DEVICE, HOST)
class Engine:
    def __init__(self, game):
        found = path(game.game_dir)
        if not found:
            raise EngineError("エンジンがありません（%s/ の中の %s か %s）。%s" % (DIR, DEVICE, HOST, HOW_TO_BUILD))
        try:
            self._proc = backend.current().spawn([found], game.game_dir)
        except OSError as e:
            raise EngineError("エンジンを動かせません: %s。%s" % (e, HOW_TO_BUILD))
        self._why = ""
        game.add_closer(self.close)
        try:
            hello = self._read(6)
            if hello[:4] != MAGIC or struct.unpack("<H", hello[4:])[0] != PROTOCOL:
                raise EngineError("エンジンの話し方が、このライブラリと合いません。%s" % HOW_TO_BUILD)
            self._reply()
        except EngineError as e:
            self.close()
            raise EngineError("エンジンを開けません: %s" % e)
    def _stopped(self, why):
        self._why = self._why or why
        return EngineError(self._why)
    def _read(self, size):
        data = bytearray()
        while len(data) < size:
            chunk = self._proc.stdout.read(size - len(data))
            if not chunk:
                raise self._stopped("エンジンが止まりました（記録の、engine: の行を見てください）")
            data += chunk
        return bytes(data)
    def _reply(self):
        size = struct.unpack("<I", self._read(4))[0]
        if size == 0:
            raise self._stopped("エンジンの返事の形が違います")
        reply = self._read(size)
        if reply[0] != 0:
            message = reply[1:].decode("utf-8", "replace")
            if self._proc.poll() is not None or message.startswith("エンジンが落ちました"):
                raise self._stopped(message)
            raise EngineError(message)
        return reply[1:]
    def ask(self, op, data=b""):
        if isinstance(op, int):
            if not 0 <= op <= 255:
                raise ValueError("頼みの種類は 0〜255: %r" % op)
            op = bytes((op,))
        if not isinstance(op, bytes) or len(op) != 1:
            raise ValueError("頼みの種類は 1 バイト（b\"N\" か 0〜255）: %r" % (op,))
        if self._why:
            raise EngineError(self._why)
        try:
            self._proc.stdin.write(struct.pack("<I", len(data) + 1) + op + bytes(data))
        except (BrokenPipeError, OSError, ValueError):
            raise self._stopped("エンジンが止まりました（記録の、engine: の行を見てください）")
        return self._reply()
    def ask_json(self, op, value):
        reply = self.ask(op, json.dumps(value, ensure_ascii=False).encode("utf-8"))
        try:
            return json.loads(reply)
        except ValueError:
            raise EngineError("エンジンの返事が JSON ではありません: %r" % reply[:80])
    def close(self):
        self._why = self._why or "エンジンは閉じました"
        proc = self._proc
        if proc.poll() is not None:
            return
        try:
            proc.stdin.close()
            proc.wait(timeout=CLOSE_WAIT)
        except (OSError, subprocess.TimeoutExpired):
            proc.kill()
            proc.wait()
