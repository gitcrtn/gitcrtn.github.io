import math
import os
import struct
import subprocess
import sys
import time
from array import array
from itertools import chain
from . import backend, g3drot
from .gfx import HEIGHT, WIDTH, rows_to_rgba
SIZE_MIN = 160
SIZE_MAX = 480
TEXTURE_MAX = 256
RENDER_DIR = "g3d"
RENDER_DEVICE = "render-linux-arm64"
RENDER_HOST = ".render-host"
HOW_TO_BUILD = "gamekit/build3d.sh を実行してください"
TUNING_ENV = "RGBKIT_G3D_TUNING"
class G3dError(RuntimeError):
    pass
class Shape:
    def __init__(self, vertices, faces, uvs=None, colors=None):
        self.vertices = [tuple(float(value) for value in vertex) for vertex in vertices]
        self.faces = [tuple(face) for face in faces]
        self.uvs = list(uvs) if uvs is not None else [(0.0, 0.0)] * len(self.vertices)
        self.colors = list(colors) if colors is not None else [(255, 255, 255)] * len(self.vertices)
        count = len(self.vertices)
        if len(self.uvs) != count or len(self.colors) != count:
            raise ValueError("uvs と colors は、頂点と同じ数にします")
        for face in self.faces:
            if len(face) < 3 or any(not 0 <= index < count for index in face):
                raise ValueError("面の書き方が違います: %r（3 つ以上の、頂点の番号）" % (face,))
    def triangles(self):
        return [(face[0], face[i], face[i + 1]) for face in self.faces for i in range(1, len(face) - 1)]
    def add(self, other, pos=(0, 0, 0), rot=(0, 0, 0), scale=1, color=None):
        m = _place(pos, rot, scale)
        base = len(self.vertices)
        self.vertices += [(m[0] * x + m[1] * y + m[2] * z + m[3], m[4] * x + m[5] * y + m[6] * z + m[7],
                           m[8] * x + m[9] * y + m[10] * z + m[11]) for x, y, z in other.vertices]
        self.uvs += other.uvs
        if color is None:
            self.colors += other.colors
        else:
            self.colors += [(tint[0] * color[0] // 255, tint[1] * color[1] // 255, tint[2] * color[2] // 255)
                            for tint in other.colors]
        self.faces += [tuple(base + index for index in face) for face in other.faces]
        return self
    def bounds(self):
        if not self.vertices:
            return (0.0, 0.0, 0.0), 0.0
        low = [min(vertex[i] for vertex in self.vertices) for i in range(3)]
        high = [max(vertex[i] for vertex in self.vertices) for i in range(3)]
        center = tuple((a + b) / 2 for a, b in zip(low, high))
        return center, max(math.dist(center, vertex) for vertex in self.vertices)
def _place(pos, rot, scale):
    sx, sy, sz = scale if isinstance(scale, (tuple, list)) else (scale, scale, scale)
    ax, ay, az = (math.radians(angle) for angle in rot)
    sin_x, cos_x, sin_y, cos_y, sin_z, cos_z = math.sin(ax), math.cos(ax), math.sin(ay), math.cos(ay), math.sin(az), math.cos(az)
    return ((cos_y * cos_z + sin_y * sin_x * sin_z) * sx, (-cos_y * sin_z + sin_y * sin_x * cos_z) * sy, sin_y * cos_x * sz, pos[0],
            cos_x * sin_z * sx, cos_x * cos_z * sy, -sin_x * sz, pos[1],
            (-sin_y * cos_z + cos_y * sin_x * sin_z) * sx, (sin_y * sin_z + cos_y * sin_x * cos_z) * sy, cos_y * cos_x * sz, pos[2])
def box(w=1.0, h=1.0, d=1.0):
    x, y, z = w / 2, h / 2, d / 2
    sides = [
        [(-x, -y, -z), (x, -y, -z), (x, y, -z), (-x, y, -z)],
        [(x, -y, z), (-x, -y, z), (-x, y, z), (x, y, z)],
        [(x, -y, -z), (x, -y, z), (x, y, z), (x, y, -z)],
        [(-x, -y, z), (-x, -y, -z), (-x, y, -z), (-x, y, z)],
        [(-x, y, -z), (x, y, -z), (x, y, z), (-x, y, z)],
        [(-x, -y, z), (x, -y, z), (x, -y, -z), (-x, -y, -z)],
    ]
    vertices = [corner for side in sides for corner in side]
    faces = [(i * 4, i * 4 + 1, i * 4 + 2, i * 4 + 3) for i in range(len(sides))]
    return Shape(vertices, faces, uvs=[(0, 1), (1, 1), (1, 0), (0, 0)] * len(sides))
def plane(w=1.0, d=1.0, cells=1, skip=None):
    if cells < 1:
        raise ValueError("cells は 1 以上")
    if skip is not None and not callable(skip):
        sx0, sx1, sz0, sz1 = skip
        skip = lambda col, row: (sx0 < w * ((col + 0.5) / cells - 0.5) < sx1
                                 and sz0 < d * ((row + 0.5) / cells - 0.5) < sz1)
    vertices, uvs, faces = [], [], []
    for row in range(cells + 1):
        for col in range(cells + 1):
            vertices.append((w * (col / cells - 0.5), 0.0, d * (row / cells - 0.5)))
            uvs.append((col, cells - row))
    for row in range(cells):
        for col in range(cells):
            if skip is not None and skip(col, row):
                continue
            a = row * (cells + 1) + col
            faces.append((a, a + 1, a + cells + 2, a + cells + 1))
    return Shape(vertices, faces, uvs=uvs)
def disc(radius=0.5, sides=16):
    if sides < 3:
        raise ValueError("sides は 3 以上")
    ring = [(math.cos(math.tau * i / sides), math.sin(math.tau * i / sides)) for i in range(sides)]
    return Shape([(x * radius, 0.0, z * radius) for x, z in ring], [tuple(range(sides))],
                 uvs=[(0.5 + x / 2, 0.5 - z / 2) for x, z in ring])
def cylinder(radius=0.5, height=1.0, sides=16):
    if sides < 3:
        raise ValueError("sides は 3 以上")
    y = height / 2
    ring = [(math.cos(math.tau * i / sides), math.sin(math.tau * i / sides)) for i in range(sides + 1)]
    vertices, uvs, faces = [], [], []
    for i in range(sides):
        (x0, z0), (x1, z1) = ring[i], ring[i + 1]
        faces.append(tuple(range(len(vertices), len(vertices) + 4)))
        vertices += [(x0 * radius, -y, z0 * radius), (x1 * radius, -y, z1 * radius),
                     (x1 * radius, y, z1 * radius), (x0 * radius, y, z0 * radius)]
        uvs += [(i / sides, 1), ((i + 1) / sides, 1), ((i + 1) / sides, 0), (i / sides, 0)]
    for side, order in ((y, range(sides)), (-y, range(sides - 1, -1, -1))):
        faces.append(tuple(range(len(vertices), len(vertices) + sides)))
        vertices += [(ring[i][0] * radius, side, ring[i][1] * radius) for i in order]
        uvs += [(0.5 + ring[i][0] / 2, 0.5 - ring[i][1] / 2) for i in order]
    return Shape(vertices, faces, uvs=uvs)
class Texture:
    def __init__(self, number):
        self.number = number
class Mesh:
    def __init__(self, number, triangles):
        self.number = number
        self.triangles = triangles
_pack_draw = struct.Struct("<H9f3B").pack
_pack_many = struct.Struct("<H6f3BI").pack
_pack_between = struct.Struct("<H11f3B").pack
MESH_UNLIT = 1
MESH_SHADE = 2
SHADOW_LIFT = 0.02
def _render_path(game_dir):
    return backend.current().program(game_dir, RENDER_DIR, RENDER_DEVICE, RENDER_HOST)
class View:
    def __init__(self, game, size=320):
        self.w, self.h = (size, size) if isinstance(size, int) else (int(size[0]), int(size[1]))
        if not (SIZE_MIN <= self.w <= SIZE_MAX and SIZE_MIN <= self.h <= SIZE_MAX):
            raise ValueError("size は、%d〜%d" % (SIZE_MIN, SIZE_MAX))
        self.game = game
        self._proc = None
        self._tex = None
        path = _render_path(game.game_dir)
        if not path:
            raise G3dError("3D の描画のプログラムがありません（%s の中）。%s"
                           % (os.path.join(game.game_dir, RENDER_DIR), HOW_TO_BUILD))
        try:
            tuning = os.environ.get(TUNING_ENV, "").split()
            self._proc = backend.current().spawn([path, str(self.w), str(self.h)] + tuning, game.game_dir)
        except OSError as e:
            raise G3dError("3D の描画のプログラムを動かせません: %s。%s" % (e, HOW_TO_BUILD))
        game.add_closer(self.close)
        hello = self._read(8)
        if hello != b"G3D6" + struct.pack("<HH", self.w, self.h):
            raise G3dError("3D の描画のプログラムが、このライブラリと合いません。%s" % HOW_TO_BUILD)
        self._pixels = bytearray(self.w * self.h * 4)
        self._view = memoryview(self._pixels)
        self._tex = game.gfx.stream(self.w, self.h)
        self._eye, self._at, self._fov = (0.0, 0.0, -5.0), (0.0, 0.0, 0.0), 60.0
        self._light, self._ambient = None, 0.4
        self._fog = None
        self._background = (0, 0, 0)
        self._draws = bytearray()
        self._count = 0
        self._many = bytearray()
        self._many_count = 0
        self._between = bytearray()
        self._between_count = 0
        self._textures = 0
        self._meshes = 0
        self._shadow = None
        self._shown = 0
        self._slow = 0
        self._spent = 0.0
        self._worst = 0.0
        self._render = 0.0
        self._reply = 0.0
        game.log("g3d: %dx%d %s%s" % (self.w, self.h, os.path.basename(path),
                                     " tuning=%s" % ",".join(tuning) if tuning else ""))
    def texture(self, path):
        full = os.path.join(self.game.game_dir, path)
        if not os.path.isfile(full):
            raise G3dError("絵のファイルがありません: %s" % full)
        name = os.path.abspath(full).encode("utf-8")
        self._textures += 1
        self._ask(b"P" + struct.pack("<HH", self._textures, len(name)) + name)
        return Texture(self._textures)
    def texture_rows(self, rows, color):
        if not rows or not len(rows[0]) or any(len(row) != len(rows[0]) for row in rows):
            raise ValueError("絵の行の長さが、そろっていません（または、空です）")
        if len(rows) > TEXTURE_MAX or len(rows[0]) > TEXTURE_MAX:
            raise ValueError("絵は、縦横とも %d まで" % TEXTURE_MAX)
        self._textures += 1
        self._ask(b"T" + struct.pack("<HHH", self._textures, len(rows[0]), len(rows)) + rows_to_rgba(rows, color))
        return Texture(self._textures)
    def mesh(self, shape, texture=None, color=(255, 255, 255), lit=True, blend=None):
        if blend not in (None, "multiply"):
            raise ValueError('blend は、None か "multiply"')
        flags = (0 if lit else MESH_UNLIT) | (MESH_SHADE if blend else 0)
        triangles = shape.triangles()
        data = bytearray()
        for (x, y, z), (u, v), tint in zip(shape.vertices, shape.uvs, shape.colors):
            data += struct.pack("<5f4B", x, y, z, u, v, tint[0] * color[0] // 255, tint[1] * color[1] // 255,
                                tint[2] * color[2] // 255, 255)
        for triangle in triangles:
            data += struct.pack("<3I", *triangle)
        self._meshes += 1
        self._ask(b"M" + struct.pack("<HiIIB", self._meshes, texture.number if texture and not blend else -1,
                                     len(shape.vertices), len(triangles), flags) + data)
        return Mesh(self._meshes, len(triangles))
    def camera(self, eye, look_at, fov=60):
        self._eye, self._at, self._fov = tuple(eye), tuple(look_at), float(fov)
    def light(self, direction, ambient=0.4):
        self._light, self._ambient = (tuple(direction) if direction else None), float(ambient)
    def fog(self, color, near, far):
        self._fog = (tuple(color), float(near), float(far)) if color else None
    def background(self, color):
        self._background = tuple(color)
    def reaches(self, center, radius=0.0):
        if self._fog is None:
            return True
        reach = self._fog[2] + radius
        ex, ey, ez = self._eye
        return (center[0] - ex) ** 2 + (center[1] - ey) ** 2 + (center[2] - ez) ** 2 < reach * reach
    def draw(self, mesh, pos=(0, 0, 0), rot=(0, 0, 0), scale=1, color=None):
        if rot[0].__class__ is tuple or rot[0].__class__ is list:
            rot = g3drot.euler(rot)
        if scale.__class__ is tuple or scale.__class__ is list:
            sx, sy, sz = scale
        else:
            sx = sy = sz = scale
        if color is None:
            r = g = b = 255
        else:
            r, g, b = color
        self._draws += _pack_draw(mesh.number, pos[0], pos[1], pos[2], rot[0], rot[1], rot[2], sx, sy, sz, r, g, b)
        self._count += 1
    def draw_between(self, mesh, a, b, width=1.0, depth=None, face=(1.0, 0.0, 0.0), color=None):
        if color is None:
            r = g = b_ = 255
        else:
            r, g, b_ = color
        self._between += _pack_between(mesh.number, a[0], a[1], a[2], b[0], b[1], b[2], width, width if depth is None else depth,
                                       face[0], face[1], face[2], r, g, b_)
        self._between_count += 1
    def shadow(self, pos, radius=0.5, strength=0.5):
        if self._shadow is None:
            self._shadow = self.mesh(disc(0.5), blend="multiply")
        level = max(0, min(255, int(255 * (1.0 - strength))))
        self.draw(self._shadow, pos=(pos[0], pos[1] + SHADOW_LIFT, pos[2]), scale=radius * 2,
                  color=(level, level, level))
    def orbit(self, center, radius, height, angle, fov=60):
        a = math.radians(angle)
        self.camera(eye=(center[0] + math.sin(a) * radius, center[1] + height, center[2] + math.cos(a) * radius),
                    look_at=center, fov=fov)
    def draw_many(self, mesh, positions, rot=(0, 0, 0), scale=1, color=None):
        if positions.__class__ is array:
            flat = positions
            if flat.typecode != "f":
                raise ValueError('positions に array を渡すときは、array("f")')
        else:
            flat = array("f", chain.from_iterable(positions))
        if len(flat) % 3:
            raise ValueError("positions は、(x, y, z) の一覧（数が、3 つずつ）")
        if not flat:
            return
        if sys.byteorder != "little":
            flat = array("f", flat)
            flat.byteswap()
        if scale.__class__ is tuple or scale.__class__ is list:
            sx, sy, sz = scale
        else:
            sx = sy = sz = scale
        r, g, b = (255, 255, 255) if color is None else color
        self._many += _pack_many(mesh.number, rot[0], rot[1], rot[2], sx, sy, sz, r, g, b, len(flat) // 3)
        self._many += flat.tobytes()
        self._many_count += 1
    def show(self, x=0, y=0, w=WIDTH, h=HEIGHT):
        started = time.perf_counter()
        light, fog = self._light or (0.0, -1.0, 0.0), self._fog or ((0, 0, 0), 0.0, 0.0)
        head = struct.pack("<3BB3f3ff3ff3BxffIII",
                           *self._background[:3], (1 if self._light else 0) | (2 if self._fog else 0),
                           *self._eye, *self._at, self._fov, *light, self._ambient,
                           *fog[0][:3], fog[1], fog[2], self._count, self._many_count, self._between_count)
        draws, self._draws, self._count = self._draws, bytearray(), 0
        many, self._many, self._many_count = self._many, bytearray(), 0
        between, self._between, self._between_count = self._between, bytearray(), 0
        self._ask(b"F" + head + draws + many + between)
        render, = struct.unpack("<I", self._read(4))
        got = 0
        while got < len(self._pixels):
            count = self._proc.stdout.readinto(self._view[got:])
            if not count:
                raise self._stopped()
            got += count
        received = time.perf_counter()
        self._tex.update(self._pixels)
        self._tex.draw(x, y, w, h)
        spent = time.perf_counter() - started
        self._shown += 1
        self._spent += spent
        self._worst = max(self._worst, spent)
        self._slow += spent > 1.0 / self.game.fps
        self._render += render / 1e6
        self._reply += received - started
    def close(self):
        proc, self._proc = self._proc, None
        if not proc:
            return
        if self._shown:
            count = self._shown
            self.game.log("g3d: frames=%d average=%.1fms worst=%.1fms render=%.1fms pipe=%.1fms upload=%.1fms slow=%d" % (
                count, self._spent / count * 1000, self._worst * 1000, self._render / count * 1000,
                (self._reply - self._render) / count * 1000, (self._spent - self._reply) / count * 1000, self._slow))
        try:
            proc.stdin.close()
        except OSError:
            pass
        try:
            proc.wait(timeout=1)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        proc.stdout.close()
        if self._tex:
            self._tex.close()
            self._tex = None
    def _stopped(self):
        code = self._proc.poll() if self._proc else None
        return G3dError("3D の描画のプログラムが止まりました（終了コード %s。理由は、記録の g3d: の行）" % code)
    def _read(self, size):
        data = b""
        while len(data) < size:
            part = self._proc.stdout.read(size - len(data))
            if not part:
                raise self._stopped()
            data += part
        return data
    def _ask(self, data):
        if not self._proc:
            raise G3dError("この View は、もう閉じています")
        try:
            view = memoryview(data)
            while view:
                view = view[self._proc.stdin.write(view):]
        except OSError:
            raise self._stopped()
        if self._read(1) != b"\x00":
            size, = struct.unpack("<H", self._read(2))
            raise G3dError(self._read(size).decode("utf-8", "replace"))
