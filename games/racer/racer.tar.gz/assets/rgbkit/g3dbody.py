import math
STEP = 1.0 / 60
EPS = 1e-4
FLOOR = "floor"
EDGE = "edge"
class Box:
    __slots__ = ("x0", "x1", "y0", "y1", "z0", "z1", "dx", "dy", "dz", "tag")
    def __init__(self, x0, x1, y0, y1, z0, z1, tag=None):
        self.x0, self.x1 = float(min(x0, x1)), float(max(x0, x1))
        self.y0, self.y1 = float(min(y0, y1)), float(max(y0, y1))
        self.z0, self.z1 = float(min(z0, z1)), float(max(z0, z1))
        self.dx = self.dy = self.dz = 0.0
        self.tag = tag
    @classmethod
    def at(cls, center, size, tag=None):
        (x, y, z), (w, h, d) = center, size
        return cls(x - w / 2, x + w / 2, y - h / 2, y + h / 2, z - d / 2, z + d / 2, tag)
    @property
    def center(self):
        return ((self.x0 + self.x1) / 2, (self.y0 + self.y1) / 2, (self.z0 + self.z1) / 2)
    @property
    def size(self):
        return (self.x1 - self.x0, self.y1 - self.y0, self.z1 - self.z0)
    def grown(self, pad):
        return Box(self.x0 - pad, self.x1 + pad, self.y0, self.y1, self.z0 - pad, self.z1 + pad, tag=self.tag)
    def move_to(self, x, y, z):
        cx, cy, cz = self.center
        dx, dy, dz = x - cx, y - cy, z - cz
        self.x0 += dx
        self.x1 += dx
        self.y0 += dy
        self.y1 += dy
        self.z0 += dz
        self.z1 += dz
        self.dx, self.dy, self.dz = dx, dy, dz
    def place(self, x, y, z):
        self.move_to(x, y, z)
        self.dx = self.dy = self.dz = 0.0
class Mover:
    def __init__(self, box, to, period=5.0, phase=0.0):
        if period <= 0:
            raise ValueError("period は、0 より大きい数")
        self.box = box
        self.home = box.center
        self.to = tuple(float(value) for value in to)
        self.period, self.phase = float(period), float(phase)
        self.time = 0.0
    def center(self, time):
        k = 0.5 - 0.5 * math.cos(math.tau * (time / self.period + self.phase))
        return (self.home[0] + self.to[0] * k, self.home[1] + self.to[1] * k, self.home[2] + self.to[2] * k)
    def advance(self, dt):
        self.time += dt
        self.box.move_to(*self.center(self.time))
    def place(self, time=0.0):
        self.time = float(time)
        self.box.place(*self.center(self.time))
class Event:
    __slots__ = ("kind", "box", "speed", "axis", "normal")
    def __init__(self, kind, box, speed=0.0, axis=None, normal=None):
        self.kind, self.box, self.speed, self.axis, self.normal = kind, box, speed, axis, normal
    def __repr__(self):
        return "Event(%r, %r, %.2f)" % (self.kind, self.box, self.speed)
class Body:
    def __init__(self, pos=(0.0, 0.0, 0.0), width=0.7, height=1.5, eye=1.2, gravity=18.0, jump_speed=10.0, jumps=1,
                 max_fall=20.0, coyote=0.1, air_control=1.0, floor=0.0, edge=None):
        self.width, self.height, self.eye = float(width), float(height), float(eye)
        self.gravity, self.jump_speed, self.jumps = float(gravity), float(jump_speed), int(jumps)
        self.max_fall, self.coyote, self.air_control = float(max_fall), float(coyote), float(air_control)
        self.floor, self.edge = floor, edge
        self.place(pos)
    def place(self, pos, on=FLOOR):
        self.x, self.y, self.z = (float(value) for value in pos)
        self.vy = 0.0
        self.grounded = True
        self.jumps_used = 0
        self.surface = on
        self._off = 0.0
        self._free = None
    def release(self):
        self.grounded = False
        self._off = 0.0
    def glide(self, dt, boxes, heading, speed, movers=(), on_land=None, bounce=0.0):
        angle = math.radians(heading)
        dx, dz = math.sin(angle) * speed * dt, math.cos(angle) * speed * dt
        x, z = self.x, self.z
        events = self.update(dt, boxes, dx, dz, movers, on_land)
        ax, az = self.x - x, self.z - z
        if abs(ax - dx) <= 1e-6 and abs(az - dz) <= 1e-6:
            self._free = (heading, speed)
            return events, heading, speed, None
        if self._free is None:
            self._free = (heading, speed)
        before = self._free
        hit = next((event for event in reversed(events) if event.kind == "hit"), None)
        if bounce and hit is not None:
            way = math.radians(before[0])
            vx, vz = math.sin(way) * before[1], math.cos(way) * before[1]
            nx, nz = hit.normal[0], hit.normal[2]
            into = vx * nx + vz * nz
            if into < 0:
                vx -= (1.0 + bounce) * into * nx
                vz -= (1.0 + bounce) * into * nz
            speed = math.hypot(vx, vz)
            if speed > 1e-6:
                heading = math.degrees(math.atan2(vx, vz)) % 360.0
            return events, heading, speed, before
        speed = math.hypot(ax, az) / dt if dt > 0 else 0.0
        if speed > 0.05:
            heading = math.degrees(math.atan2(ax, az)) % 360.0
        else:
            speed = 0.0
        return events, heading, speed, before
    def jump(self):
        if self.jumps_used >= self.jumps:
            return 0
        self.jumps_used += 1
        self.vy = self.jump_speed
        self.grounded = False
        return self.jumps_used
    def bounce(self, speed, jumps_used=1):
        self.vy = float(speed)
        self.grounded = False
        self.jumps_used = jumps_used
        self._off = self.coyote + 1.0
    def follow(self, walker):
        walker.x, walker.y, walker.z = self.x, self.y + self.eye, self.z
    def walk(self, walker, dt, boxes, movers=(), on_land=None):
        walker.look(dt)
        dx, dz = walker.step(dt)
        events = self.update(dt, boxes, dx, dz, movers, on_land)
        self.follow(walker)
        return events
    def update(self, dt, boxes, dx=0.0, dz=0.0, movers=(), on_land=None):
        events = []
        count = max(1, math.ceil(dt / STEP - 1e-6))
        part = dt / count
        for _ in range(count):
            for mover in movers:
                mover.advance(part)
            if movers:
                self._carry(boxes)
            self._move(dx / count, dz / count, part, boxes, on_land, events)
        return events
    def under(self, boxes):
        r, x, y, z = self.width / 2, self.x, self.y, self.z
        top, found = (self.floor, FLOOR) if self.floor is not None and self.floor <= y + EPS else (None, None)
        for b in boxes:
            if b.y1 <= y + EPS and (top is None or b.y1 > top) and x + r > b.x0 and x - r < b.x1 \
                    and z + r > b.z0 and z - r < b.z1:
                top, found = b.y1, b
        return found
    def below(self, boxes):
        found = self.under(boxes)
        if found is None:
            return None
        return self.floor if found is FLOOR else found.y1
    def apex(self, jumps=1, first=None):
        return self._flight(None, jumps, first)[0]
    def _flight(self, rise, jumps, first):
        first = self.jump_speed if first is None else first
        y = top = seconds = 0.0
        steps = last = 0
        for jump in range(jumps):
            vy = first if jump == 0 else self.jump_speed
            while True:
                vy = max(-self.max_fall, vy - self.gravity * STEP)
                if vy <= 0 and (jump < jumps - 1 or rise is None):
                    break
                y += vy * STEP
                steps += 1
                top = max(top, y)
                if rise is not None and y >= rise:
                    last = steps
                if vy <= 0 and (y < rise or steps > 100000):
                    break
        seconds = last * STEP
        return top, seconds
    def reach(self, rise, speed, jumps=1, first=None):
        top, seconds = self._flight(rise, jumps, first)
        if rise > top:
            return 0.0
        return speed * self.air_control * seconds
    def _carry(self, boxes):
        r, h = self.width / 2, self.height
        riding = self.surface if self.grounded and self.surface is not FLOOR else None
        if riding is not None and (riding.dx or riding.dy or riding.dz):
            self.x += riding.dx
            self.z += riding.dz
            self.y = riding.y1
        for b in boxes:
            if b is riding or not (b.dx or b.dy or b.dz):
                continue
            if not (self.y < b.y1 - EPS and self.y + h > b.y0 + EPS and self.x + r > b.x0 and self.x - r < b.x1
                    and self.z + r > b.z0 and self.z - r < b.z1):
                continue
            if self.y >= b.y1 - max(b.dy, 0.0) - EPS:
                continue
            if b.dx or b.dz:
                if b.dx > 0:
                    self.x = b.x1 + r
                elif b.dx < 0:
                    self.x = b.x0 - r
                if b.dz > 0:
                    self.z = b.z1 + r
                elif b.dz < 0:
                    self.z = b.z0 - r
            elif b.dy < 0:
                self.y = b.y0 - h
                self.vy = min(self.vy, 0.0)
    def _move(self, dx, dz, dt, boxes, on_land, events):
        r, h = self.width / 2, self.height
        y = self.y
        if not self.grounded:
            dx *= self.air_control
            dz *= self.air_control
        x = self.x + dx
        if dx:
            for b in boxes:
                if y < b.y1 - EPS and y + h > b.y0 + EPS and self.z + r > b.z0 and self.z - r < b.z1 \
                        and x + r > b.x0 and x - r < b.x1:
                    if dx > 0 and self.x + r <= b.x0 + EPS:
                        x = b.x0 - r
                        events.append(Event("hit", b, axis="x", normal=(-1.0, 0.0, 0.0)))
                    elif dx < 0 and self.x - r >= b.x1 - EPS:
                        x = b.x1 + r
                        events.append(Event("hit", b, axis="x", normal=(1.0, 0.0, 0.0)))
        z = self.z + dz
        if dz:
            for b in boxes:
                if y < b.y1 - EPS and y + h > b.y0 + EPS and x + r > b.x0 and x - r < b.x1 \
                        and z + r > b.z0 and z - r < b.z1:
                    if dz > 0 and self.z + r <= b.z0 + EPS:
                        z = b.z0 - r
                        events.append(Event("hit", b, axis="z", normal=(0.0, 0.0, -1.0)))
                    elif dz < 0 and self.z - r >= b.z1 - EPS:
                        z = b.z1 + r
                        events.append(Event("hit", b, axis="z", normal=(0.0, 0.0, 1.0)))
        if self.edge is not None:
            if abs(x) > self.edge:
                x = max(-self.edge, min(self.edge, x))
                events.append(Event("hit", EDGE, axis="x", normal=(-1.0 if x > 0 else 1.0, 0.0, 0.0)))
            if abs(z) > self.edge:
                z = max(-self.edge, min(self.edge, z))
                events.append(Event("hit", EDGE, axis="z", normal=(0.0, 0.0, -1.0 if z > 0 else 1.0)))
        self.x, self.z = x, z
        rising = self.vy
        self.vy = max(-self.max_fall, self.vy - self.gravity * dt)
        new_y = y + self.vy * dt
        top = landed = None
        if self.vy <= 0:
            if self.floor is not None and new_y <= self.floor:
                top, landed = self.floor, FLOOR
            for b in boxes:
                if new_y <= b.y1 and b.y1 - max(b.dy, 0.0) <= y + EPS and x + r > b.x0 and x - r < b.x1 \
                        and z + r > b.z0 and z - r < b.z1:
                    if top is None or b.y1 > top:
                        top, landed = b.y1, b
        else:
            for b in boxes:
                if y + h - EPS <= b.y0 <= new_y + h and x + r > b.x0 and x - r < b.x1 and z + r > b.z0 and z - r < b.z1:
                    new_y = b.y0 - h
                    self.vy = 0.0
                    events.append(Event("bump", b, rising))
        if landed is None:
            self.y = new_y
            if self.grounded:
                self.grounded = False
                self._off = 0.0
            self._off += dt
            if self.jumps_used == 0 and self._off > self.coyote:
                self.jumps_used = 1
                events.append(Event("leave", self.surface))
            return
        speed = -self.vy if not self.grounded else 0.0
        if on_land and landed is not FLOOR and (not self.grounded or landed is not self.surface):
            if on_land(self, landed, speed) is False:
                self.y = top if self.vy > 0 else new_y
                self.grounded = False
                return
        self.y = top
        if speed > 0:
            events.append(Event("land", landed, speed))
        self.vy = 0.0
        self.grounded = True
        self.jumps_used = 0
        self.surface = landed
        self._off = 0.0
def top(boxes, x, z, floor=0.0, pad=0.0):
    height = floor
    for b in boxes:
        if b.y1 > height and b.x0 - pad <= x <= b.x1 + pad and b.z0 - pad <= z <= b.z1 + pad:
            height = b.y1
    return height
def depth(boxes, x, y, z, side=None, floor=0.0):
    best = (floor - y, (0.0, 1.0, 0.0)) if floor is not None else (0.0, None)
    for b in boxes:
        if b.x0 < x < b.x1 and b.z0 < z < b.z1 and b.y0 <= y < b.y1:
            options = [(b.y1 - y, (0.0, 1.0, 0.0)), (x - b.x0, (-1.0, 0.0, 0.0)), (b.x1 - x, (1.0, 0.0, 0.0)),
                       (z - b.z0, (0.0, 0.0, -1.0)), (b.z1 - z, (0.0, 0.0, 1.0))]
            if side is not None:
                sx, sy, sz = side
                keep = [sy >= b.y1 - 1e-6, sx <= b.x0, sx >= b.x1, sz <= b.z0, sz >= b.z1]
                options = [option for option, ok in zip(options, keep) if ok] or options
            found = min(options, key=lambda option: option[0])
            if found[0] > best[0]:
                best = found
    return best
def gap(a, b):
    dx = max(0.0, a.x0 - b.x1, b.x0 - a.x1)
    dz = max(0.0, a.z0 - b.z1, b.z0 - a.z1)
    return math.hypot(dx, dz)
def hops(body, a, b, speed, margin=1.0, first=None):
    rise = b.y1 - (a.y1 if a is not None else (body.floor or 0.0))
    far = gap(a, b) if a is not None else 0.0
    for jumps in range(1, body.jumps + 1):
        if rise <= body.apex(jumps, first) * margin and far <= body.reach(rise, speed, jumps, first) * margin:
            return jumps
    return 0
def blocked(body, low, high, first=None):
    room = body.apex(body.jumps, first) + body.height
    return high.y0 > low.y1 and gap(low, high) == 0.0 and high.y0 - low.y1 < room
