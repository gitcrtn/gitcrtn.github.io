import random
from . import anim, g3d, g3dtop
STEPS = 32
class Puffs:
    def __init__(self, view, life=0.6, limit=40, rise=0.0, size=None, color=(255, 255, 255), lit=True, shape=None,
                 vary=(1.0, 1.0), seed=1):
        self.view = view
        self.life, self.limit, self.rise, self.vary = float(life), int(limit), float(rise), vary
        self.mesh = view.mesh(shape or g3d.box(), lit=lit)
        size = size if size is not None else anim.Curve([(0.0, 1.0), (1.0, 0.0)])
        self._sizes = size.table(STEPS) if isinstance(size, anim.Curve) else [float(size)] * (STEPS + 1)
        self._colors = color.table(STEPS, whole=True) if isinstance(color, anim.Curve) else [tuple(color)] * (STEPS + 1)
        self.random = random.Random(seed)
        self.items = []
    def __len__(self):
        return len(self.items)
    def clear(self):
        self.items = []
    def emit(self, pos, size=1.0, spread=0.0):
        rnd = self.random
        self.items.append([pos[0] + rnd.uniform(-spread, spread), pos[1], pos[2] + rnd.uniform(-spread, spread), 0.0,
                           size * rnd.uniform(*self.vary), rnd.uniform(0.0, 90.0)])
        del self.items[:-self.limit]
    def step(self, dt):
        rise, life = self.rise * dt, self.life
        for item in self.items:
            item[1] += rise
            item[3] += dt
        self.items = [item for item in self.items if item[3] < life]
    def draw(self):
        view, mesh, sizes, colors, k = self.view, self.mesh, self._sizes, self._colors, STEPS / self.life
        for x, y, z, age, size, turn in self.items:
            i = int(age * k)
            view.draw(mesh, pos=(x, y, z), rot=(0, turn, 0), scale=size * sizes[i], color=colors[i])
class Jet:
    def __init__(self, view, layers, flicker=(0.0, 0.5, 0.2, 0.7, 0.35), rate=60.0, lit=False):
        self.view, self.layers, self.flicker, self.rate = view, list(layers), tuple(flicker), float(rate)
        self.mesh = view.mesh(g3d.box(), lit=lit)
    def draw(self, pos, angle, time):
        shake = anim.flicker(time, self.flicker, self.rate)
        for width, height, length, grow, color in self.layers:
            length += grow * shake
            x, z = g3dtop.world(pos[0], pos[2], angle, -length / 2, 0.0)
            self.view.draw(self.mesh, pos=(x, pos[1], z), rot=(0, angle, 0), scale=(width, height, length), color=color)
