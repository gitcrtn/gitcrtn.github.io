import math
def wrap(angle):
    return (angle + 180.0) % 360.0 - 180.0
def _arc_end(x, z, heading, radius, angle):
    side = 1.0 if angle > 0 else -1.0
    a = math.radians(heading)
    cx, cz = x + math.cos(a) * radius * side, z - math.sin(a) * radius * side
    b = math.radians(heading + angle)
    return cx - math.cos(b) * radius * side, cz + math.sin(b) * radius * side, heading + angle
def solve(parts):
    x = z = heading = 0.0
    free = []
    for part in parts:
        if part[0] == "s":
            a = math.radians(heading)
            if part[1] is None:
                free.append((math.sin(a), math.cos(a)))
            else:
                x += math.sin(a) * part[1]
                z += math.cos(a) * part[1]
        elif part[0] == "c":
            x, z, heading = _arc_end(x, z, heading, part[1], part[2])
        else:
            raise ValueError('並びの書き方が違います: %r（("s", 長さ) か ("c", 半径, 角度)）' % (part,))
    if not free:
        return list(parts)
    if len(free) != 2:
        raise ValueError("長さを決めない直線は、2 本にします")
    (ax, az), (bx, bz) = free
    det = ax * bz - az * bx
    if abs(det) < 1e-6:
        raise ValueError("長さを決めない直線 2 本が、同じ向きです")
    lengths = iter(((-x * bz + z * bx) / det, (-ax * z + az * x) / det))
    return [("s", next(lengths)) if part[0] == "s" and part[1] is None else part for part in parts]
class Path:
    def __init__(self, points):
        count = self.count = len(points)
        if count < 3:
            raise ValueError("点は、3 つ以上")
        self.sx, self.sz, self.dx, self.dz, self.length, self.start = [], [], [], [], [], []
        total = 0.0
        for i in range(count):
            x0, z0 = points[i][0], points[i][1]
            x1, z1 = points[(i + 1) % count][0], points[(i + 1) % count][1]
            length = math.hypot(x1 - x0, z1 - z0)
            if length == 0:
                raise ValueError("同じ場所の点が、続いています（%d 番め）" % i)
            self.sx.append(float(x0))
            self.sz.append(float(z0))
            self.dx.append((x1 - x0) / length)
            self.dz.append((z1 - z0) / length)
            self.length.append(length)
            self.start.append(total)
            total += length
        self.total = total
        headings = []
        for i in range(count):
            if len(points[i]) > 2:
                headings.append(float(points[i][2]))
            else:
                before = math.degrees(math.atan2(self.dx[i - 1], self.dz[i - 1]))
                after = math.degrees(math.atan2(self.dx[i], self.dz[i]))
                headings.append(before + wrap(after - before) / 2)
        self.points = [(self.sx[i], self.sz[i], headings[i]) for i in range(count)]
        self.gap = 0.0
        self.turned = 360.0
        self.parts = None
    @classmethod
    def from_parts(cls, parts, spacing=5.0):
        parts = solve(parts)
        points = []
        x = z = heading = 0.0
        for part in parts:
            if part[0] == "s":
                if part[1] <= 0:
                    raise ValueError("直線の長さが、0 以下です: %r（輪が、閉じません）" % (part,))
                count = max(1, round(part[1] / spacing))
                a = math.radians(heading)
                for i in range(count):
                    d = part[1] * i / count
                    points.append((x + math.sin(a) * d, z + math.cos(a) * d, heading))
                x, z = x + math.sin(a) * part[1], z + math.cos(a) * part[1]
            else:
                radius, angle = part[1], part[2]
                count = max(2, round(abs(math.radians(angle)) * radius / spacing))
                for i in range(count):
                    points.append(_arc_end(x, z, heading, radius, angle * i / count))
                x, z, heading = _arc_end(x, z, heading, radius, angle)
        path = cls(points)
        path.gap, path.turned, path.parts = math.hypot(x, z), heading, parts
        return path
    def locate(self, x, z, near=None, back=4, ahead=8):
        count = self.count
        candidates = range(count) if near is None else [(near + k) % count for k in range(-back, ahead + 1)]
        best, best_far = 0, None
        for i in candidates:
            px, pz = x - self.sx[i], z - self.sz[i]
            along = px * self.dx[i] + pz * self.dz[i]
            along = 0.0 if along < 0.0 else (self.length[i] if along > self.length[i] else along)
            ex, ez = px - self.dx[i] * along, pz - self.dz[i] * along
            far = ex * ex + ez * ez
            if best_far is None or far < best_far:
                best, best_far = i, far
        i = best
        px, pz = x - self.sx[i], z - self.sz[i]
        along = max(0.0, min(self.length[i], px * self.dx[i] + pz * self.dz[i]))
        side = px * self.dz[i] - pz * self.dx[i]
        h0, h1 = self.points[i][2], self.points[(i + 1) % count][2]
        heading = h0 + wrap(h1 - h0) * along / self.length[i]
        return i, (self.start[i] + along) % self.total, side, heading % 360.0
    def place(self, dist, side=0.0):
        dist %= self.total
        low, high = 0, self.count - 1
        while low < high:
            mid = (low + high + 1) // 2
            if self.start[mid] <= dist:
                low = mid
            else:
                high = mid - 1
        i = low
        along = dist - self.start[i]
        h0, h1 = self.points[i][2], self.points[(i + 1) % self.count][2]
        heading = (h0 + wrap(h1 - h0) * along / self.length[i]) % 360.0
        return (self.sx[i] + self.dx[i] * along + self.dz[i] * side,
                self.sz[i] + self.dz[i] * along - self.dx[i] * side, heading, i)
    def advance(self, before, now):
        total = self.total
        return (now - before + total / 2) % total - total / 2
    def clamp(self, x, z, limit, near=None):
        i, dist, side, heading = self.locate(x, z, near)
        over = abs(side) - limit
        if over <= 0:
            return x, z, i, dist, side, heading, 0.0
        sign = 1.0 if side > 0 else -1.0
        return (x - self.dz[i] * over * sign, z + self.dx[i] * over * sign, i, dist, limit * sign, heading, over)
    def fit(self, x, y, size, margin=0.0, pad=0):
        return Fit(self, x, y, size, margin, pad)
class Fit:
    def __init__(self, path, x, y, size, margin=0.0, pad=0):
        self.path = path
        xs = [point[0] for point in path.points]
        zs = [point[1] for point in path.points]
        low_x, high_x, low_z, high_z = min(xs) - margin, max(xs) + margin, min(zs) - margin, max(zs) + margin
        self.scale = (size - pad * 2) / max(high_x - low_x, high_z - low_z)
        self.left = x + (size - (high_x - low_x) * self.scale) / 2 - low_x * self.scale
        self.top = y + (size - (high_z - low_z) * self.scale) / 2 + high_z * self.scale
    def at(self, x, z):
        return self.left + x * self.scale, self.top - z * self.scale
    def outline(self, every=1):
        return [self.at(point[0], point[1]) for point in self.path.points[::every]]
class Laps:
    def __init__(self, path, laps=3):
        self.total, self.laps = path.total, int(laps)
        self._names = []
        self._run, self._time, self._done, self._times, self._lap_start = {}, {}, {}, {}, {}
        self._finished = []
    def join(self, name, behind=0.0):
        if name in self._run:
            raise ValueError("もう、足してあります: %r" % (name,))
        self._names.append(name)
        self._run[name], self._time[name], self._done[name] = -float(behind), 0.0, 0
        self._times[name], self._lap_start[name] = [], 0.0
    def add(self, name, moved, dt=0.0):
        self._run[name] += moved
        if name in self._finished:
            return 0
        self._time[name] += dt
        if self._run[name] < (self._done[name] + 1) * self.total:
            return 0
        self._done[name] += 1
        self._times[name].append(self._time[name] - self._lap_start[name])
        self._lap_start[name] = self._time[name]
        if self._done[name] >= self.laps:
            self._finished.append(name)
        return self._done[name]
    def lap(self, name):
        return min(self.laps, self._done[name] + 1)
    def times(self, name):
        return list(self._times[name])
    def time(self, name):
        return self._time[name]
    def run(self, name):
        return self._run[name]
    def finished(self, name):
        return name in self._finished
    def order(self):
        racing = [name for name in self._names if name not in self._finished]
        racing.sort(key=lambda name: -self._run[name])
        return self._finished + racing
    def rank(self, name):
        return self.order().index(name) + 1
