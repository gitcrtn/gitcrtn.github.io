import math
from . import anim
from .g3d import _place
from .g3drot import UP, angle, apply, cross, is_matrix, mul, orthonormal, turn_about, unit
from .g3drot import about as _about
def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def _unit(a):
    length = math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])
    return (a[0] / length, a[1] / length, a[2] / length) if length > 1e-9 else None
def mix(a, b, t):
    if isinstance(a, dict):
        return {name: mix(a[name], b[name], t) for name in b}
    if isinstance(a, (tuple, list)):
        return tuple(x + (y - x) * t for x, y in zip(a, b))
    return a + (b - a) * t
def bend(a, b, length, toward=(1.0, 0.0, 0.0), length2=None):
    upper, lower = float(length), float(length if length2 is None else length2)
    line = _sub(b, a)
    far = math.sqrt(line[0] ** 2 + line[1] ** 2 + line[2] ** 2)
    far = max(abs(upper - lower) + 1e-4, min(far, upper + lower - 1e-4))
    along = _unit(line) or (0.0, -1.0, 0.0)
    dot = toward[0] * along[0] + toward[1] * along[1] + toward[2] * along[2]
    out = _unit((toward[0] - along[0] * dot, toward[1] - along[1] * dot, toward[2] - along[2] * dot)) or (1.0, 0.0, 0.0)
    part = (upper * upper - lower * lower + far * far) / (2 * far)
    rise = math.sqrt(max(0.0, upper * upper - part * part))
    return tuple(a[i] + along[i] * part + out[i] * rise for i in range(3))
def mirror(points, axis="z"):
    i = "xyz".index(axis)
    return {name: tuple(-value if n == i else value for n, value in enumerate(p)) for name, p in points.items()}
def _placed(pos, rot):
    if is_matrix(rot):
        return (rot[0][0], rot[0][1], rot[0][2], pos[0], rot[1][0], rot[1][1], rot[1][2], pos[1],
                rot[2][0], rot[2][1], rot[2][2], pos[2])
    return _place(pos, rot, 1.0)
def turn(vector, rot):
    m = _placed((0.0, 0.0, 0.0), rot)
    x, y, z = vector
    return (m[0] * x + m[1] * y + m[2] * z, m[4] * x + m[5] * y + m[6] * z, m[8] * x + m[9] * y + m[10] * z)
def place(points, pos=(0.0, 0.0, 0.0), rot=(0.0, 0.0, 0.0)):
    m = _placed(pos, rot)
    return {name: (m[0] * x + m[1] * y + m[2] * z + m[3], m[4] * x + m[5] * y + m[6] * z + m[7],
                   m[8] * x + m[9] * y + m[10] * z + m[11]) for name, (x, y, z) in points.items()}
class Layer:
    def __init__(self, seconds, weight=None):
        self.seconds, self.curve = float(seconds), weight
        self.time = None
    def start(self):
        self.time = 0.0
    def stop(self):
        self.time = None
    def update(self, dt):
        if self.time is not None:
            self.time += dt
            if self.time >= self.seconds:
                self.time = None
    @property
    def active(self):
        return self.time is not None
    @property
    def t(self):
        return self.time / self.seconds if self.time is not None else 0.0
    @property
    def weight(self):
        if self.time is None:
            return 0.0
        return self.curve.at(self.time / self.seconds) if self.curve is not None else 1.0
class Rig:
    def __init__(self, view, mesh, bones):
        self.view, self.mesh = view, mesh
        self.bones = [tuple(bone) for bone in bones]
    def draw(self, points, face=(1.0, 0.0, 0.0)):
        between = self.view.draw_between
        mesh = self.mesh
        for a, b, width, depth, color in self.bones:
            between(mesh, points[a], points[b], width, depth, face, color)
def settle(points, pos, toward, ground=None, angles=range(40, 141, 5), thick=0.13, clear=0.10, weight=2.0, boxes=None, floor=0.0):
    if ground is None and boxes is None:
        raise ValueError("ground か boxes を渡します")
    near, base = (), None
    if boxes is not None:
        far = max(math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) for p in points) + 1e-6
        near = [(b.x0, b.x1, b.z0, b.z1, b.y1) for b in boxes
                if b.x0 - far <= pos[0] <= b.x1 + far and b.z0 - far <= pos[2] <= b.z1 + far and b.y1 > floor]
        base = floor
    px, py, pz = pos
    yaw = math.radians(toward - 90.0)
    sin_y, cos_y = math.sin(yaw), math.cos(yaw)
    count = len(points)
    best = None
    for angle in angles:
        sin_z, cos_z = math.sin(math.radians(-angle)), math.cos(math.radians(-angle))
        rest = math.sin(math.radians(angle)) * thick
        lift = total = 0.0
        for p in points:
            x, y = p[0] * cos_z - p[1] * sin_z, p[0] * sin_z + p[1] * cos_z + rest
            wx, wz = px + cos_y * x + sin_y * p[2], pz - sin_y * x + cos_y * p[2]
            height = base
            for x0, x1, z0, z1, y1 in near:
                if y1 > height and x0 <= wx <= x1 and z0 <= wz <= z1:
                    height = y1
            if ground is not None:
                height = ground(wx, wz) if height is None else max(height, ground(wx, wz))
            under = height - py
            if under + clear - y > lift:
                lift = under + clear - y
            total += y
        score = total / count + lift * weight + abs(angle - 90.0) * 1e-4
        if best is None or score < best[0]:
            best = (score, angle, lift)
    return best[1], best[2]
FALL_ANGLE = 90.0
FALL_CURVE = anim.Curve([(0.0, 0.0), (0.07, 22.0), (0.17, FALL_ANGLE), (0.215, FALL_ANGLE - 9.0), (0.26, FALL_ANGLE),
                         (0.74, FALL_ANGLE), (0.86, 50.0), (1.0, 0.0)])
class Fall:
    def __init__(self, m, toward=None, up=UP, flip=None, curve=FALL_CURVE, angle=FALL_ANGLE, rate=720.0, get_up=0.74,
                 slack=45.0, side=1, angles=tuple(range(40, 141, 5)), settle_rate=0.25, settle_move=0.05):
        self.m = orthonormal(m)
        self.up = tuple(up)
        self.curve, self.angle, self.rate, self.get_up = curve, float(angle), float(rate), float(get_up)
        self.slack, self.side, self.angles = float(slack), (1 if side >= 0 else -1), tuple(angles)
        self.settle_rate, self.settle_move = float(settle_rate), float(settle_move)
        axis, way, pitch = flip if flip is not None else (apply(self.m, (1.0, 0.0, 0.0)), 0, 0.0)
        self.axis, self.flip_way, self.pitch = unit(axis) or (1.0, 0.0, 0.0), int(way), float(pitch)
        self.base = None
        self.tumbling = False
        self.lie = 0.0
        self.fall = 0.0
        self.lying = 0.0
        self.part = 0.0
        self.way = (0.0, 0.0, 1.0)
        self.toward = 0.0
        self.chest_turn = 0.0
        self.rest = None
        self.settled = None
        self.settles = 0
        self.again(toward)
    def again(self, toward=None):
        self.tumbling = self.flip_way != 0 and abs(anim.wrap(self.pitch)) > self.slack
        if self.tumbling:
            lie = (math.floor((self.pitch - 90.0) / 180.0) if self.flip_way < 0 else math.ceil((self.pitch - 90.0) / 180.0)) \
                * 180.0 + 90.0
            if (lie - self.pitch) * self.flip_way <= 0:
                lie += 180.0 * self.flip_way
            self.lie = lie
            if self.base is not None:
                self.m, self.base = self.base, None
        elif self.base is None:
            self.base = self.m
        if toward is not None:
            self.fall_to(toward)
    def fall_to(self, toward):
        toward = unit(toward)
        if toward is None:
            return
        self.way = toward
        if abs(toward[0]) + abs(toward[2]) > 1e-6:
            self.toward = math.degrees(math.atan2(toward[0], toward[2]))
        if self.base is not None:
            found = turn_about(apply(self.base, UP), apply(self.base, (0.0, 0.0, 1.0)), toward)
            if found is not None:
                self.chest_turn = anim.wrap(found - 90.0 * self.side)
    def step(self, dt, part, after=None):
        self.part = part if after is None else after
        if self.tumbling:
            if part >= self.get_up:
                target, rate = round(self.pitch / 360.0) * 360.0, self.rate * 0.5
            else:
                target, rate = self.lie, self.rate
            step = anim.approach(self.pitch, target, rate * dt) - self.pitch
            if step:
                self.m = orthonormal(mul(_about(self.axis, step), self.m))
            self.pitch += step
        else:
            base = self.base if self.base is not None else self.m
            top = apply(base, UP)
            off = angle(top, self.up)
            if off > 1e-9:
                base = orthonormal(mul(_about(unit(cross(top, self.up)) or self.axis, min(off, self.rate * dt)), base))
            self.base = base
            self.lying = self.curve.at(self.part) / self.angle
            self._bend()
            self.pitch = 0.0
        return self.m
    def _bend(self):
        self.fall = self.lying * (self.rest[0] if self.rest is not None else self.angle)
        turn = self.chest_turn * min(1.0, self.lying * 1.5)
        self.m = orthonormal(mul(self.base, mul(_about(UP, turn), _about((0.0, 0.0, 1.0), -self.fall * self.side))))
    def rest_on(self, shape, feet, boxes, thick, clear, depth=None, contact=None, height=0.0):
        if self.base is None or self.lying <= 0.0:
            self.rest = None
            return
        if not boxes:
            found = self.angle if depth is None or contact is None else self._wall_rest(shape, contact, height, thick, clear, depth)
            self.rest = (found, 0.0) if self.rest is None else (self.rest[0] + (found - self.rest[0]) * self.settle_rate, 0.0)
            self._bend()
            return
        key = (feet, self.toward)
        last = self.settled
        if self.lying < 1.0 or last is None or math.dist(last[0][0], feet) > self.settle_move or abs(last[0][1] - self.toward) > 1.0:
            self.settled = (key, settle(shape, feet, self.toward, boxes=boxes, angles=self.angles, thick=thick, clear=clear,
                                        weight=2.0))
            self.settles += 1
        found, lift = self.settled[1]
        if self.rest is None:
            self.rest = (found, lift)
        else:
            self.rest = (self.rest[0] + (found - self.rest[0]) * self.settle_rate,
                         self.rest[1] + (lift - self.rest[1]) * self.settle_rate)
        self._bend()
    def _wall_rest(self, shape, contact, height, thick, clear, depth):
        least = None
        for tried in sorted(self.angles, key=lambda a: abs(a - self.angle)):
            lying = mul(self.base, mul(_about(UP, self.chest_turn), _about((0.0, 0.0, 1.0), -tried * self.side)))
            lift = apply(self.base, (0.0, math.sin(math.radians(tried)) * thick + height, 0.0))
            worst = max(depth(*(contact[i] + lift[i] + v for i, v in enumerate(apply(lying, p))), contact)[0] for p in shape)
            if worst <= -clear * 0.5:
                return tried
            if least is None or worst < least[0]:
                least = (worst, tried)
        return least[1]
    def lift(self):
        return self.lying * self.rest[1] if self.rest is not None else 0.0
    def stand(self):
        m = self.base if self.base is not None else self.m
        self.m, self.base = m, None
        self.fall, self.lying, self.rest, self.settled, self.tumbling = 0.0, 0.0, None, None, False
        return m
