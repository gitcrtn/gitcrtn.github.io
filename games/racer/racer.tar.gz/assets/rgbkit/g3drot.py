import math
UP = (0.0, 1.0, 0.0)
IDENTITY = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def unit(a):
    length = math.sqrt(dot(a, a))
    return (a[0] / length, a[1] / length, a[2] / length) if length > 1e-9 else None
def angle(a, b):
    return math.degrees(math.acos(max(-1.0, min(1.0, dot(a, b)))))
def turn_about(axis, a, b):
    pa = unit(tuple(a[i] - dot(a, axis) * axis[i] for i in range(3)))
    pb = unit(tuple(b[i] - dot(b, axis) * axis[i] for i in range(3)))
    if pa is None or pb is None:
        return None
    return math.degrees(math.atan2(dot(axis, cross(pa, pb)), dot(pa, pb)))
def about(axis, degrees):
    axis = unit(axis)
    if axis is None:
        raise ValueError("軸の長さが 0 です")
    t = math.radians(degrees)
    c, s = math.cos(t), math.sin(t)
    x, y, z = axis
    k = 1.0 - c
    return ((c + x * x * k, x * y * k - z * s, x * z * k + y * s),
            (y * x * k + z * s, c + y * y * k, y * z * k - x * s),
            (z * x * k - y * s, z * y * k + x * s, c + z * z * k))
def yaw(heading):
    return about(UP, heading)
def mul(a, b):
    return tuple(tuple(a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j] for j in range(3)) for i in range(3))
def apply(m, v):
    return (m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
            m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
            m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2])
def back(m, v):
    return (m[0][0] * v[0] + m[1][0] * v[1] + m[2][0] * v[2],
            m[0][1] * v[0] + m[1][1] * v[1] + m[2][1] * v[2],
            m[0][2] * v[0] + m[1][2] * v[1] + m[2][2] * v[2])
def between(a, b):
    trace = sum(a[k][i] * b[k][i] for i in range(3) for k in range(3))
    return math.degrees(math.acos(max(-1.0, min(1.0, (trace - 1.0) / 2.0))))
def orthonormal(m):
    up = unit((m[0][1], m[1][1], m[2][1]))
    ahead = (m[0][2], m[1][2], m[2][2])
    ahead = unit(tuple(ahead[i] - dot(ahead, up) * up[i] for i in range(3)))
    side = cross(up, ahead)
    return tuple((side[i], up[i], ahead[i]) for i in range(3))
def euler(m):
    sin_x = max(-1.0, min(1.0, -m[1][2]))
    if abs(sin_x) > 0.99999:
        return (math.degrees(math.asin(sin_x)), math.degrees(math.atan2(-m[2][0], m[0][0])), 0.0)
    return (math.degrees(math.asin(sin_x)), math.degrees(math.atan2(m[0][2], m[2][2])),
            math.degrees(math.atan2(m[1][0], m[1][1])))
def is_matrix(rot):
    first = rot[0]
    return first.__class__ is tuple or first.__class__ is list
class Spin:
    def __init__(self, m=IDENTITY, rate=(0.0, 0.0, 0.0)):
        self.m = orthonormal(m)
        self.rate = tuple(float(value) for value in rate)
    def speed(self, axis=None):
        if axis is None:
            return math.sqrt(dot(self.rate, self.rate))
        axis = unit(axis)
        return dot(self.rate, axis) if axis else 0.0
    def push(self, axis, force, dt, limit):
        axis = unit(axis)
        if axis is None or not force or dt <= 0:
            return
        now = dot(self.rate, axis)
        limit = abs(limit)
        if force > 0:
            new = now if now >= limit else min(limit, now + force * dt)
        else:
            new = now if now <= -limit else max(-limit, now + force * dt)
        change = new - now
        self.rate = tuple(self.rate[i] + change * axis[i] for i in range(3))
    def damp(self, rate, dt):
        keep = max(0.0, 1.0 - rate * dt)
        self.rate = tuple(value * keep for value in self.rate)
    def set(self, axis, rate):
        axis = unit(axis)
        self.rate = (0.0, 0.0, 0.0) if axis is None else tuple(axis[i] * rate for i in range(3))
    def stop(self):
        self.rate = (0.0, 0.0, 0.0)
    def turn(self, axis, degrees):
        self.m = orthonormal(mul(about(axis, degrees), self.m))
    def step(self, dt):
        amount = math.sqrt(dot(self.rate, self.rate)) * dt
        if amount > 1e-9:
            self.m = orthonormal(mul(about(self.rate, amount), self.m))
        return amount
def launch(m, velocity, up=UP, side=(1.0, 0.0, 0.0), body_up=(0.0, 1.0, 0.0), lean_min=0.2,
           strength=lambda lean: math.sin(math.radians(lean))):
    top = apply(m, body_up)
    travel = unit(velocity)
    axis = None
    if travel is not None:
        across = cross(top, travel)
        if math.sqrt(dot(across, across)) > 0.2:
            axis = unit(across)
    if axis is None:
        axis = unit(apply(m, side))
    lean = turn_about(axis, up, top)
    lean = 0.0 if lean is None else lean
    power = strength(lean)
    way = 0 if abs(power) < lean_min else (1 if power > 0 else -1)
    return axis, way, abs(power), lean
