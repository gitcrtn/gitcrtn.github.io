import math
from .anim import approach
from .gfx import HEIGHT, WIDTH
from .ui import ACCENT, GRAY, PANEL, ROW_H, SELECT, SHADE, WHITE, Overlay, moved
SETTINGS_FILE = "g3dstick.json"
PITCH_LIMIT = 80.0
AIM_LIMIT = 88.0
LOOK_SPEED_MIN = 1
LOOK_SPEED_MAX = 10
LOOK_SPEED_NORMAL = 5
class Walker:
    def __init__(self, game, pos=(0.0, 1.2, 0.0), yaw=0.0, pitch=0.0, speed=3.5, turn=120.0):
        self.game = game
        self.x, self.y, self.z = (float(value) for value in pos)
        self.yaw, self.pitch = float(yaw), float(pitch)
        self.speed, self.turn = float(speed), float(turn)
        saved = game.load_json(SETTINGS_FILE, {})
        saved = saved if isinstance(saved, dict) else {}
        self.invert_x = saved.get("invert_x") is True
        self.invert_y = saved.get("invert_y") is True
        level = saved.get("look_speed")
        self.look_speed = level if type(level) is int and LOOK_SPEED_MIN <= level <= LOOK_SPEED_MAX else LOOK_SPEED_NORMAL
        game.log("g3dstick: settings %s (%s)" % (self._settings_text(), "saved" if saved else "default"))
        game.input.left_stick_counts = False
    def update(self, dt):
        self.look(dt)
        dx, dz = self.step(dt)
        self.x += dx
        self.z += dz
    def look(self, dt):
        look_x, look_y = self.game.input.stick("right")
        turn = self.turn * self.look_speed / LOOK_SPEED_NORMAL * dt
        self.yaw = (self.yaw + (-look_x if self.invert_x else look_x) * turn) % 360
        self.pitch += (look_y if self.invert_y else -look_y) * turn
        self.pitch = max(-PITCH_LIMIT, min(PITCH_LIMIT, self.pitch))
    def step(self, dt):
        side, back = self.game.input.stick("left")
        heading = math.radians(self.yaw)
        sin, cos = math.sin(heading), math.cos(heading)
        step = self.speed * dt
        return ((-back * sin + side * cos) * step, (-back * cos - side * sin) * step)
    def aim(self, view, fov=60, pitch=0.0, yaw=0.0):
        heading = math.radians(self.yaw + yaw)
        tilt = math.radians(max(-AIM_LIMIT, min(AIM_LIMIT, self.pitch + pitch)))
        flat = math.cos(tilt)
        view.camera(eye=(self.x, self.y, self.z),
                    look_at=(self.x + math.sin(heading) * flat, self.y + math.sin(tilt),
                             self.z + math.cos(heading) * flat), fov=fov)
    def open_settings(self):
        return self.game.open(Settings(self))
    def menu_items(self):
        return [("視点の設定", self.open_settings)]
    def save_settings(self):
        self.game.save_json(SETTINGS_FILE, {"invert_x": self.invert_x, "invert_y": self.invert_y,
                                            "look_speed": self.look_speed}, always=True)
    def _settings_text(self):
        return "invert_x=%s invert_y=%s look_speed=%d" % (self.invert_x, self.invert_y, self.look_speed)
class Settings(Overlay):
    ROWS = (("上下", "invert_y"), ("左右", "invert_x"), ("速さ", "look_speed"))
    def __init__(self, walker):
        super().__init__(walker.game)
        self.walker = walker
        self.index = 0
        self._before = walker._settings_text()
    def close(self):
        if self.walker._settings_text() != self._before:
            self.game.log("g3dstick: settings %s (changed)" % self.walker._settings_text())
        super().close()
    def update(self, inp):
        walker = self.walker
        name = self.ROWS[self.index][1]
        if moved(inp, "up"):
            self.index = (self.index - 1) % len(self.ROWS)
        elif moved(inp, "down"):
            self.index = (self.index + 1) % len(self.ROWS)
        elif name == "look_speed" and (moved(inp, "left") or moved(inp, "right")):
            level = walker.look_speed + (1 if moved(inp, "right") else -1)
            if LOOK_SPEED_MIN <= level <= LOOK_SPEED_MAX:
                walker.look_speed = level
                walker.save_settings()
        elif inp.tapped("a"):
            if name != "look_speed":
                setattr(walker, name, not getattr(walker, name))
                walker.save_settings()
        elif inp.tapped("b") or inp.tapped("start"):
            self.close()
    def draw(self, gfx):
        walker = self.walker
        gfx.rect(0, 0, WIDTH, HEIGHT, SHADE)
        w = 480
        h = 96 + ROW_H * len(self.ROWS) + 56
        x, y = (WIDTH - w) // 2, (HEIGHT - h) // 2
        gfx.rect(x, y, w, h, PANEL)
        gfx.rect(x, y, w, 6, ACCENT)
        gfx.text(WIDTH // 2, y + 28, "視点の設定", 30, WHITE, align="center")
        row_y = y + 96
        right = x + w - 48
        for i, (label, name) in enumerate(self.ROWS):
            if i == self.index:
                gfx.rect(x + 16, row_y + 2, w - 32, ROW_H - 4, SELECT)
            gfx.text(x + 48, row_y + 12, label, 28, WHITE)
            if name == "look_speed":
                level = walker.look_speed
                gfx.text(right, row_y + 12, ">", 28, WHITE if level < LOOK_SPEED_MAX else GRAY, align="right")
                gfx.text(right - 78, row_y + 12, str(level), 28, WHITE, align="center")
                gfx.text(right - 156, row_y + 12, "<", 28, WHITE if level > LOOK_SPEED_MIN else GRAY)
            else:
                gfx.text(right, row_y + 12, "リバース" if getattr(walker, name) else "ノーマル", 28, WHITE, align="right")
            row_y += ROW_H
        gfx.text(WIDTH // 2, y + h - 42, "A: 切り替え   左右: 速さ   B: 閉じる", 20, GRAY, align="center")
