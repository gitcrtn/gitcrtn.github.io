import math
def axes(angle):
    a = math.radians(angle)
    s, c = math.sin(a), math.cos(a)
    return (s, c), (c, -s)
def corners(box):
    cx, cz, hf, hr, angle = box
    (fx, fz), (rx, rz) = axes(angle)
    return [(cx + fx * f + rx * r, cz + fz * f + rz * r) for f, r in ((hf, hr), (hf, -hr), (-hf, -hr), (-hf, hr))]
def overlap(a, b):
    pa, pb = corners(a), corners(b)
    for box in (a, b):
        for ax, az in axes(box[4]):
            sa = [x * ax + z * az for x, z in pa]
            sb = [x * ax + z * az for x, z in pb]
            if max(sa) <= min(sb) + 1e-9 or max(sb) <= min(sa) + 1e-9:
                return False
    return True
def inside(box, x0, x1, z0, z1):
    return all(x0 <= x <= x1 and z0 <= z <= z1 for x, z in corners(box))
def local(x, z, angle, px, pz):
    (fx, fz), (rx, rz) = axes(angle)
    dx, dz = px - x, pz - z
    return dx * fx + dz * fz, dx * rx + dz * rz
def world(x, z, angle, f, r):
    (fx, fz), (rx, rz) = axes(angle)
    return x + fx * f + rx * r, z + fz * f + rz * r
