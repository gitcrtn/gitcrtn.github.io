import math
from array import array
WIDTH = 720
HEIGHT = 720
FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/noto-cjk/NotoSansCJKsc-Regular.otf",
    "/System/Library/Fonts/ヒラギノ角ゴシック W4.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]
TEXT_CACHE_MAX = 256
SHAPE_CACHE_MAX = 256
SPRITE_BLANK = (".", " ", 0)
def rows_to_rgba(rows, color):
    blank = bytes(4)
    if isinstance(color, dict):
        dots = {}
        for key, value in color.items():
            dots[key] = bytes((value[0], value[1], value[2], value[3] if len(value) > 3 else 255))
        try:
            return b"".join(blank if cell in SPRITE_BLANK else dots[cell] for row in rows for cell in row)
        except KeyError as e:
            raise ValueError("ドット絵に、色の表に無い文字があります: %r" % e.args[0])
    dot = bytes((color[0], color[1], color[2], color[3] if len(color) > 3 else 255))
    return b"".join(blank if cell in SPRITE_BLANK else dot for row in rows for cell in row)
def line_points(x1, y1, x2, y2, width):
    dx, dy = x2 - x1, y2 - y1
    far = math.hypot(dx, dy)
    if far == 0:
        return []
    nx, ny = -dy / far * width / 2, dx / far * width / 2
    return [x1 + nx, y1 + ny, x2 + nx, y2 + ny, x2 - nx, y2 - ny, x1 + nx, y1 + ny, x2 - nx, y2 - ny, x1 - nx, y1 - ny]
def ring_points(cx, cy, radius, width, start=0.0, end=360.0):
    if radius <= 0 or end <= start:
        return []
    steps = max(2, math.ceil(max(8, min(96, int(radius * 0.75))) * min(360.0, end - start) / 360.0))
    inner = max(0.0, radius - width)
    turns = [math.radians(start + (end - start) * i / steps) for i in range(steps + 1)]
    rim = [(math.cos(a), math.sin(a)) for a in turns]
    points = []
    for (ax, ay), (bx, by) in zip(rim, rim[1:]):
        x1, y1, x2, y2 = cx + ax * radius, cy + ay * radius, cx + bx * radius, cy + by * radius
        if inner <= 0:
            points += [cx, cy, x1, y1, x2, y2]
        else:
            x3, y3, x4, y4 = cx + bx * inner, cy + by * inner, cx + ax * inner, cy + ay * inner
            points += [x1, y1, x2, y2, x3, y3, x1, y1, x3, y3, x4, y4]
    return points
class Packed:
    __slots__ = ("xy", "colors")
    def __init__(self, xy=b"", colors=b""):
        self.xy = xy
        self.colors = colors
    def __add__(self, other):
        return Packed(self.xy + other.xy, self.colors + other.colors)
    def __len__(self):
        return len(self.colors) // 4
def pack(points, color):
    count = len(points) // 2
    return Packed(array("f", points[:count * 2] if len(points) % 2 else points).tobytes(),
                  bytes((color[0], color[1], color[2], color[3] if len(color) > 3 else 255)) * count)
class Sprite:
    def __init__(self, tex, cols, rows, scale):
        self.tex = tex
        self.cols = cols
        self.rows = rows
        self.scale = scale
        self.w = cols * scale
        self.h = rows * scale
def __getattr__(name):
    if name == "Gfx":
        from . import backend
        return backend.current().Gfx
    raise AttributeError("module %r has no attribute %r" % (__name__, name))
