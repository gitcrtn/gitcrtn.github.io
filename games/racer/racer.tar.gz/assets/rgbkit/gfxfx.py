import math
import random
from . import anim
from .gfx import line_points, pack, ring_points
class SpeedLines:
    def __init__(self, count=16, center=(360, 360), inner=150, outer=520, speed=1100.0, length=(40, 140),
                 color=(255, 255, 255), thick=0.4, width=2, seed=2):
        self.count, self.center, self.inner, self.outer = int(count), tuple(center), float(inner), float(outer)
        self.speed, self.length, self.color, self.thick, self.width = float(speed), tuple(length), tuple(color), thick, width
        self.random = random.Random(seed)
        self.lines = []
    def clear(self):
        self.lines = []
    def update(self, dt, on=True):
        if not on:
            self.lines = []
            return
        rnd, move, outer = self.random, self.speed * dt, self.outer
        for line in self.lines:
            line[1] += move
        self.lines = [line for line in self.lines if line[1] < outer]
        last = self.inner + (outer - self.inner) * 0.73
        while len(self.lines) < self.count:
            self.lines.append([rnd.uniform(0.0, math.tau), rnd.uniform(self.inner, last), rnd.uniform(*self.length),
                               rnd.random() < self.thick])
    def draw(self, gfx):
        cx, cy = self.center
        for angle, far, length, thick in self.lines:
            ax, ay = math.cos(angle), math.sin(angle)
            gfx.line(cx + ax * far, cy + ay * far, cx + ax * (far + length), cy + ay * (far + length), self.color,
                     width=self.width if thick else 1)
class Gauge:
    def __init__(self, size=192, start=135.0, sweep=270.0, ticks=11, zones=(), face=(22, 26, 38), rim=(200, 205, 215),
                 needle=(255, 235, 110), edge=(20, 30, 50), needle_from=None, needle_to=None, needle_width=5,
                 follow=6.0, value=0.0):
        self.radius = size / 2
        self.start, self.sweep, self.ticks, self.zones = float(start), float(sweep), int(ticks), list(zones)
        self.face, self.rim, self.needle, self.edge = face, rim, needle, edge
        self.needle_from = self.radius * 0.52 if needle_from is None else needle_from
        self.needle_to = self.radius * 0.92 if needle_to is None else needle_to
        self.needle_width, self.follow = needle_width, float(follow)
        self.target = self.value = float(value)
        self._at, self._dial = None, None
    def set(self, value, dt, rate=None):
        self.target = max(0.0, min(1.0, value))
        self.value = anim.follow(self.value, self.target, self.follow if rate is None else rate, dt)
    def jump(self, value):
        self.target = self.value = max(0.0, min(1.0, value))
    def _build(self, cx, cy):
        r = self.radius
        rim, band, tick = r * 0.0625, r * 0.125, r * 0.21
        data = pack(ring_points(cx, cy, r, r), self.face)
        for low, high, color in self.zones:
            data += pack(ring_points(cx, cy, r - rim, band, self.start + self.sweep * low, self.start + self.sweep * high), color)
        for i in range(self.ticks):
            a = math.radians(self.start + self.sweep * i / max(1, self.ticks - 1))
            ax, ay = math.cos(a), math.sin(a)
            data += pack(line_points(cx + ax * (r - rim - tick), cy + ay * (r - rim - tick), cx + ax * (r - rim), cy + ay * (r - rim),
                                     max(2.0, r * 0.07)), self.rim)
        self._at, self._dial = (cx, cy), data + pack(ring_points(cx, cy, r, rim), self.rim)
    def draw(self, gfx, cx, cy):
        if self._at != (cx, cy):
            self._build(cx, cy)
        gfx.packed(self._dial)
        a = math.radians(self.start + self.sweep * self.value)
        ax, ay = math.cos(a), math.sin(a)
        x1, y1, x2, y2 = cx + ax * self.needle_from, cy + ay * self.needle_from, cx + ax * self.needle_to, cy + ay * self.needle_to
        if self.edge is not None:
            gfx.line(x1, y1, x2, y2, self.edge, width=self.needle_width + 2)
        gfx.line(x1, y1, x2, y2, self.needle, width=self.needle_width)
def bar(gfx, x, y, w, h, value, color, back=None, edge=None, pad=2):
    if edge is not None:
        gfx.rect(x - pad, y - pad, w + pad * 2, h + pad * 2, edge)
    if back is not None:
        gfx.rect(x, y, w, h, back)
    filled = int(w * max(0.0, min(1.0, value)))
    if filled > 0:
        gfx.rect(x, y, filled, h, color)
def cells(gfx, x, y, count, filled, part=0.0, w=48, h=24, gap=8, full=(255, 255, 255), empty=(60, 60, 70), fill=None,
          edge=None, pad=2):
    for i in range(count):
        left = x + i * (w + gap)
        if edge is not None:
            gfx.rect(left - pad, y - pad, w + pad * 2, h + pad * 2, edge)
        gfx.rect(left, y, w, h, full if i < filled else empty)
        if i == filled and part > 0:
            gfx.rect(left, y, int(w * min(1.0, part)), h, fill if fill is not None else full)
    return count * w + (count - 1) * gap
