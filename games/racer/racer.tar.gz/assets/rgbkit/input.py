import time
NAMES = frozenset({"a", "b", "x", "y", "start", "l1", "r1", "l2", "r2", "up", "down", "left", "right"})
_STICK = {0: ("left", "right"), 1: ("up", "down")}
_STICK_ON = 20000
_STICK_OFF = 12000
_AXES = {"left": (0, 1), "right": (2, 3)}
AXIS_NAMES = {"lx": 0, "ly": 1, "rx": 2, "ry": 3}
STICK_DEAD = 3500
STICK_FULL = 21000
REPEAT_DELAY = 0.40
REPEAT_INTERVAL = 0.10
def _check(name):
    if name not in NAMES:
        if name == "select":
            raise ValueError("SELECT は、ゲームでは使えません（RGBMenu がスクリーンショットと録画に使います）")
        raise ValueError("ボタンの名前が違います: %r（使える名前: %s）" % (name, " ".join(sorted(NAMES))))
    return name
class Input:
    def __init__(self, swap_ab=None, events=None):
        self._held = {}
        self._pressed = set()
        self._released = set()
        self._tapped = set()
        self._tap_seconds = {}
        self._tap_since = {}
        self._real = set()
        self._tilted = set()
        self._alone = {}
        self._repeat_at = {}
        self._repeated = set()
        self._real_pressed = set()
        self._real_repeat_at = {}
        self._real_repeated = set()
        self._stick = {}
        self._axes = [0, 0, 0, 0]
        self.left_stick_counts = True
        self.now = time.monotonic
        self.quit_requested = False
        if events is None:
            from . import backend
            events = backend.current().Events(swap_ab)
        self._events = events
    def poll(self):
        self._pressed.clear()
        self._released.clear()
        self._tapped.clear()
        self._tap_seconds.clear()
        self._tap_since.clear()
        self._repeated.clear()
        self._real_pressed.clear()
        self._real_repeated.clear()
        self._events.read(self)
        now = self.now()
        for name, due in list(self._repeat_at.items()):
            if now >= due:
                self._repeated.add(name)
                self._repeat_at[name] = now + REPEAT_INTERVAL
        for name, due in list(self._real_repeat_at.items()):
            if now >= due:
                self._real_repeated.add(name)
                self._real_repeat_at[name] = now + REPEAT_INTERVAL
    def set(self, name, is_down, from_stick=False):
        if name != "select":
            _check(name)
        mine, other = (self._tilted, self._real) if from_stick else (self._real, self._tilted)
        if not from_stick:
            if is_down and name not in self._real:
                self._real_pressed.add(name)
                self._real_repeat_at[name] = self.now() + REPEAT_DELAY
            elif not is_down:
                self._real_repeat_at.pop(name, None)
        counts = self.left_stick_counts or not from_stick
        if is_down:
            if name in mine:
                return
            mine.add(name)
            if name in other:
                if counts and not self.left_stick_counts:
                    for held in self._held:
                        self._alone[held] = False
                return
            now = self.now()
            if not counts:
                self._alone[name] = False
            else:
                alone = not self._counted()
                for held in self._held:
                    self._alone[held] = False
                self._alone[name] = alone
            self._held[name] = now
            self._pressed.add(name)
            self._repeat_at[name] = now + REPEAT_DELAY
        else:
            if name not in mine:
                return
            mine.discard(name)
            if name in other:
                self._alone[name] = False
                return
            since = self._held.pop(name)
            self._repeat_at.pop(name, None)
            self._released.add(name)
            if self._alone.pop(name, False):
                self._tapped.add(name)
                self._tap_seconds[name] = self.now() - since
                self._tap_since[name] = since
    def _counted(self):
        if self.left_stick_counts:
            return list(self._held)
        return [name for name in self._held if name in self._real]
    def set_axis(self, axis, value):
        self._axes[axis] = max(-32768, min(32767, int(value)))
        if axis in _STICK:
            negative, positive = _STICK[axis]
            current = self._stick.get(axis)
            if current and (abs(value) < _STICK_OFF or (value > 0) != (current == positive)):
                self._stick[axis] = None
                self.set(current, False, from_stick=True)
                current = None
            if not current and abs(value) >= _STICK_ON:
                self._stick[axis] = positive if value > 0 else negative
                self.set(self._stick[axis], True, from_stick=True)
    def stick(self, name):
        try:
            ax, ay = _AXES[name]
        except KeyError:
            raise ValueError('スティックの名前が違います: %r（"left" か "right"）' % (name,))
        x, y = self._axes[ax], self._axes[ay]
        far = (x * x + y * y) ** 0.5
        if far <= STICK_DEAD:
            return (0.0, 0.0)
        amount = min(1.0, (far - STICK_DEAD) / (STICK_FULL - STICK_DEAD))
        return (x / far * amount, y / far * amount)
    def down(self, name, stick=True):
        return _check(name) in (self._held if stick else self._real)
    def pressed(self, name, stick=True):
        return _check(name) in (self._pressed if stick else self._real_pressed)
    def released(self, name):
        return _check(name) in self._released
    def tapped(self, name, since=None, wait=0.0):
        if _check(name) not in self._tapped:
            return False
        if since is None:
            return True
        return self._tap_since[name] >= since and self.now() - since >= wait
    def tapped_for(self, name):
        return self._tap_seconds.get(_check(name), 0.0)
    def repeat(self, name, stick=True):
        if not stick:
            return _check(name) in self._real_pressed or name in self._real_repeated
        return _check(name) in self._pressed or name in self._repeated
    def held_for(self, name):
        return self.now() - self._held[name] if _check(name) in self._held else 0.0
    def only(self, *names):
        for name in names:
            _check(name)
        if not all(name in names for name in self._counted()):
            return False
        return any(name in names for name in self._held)
    def none_but(self, *names):
        for name in names:
            _check(name)
        return all(name in names for name in self._counted())
    def cursor(self, back, forward, among=None):
        if not self.only(*(among or (back, forward))):
            return 0
        if self.repeat(back) and not self.down(forward):
            return -1
        if self.repeat(forward) and not self.down(back):
            return 1
        return 0
    def direction(self):
        return (self.down("right") - self.down("left"), self.down("down") - self.down("up"))
    def any_pressed(self):
        return bool(self._pressed - {"select"})
    def has_edges(self):
        return bool(self._pressed or self._released or self._tapped or self._repeated
                    or self._real_pressed or self._real_repeated)
    def clear_edges(self):
        self._pressed.clear()
        self._released.clear()
        self._tapped.clear()
        self._tap_seconds.clear()
        self._tap_since.clear()
        self._repeated.clear()
        self._real_pressed.clear()
        self._real_repeated.clear()
