EMPTY = {"money": 0, "owned": [], "using": []}
class Inventory:
    def __init__(self, game, items, name="inventory.json", owned=(), groups=None, limit=999999, data=None):
        self.game, self.name, self.limit = game, name, int(limit)
        self.items = {}
        for item in items:
            needs = item[2] if len(item) > 2 else ()
            self.items[item[0]] = (int(item[1]), (needs,) if isinstance(needs, str) else tuple(needs))
        self.always = tuple(owned)
        self.groups = {group: list(names) for group, names in (groups or {}).items()}
        for known in list(self.always) + [n for needs in self.items.values() for n in needs[1]] + \
                [n for names in self.groups.values() for n in names]:
            if known not in self.items:
                raise ValueError("品物の表に、ありません: %r" % (known,))
        if data is None and game is not None:
            data = game.load_json(name, EMPTY, schema={"money": (int, 0, self.limit), "owned": [str], "using": [str]})
        data = dict(EMPTY, **(data or {}))
        self.money = max(0, min(self.limit, int(data["money"])))
        have = set(self.always) | {n for n in data["owned"] if n in self.items}
        while True:
            drop = {n for n in have if n not in self.always and any(need not in have for need in self.items[n][1])}
            if not drop:
                break
            have -= drop
        self._owned = have
        self._using = {}
        for group, names in self.groups.items():
            chosen = next((n for n in names if n in data["using"] and n in have), None)
            self._using[group] = chosen or next((n for n in names if n in have), None)
    def owned(self, name):
        return name in self._owned
    def price(self, name):
        return self.items[name][0]
    def can_buy(self, name):
        price, needs = self.items[name]
        return name not in self._owned and self.money >= price and all(need in self._owned for need in needs)
    def buy(self, name, use=True):
        if not self.can_buy(name):
            return False
        self.money -= self.items[name][0]
        self._owned.add(name)
        if use:
            for group, names in self.groups.items():
                if name in names:
                    self._using[group] = name
        return True
    def use(self, group, name):
        if name not in self.groups[group] or name not in self._owned or self._using[group] == name:
            return False
        self._using[group] = name
        return True
    def using(self, group):
        return self._using[group]
    def earn(self, amount):
        before = self.money
        self.money = max(0, min(self.limit, self.money + max(0, int(amount))))
        return self.money - before
    def data(self):
        return {"money": self.money, "owned": [n for n in self.items if n in self._owned],
                "using": [n for n in self._using.values() if n]}
    def save(self):
        return self.game.save_json(self.name, self.data())
