class Progress:
    def __init__(self, game, stages, name="progress.json", lower_is_better=True, low=None, high=None, migrate=None):
        if stages < 1:
            raise ValueError("stages は 1 以上")
        self.game, self.stages, self.name, self.lower_is_better = game, stages, name, lower_is_better
        self.low, self.high = low, high
        data = game.load_json(name, {"best": [], "unlocked": 1, "selected": 0}, migrate=migrate,
                              schema={"best": [(float, low, high)], "unlocked": (int, 1, stages),
                                      "selected": (int, 0, stages - 1)})
        self.best = (list(data["best"]) + [None] * stages)[:stages]
        self.unlocked = data["unlocked"]
        self.selected = min(data["selected"], self.unlocked - 1)
    def _frozen(self):
        return bool(self.game.command) and not self.game.save_with_command
    def record(self, index, value):
        if self._frozen():
            return False
        if (self.low is not None and value < self.low) or (self.high is not None and value > self.high):
            return False
        best = self.best[index]
        if best is not None and (value >= best if self.lower_is_better else value <= best):
            return False
        self.best[index] = value
        return True
    def unlock(self, count):
        if self._frozen():
            return False
        count = max(1, min(self.stages, int(count)))
        if count <= self.unlocked:
            return False
        self.unlocked = count
        return True
    def save(self):
        return self.game.save_json(self.name, {"best": self.best, "unlocked": self.unlocked, "selected": self.selected})
