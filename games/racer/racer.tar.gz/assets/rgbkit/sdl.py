import ctypes
import ctypes.util
import os
import sys
from ctypes import POINTER, Structure, c_char_p, c_int, c_uint8, c_uint32, c_void_p
INIT_AUDIO = 0x00000010
INIT_VIDEO = 0x00000020
INIT_GAMECONTROLLER = 0x00002000
WINDOWPOS_CENTERED = 0x2FFF0000
WINDOW_SHOWN = 0x00000004
WINDOW_FULLSCREEN_DESKTOP = 0x00001001
RENDERER_ACCELERATED = 0x00000002
RENDERER_PRESENTVSYNC = 0x00000004
BLENDMODE_BLEND = 1
PIXELFORMAT_RGBA32 = 0x16762004 if sys.byteorder == "little" else 0x16462004
TEXTUREACCESS_STATIC = 0
TEXTUREACCESS_STREAMING = 1
AUDIO_S16SYS = 0x8010 if sys.byteorder == "little" else 0x9010
QUIT = 0x100
KEYDOWN = 0x300
KEYUP = 0x301
CONTROLLERAXISMOTION = 0x650
CONTROLLERBUTTONDOWN = 0x651
CONTROLLERBUTTONUP = 0x652
CONTROLLERDEVICEADDED = 0x653
EVENT_SIZE = 64
class Rect(Structure):
    _fields_ = [("x", c_int), ("y", c_int), ("w", c_int), ("h", c_int)]
class Color(Structure):
    _fields_ = [("r", c_uint8), ("g", c_uint8), ("b", c_uint8), ("a", c_uint8)]
def _load(base):
    names = ["lib%s-2.0.so.0" % base]
    if sys.platform == "darwin":
        for prefix in (os.environ.get("HOMEBREW_PREFIX"), "/opt/homebrew", "/usr/local"):
            if prefix:
                names.append("%s/lib/lib%s-2.0.0.dylib" % (prefix, base))
    found = ctypes.util.find_library(base)
    if found:
        names.append(found)
    reason = ""
    for name in names:
        try:
            return ctypes.CDLL(name)
        except OSError as e:
            if os.path.exists(name):
                reason = ": %s" % str(e).splitlines()[0]
    raise OSError("%s を開けません（macOS なら brew install %s）%s" % (base, base.lower(), reason))
def _bind(lib, name, restype, *argtypes):
    fn = getattr(lib, name)
    fn.restype = restype
    fn.argtypes = list(argtypes)
    return fn
load_library = _load
bind = _bind
_sdl = _load("SDL2")
_ttf = _load("SDL2_ttf")
lib = _sdl
ttf = _ttf
Init = _bind(_sdl, "SDL_Init", c_int, c_uint32)
Quit = _bind(_sdl, "SDL_Quit", None)
InitSubSystem = _bind(_sdl, "SDL_InitSubSystem", c_int, c_uint32)
QuitSubSystem = _bind(_sdl, "SDL_QuitSubSystem", None, c_uint32)
GetCurrentAudioDriver = _bind(_sdl, "SDL_GetCurrentAudioDriver", c_char_p)
RWFromFile = _bind(_sdl, "SDL_RWFromFile", c_void_p, c_char_p, c_char_p)
_GetError = _bind(_sdl, "SDL_GetError", c_char_p)
CreateWindow = _bind(_sdl, "SDL_CreateWindow", c_void_p, c_char_p, c_int, c_int, c_int, c_int, c_uint32)
DestroyWindow = _bind(_sdl, "SDL_DestroyWindow", None, c_void_p)
CreateRenderer = _bind(_sdl, "SDL_CreateRenderer", c_void_p, c_void_p, c_int, c_uint32)
DestroyRenderer = _bind(_sdl, "SDL_DestroyRenderer", None, c_void_p)
RenderSetLogicalSize = _bind(_sdl, "SDL_RenderSetLogicalSize", c_int, c_void_p, c_int, c_int)
SetRenderDrawBlendMode = _bind(_sdl, "SDL_SetRenderDrawBlendMode", c_int, c_void_p, c_int)
SetRenderDrawColor = _bind(_sdl, "SDL_SetRenderDrawColor", c_int, c_void_p, c_uint8, c_uint8, c_uint8, c_uint8)
RenderClear = _bind(_sdl, "SDL_RenderClear", c_int, c_void_p)
RenderFillRect = _bind(_sdl, "SDL_RenderFillRect", c_int, c_void_p, POINTER(Rect))
RenderDrawRect = _bind(_sdl, "SDL_RenderDrawRect", c_int, c_void_p, POINTER(Rect))
RenderDrawLine = _bind(_sdl, "SDL_RenderDrawLine", c_int, c_void_p, c_int, c_int, c_int, c_int)
RenderCopy = _bind(_sdl, "SDL_RenderCopy", c_int, c_void_p, c_void_p, POINTER(Rect), POINTER(Rect))
RenderPresent = _bind(_sdl, "SDL_RenderPresent", None, c_void_p)
RenderReadPixels = _bind(_sdl, "SDL_RenderReadPixels", c_int, c_void_p, POINTER(Rect), c_uint32, c_void_p, c_int)
GetRendererOutputSize = _bind(_sdl, "SDL_GetRendererOutputSize", c_int, c_void_p, POINTER(c_int), POINTER(c_int))
CreateTextureFromSurface = _bind(_sdl, "SDL_CreateTextureFromSurface", c_void_p, c_void_p, c_void_p)
CreateTexture = _bind(_sdl, "SDL_CreateTexture", c_void_p, c_void_p, c_uint32, c_int, c_int, c_int)
UpdateTexture = _bind(_sdl, "SDL_UpdateTexture", c_int, c_void_p, POINTER(Rect), c_char_p, c_int)
SetTextureBlendMode = _bind(_sdl, "SDL_SetTextureBlendMode", c_int, c_void_p, c_int)
DestroyTexture = _bind(_sdl, "SDL_DestroyTexture", None, c_void_p)
QueryTexture = _bind(_sdl, "SDL_QueryTexture", c_int, c_void_p, POINTER(c_uint32), POINTER(c_int),
                     POINTER(c_int), POINTER(c_int))
FreeSurface = _bind(_sdl, "SDL_FreeSurface", None, c_void_p)
try:
    RenderGeometryRaw = _bind(_sdl, "SDL_RenderGeometryRaw", c_int, c_void_p, c_void_p, c_char_p, c_int, c_char_p, c_int,
                              c_void_p, c_int, c_int, c_void_p, c_int, c_int)
except AttributeError:
    RenderGeometryRaw = None
PollEvent = _bind(_sdl, "SDL_PollEvent", c_int, c_void_p)
Delay = _bind(_sdl, "SDL_Delay", None, c_uint32)
NumJoysticks = _bind(_sdl, "SDL_NumJoysticks", c_int)
IsGameController = _bind(_sdl, "SDL_IsGameController", c_int, c_int)
GameControllerOpen = _bind(_sdl, "SDL_GameControllerOpen", c_void_p, c_int)
TTF_Init = _bind(_ttf, "TTF_Init", c_int)
TTF_Quit = _bind(_ttf, "TTF_Quit", None)
TTF_OpenFont = _bind(_ttf, "TTF_OpenFont", c_void_p, c_char_p, c_int)
TTF_CloseFont = _bind(_ttf, "TTF_CloseFont", None, c_void_p)
TTF_RenderUTF8_Blended = _bind(_ttf, "TTF_RenderUTF8_Blended", c_void_p, c_void_p, c_char_p, Color)
TTF_SizeUTF8 = _bind(_ttf, "TTF_SizeUTF8", c_int, c_void_p, c_char_p, POINTER(c_int), POINTER(c_int))
TTF_SetFontOutline = _bind(_ttf, "TTF_SetFontOutline", None, c_void_p, c_int)
def error(what):
    msg = _GetError()
    return RuntimeError("%s: %s" % (what, msg.decode("utf-8", "replace") if msg else "?"))
