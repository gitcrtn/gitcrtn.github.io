import os
from functools import partial
from .ui import Menu
class Slots:
    def __init__(self, game, count=3, name="slot%d.json", empty=None, schema=None, filled=None):
        if count < 1:
            raise ValueError("count は 1 以上")
        self.game, self.count, self.name = game, int(count), name
        self.empty, self.schema, self.filled = empty, schema, filled
        self._data = [self._read(n) for n in range(self.count)]
    def file(self, n):
        return self.name % (n + 1)
    def _read(self, n):
        if not os.path.isfile(self.game.save_path(self.file(n))):
            return None
        data = self.game.load_json(self.file(n), self.empty, schema=self.schema)
        if self.filled is not None:
            try:
                return data if self.filled(data) else None
            except (KeyError, TypeError, IndexError, AttributeError):
                return None
        return None if data is None or data == self.empty else data
    def data(self, n):
        return self._data[n]
    def write(self, n, data):
        if not self.game.save_json(self.file(n), data):
            return False
        self._data[n] = data
        return True
    def pick(self, title, label, on_pick, confirm="上書きしますか？", yes="上書きする", no="やめる"):
        def picked(n):
            if confirm is None or self._data[n] is None:
                on_pick(n)
            else:
                self.game.confirm(confirm, partial(on_pick, n), lines=[label(n, self._data[n])], yes=yes, no=no)
        return self.game.open(Menu(self.game, title, [(label(n, self._data[n]), partial(picked, n)) for n in range(self.count)]))
