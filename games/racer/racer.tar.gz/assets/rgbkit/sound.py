import array
import math
import os
import time
RATE = 44100
HISTORY = 16
CHANNELS = 16
MAX_VOLUME = 128
def _volume(value):
    return max(0, min(MAX_VOLUME, int(value * MAX_VOLUME)))
class Playing:
    def __init__(self, channel, chunk):
        self.channel = channel
        self.chunk = chunk
class Sound:
    def __init__(self, base_dir=".", log=None, mixer=None):
        self.base_dir = base_dir
        self.enabled = False
        self.paused = False
        self._log = log or (lambda *values: None)
        self._mixer = None
        self._chunks = {}
        self._music = None
        self._music_path = None
        self._failed = set()
        self._held = {}
        self._holding = set()
        self.history = []
        self.played = 0
        self.music = None
        self.music_starts = 0
        self.clock = time.monotonic
        self._last = {}
        self._bands = {}
        try:
            if mixer is None:
                from . import backend
                mixer = backend.current().Mixer()
            driver = mixer.open(RATE, CHANNELS)
            self._mixer = mixer
            self.enabled = True
            self._log("sound: on driver=%s" % driver)
        except (RuntimeError, OSError, AttributeError) as e:
            self._mixer = None
            self._log("sound: off (%s)" % e)
    def _path(self, path):
        return path if os.path.isabs(path) else os.path.join(self.base_dir, path)
    def _fail(self, path, what):
        if path not in self._failed:
            self._failed.add(path)
            self._log("sound: cannot load %s: %s" % (path, self._mixer.error(what)))
    def load(self, path):
        if not self.enabled:
            return False
        if path in self._chunks:
            return True
        if path in self._failed:
            return False
        chunk = self._mixer.load_wav(self._path(path))
        if not chunk:
            self._fail(path, "Mix_LoadWAV")
            return False
        self._chunks[path] = chunk
        return True
    def play(self, path, volume=1.0, loop=False, every=0.0):
        if every > 0:
            now = self.clock()
            if now - self._last.get(path, -every) < every:
                return None
            self._last[path] = now
        if not loop:
            self.history = (self.history + [path])[-HISTORY:]
            self.played += 1
        if not self.load(path):
            return None
        return self._play_chunk(self._chunks[path], volume, loop)
    def beep(self, frequency=880, seconds=0.08, volume=0.5):
        if not self.enabled:
            return None
        key = (int(frequency), round(seconds, 3))
        if key not in self._chunks:
            count = max(1, int(RATE * key[1]))
            fade = max(1, min(count // 2, RATE // 200))
            samples = array.array("h")
            for i in range(count):
                level = min(1.0, i / fade, (count - 1 - i) / fade)
                value = int(32767 * level * math.sin(2 * math.pi * key[0] * i / RATE))
                samples.append(value)
                samples.append(value)
            chunk = self._mixer.load_raw(samples.tobytes())
            if not chunk:
                return None
            self._chunks[key] = chunk
        return self._play_chunk(self._chunks[key], volume, False)
    def _play_chunk(self, chunk, volume, loop):
        channel = self._mixer.play(chunk, loop)
        if channel < 0:
            return None
        self._mixer.volume(channel, _volume(volume))
        if self.paused:
            self._mixer.pause(channel)
        return Playing(channel, chunk)
    def stop(self, playing=None):
        if not self.enabled:
            if playing is None:
                self._holding = set()
            return
        if playing is None:
            self._mixer.halt(-1)
            self._held = {}
            self._holding = set()
        elif self._mixer.playing(playing.channel, playing.chunk):
            self._mixer.halt(playing.channel)
    def hold(self, path, on=True, volume=1.0):
        held = self._held.get(path)
        (self._holding.add if on else self._holding.discard)(path)
        if not on:
            if held:
                del self._held[path]
                self.stop(held[0])
            return False
        if held:
            if held[1] != volume:
                held[1] = volume
                self._mixer.volume(held[0].channel, _volume(volume))
            return True
        playing = self.play(path, volume, loop=True)
        if playing:
            self._held[path] = [playing, volume]
        return bool(playing)
    def stop_held(self):
        for path in list(self._holding | set(self._held)):
            self.hold(path, False)
    def held(self):
        return sorted(self._holding)
    def band(self, paths, value, edges, back=0.0, volume=1.0, on=True):
        key = tuple(paths)
        if len(edges) != len(key) - 1:
            raise ValueError("edges は、paths より 1 つ少なく")
        band = self._bands.get(key, 0)
        while band < len(edges) and value > edges[band]:
            band += 1
        while band > 0 and value < edges[band - 1] - back:
            band -= 1
        self._bands[key] = band
        for n, path in enumerate(key):
            self.hold(path, on and n == band, volume)
        return band
    def play_music(self, path, loop=True, volume=1.0):
        self.music_starts += self.music is None or self.music[0] != path
        self.music = (path, volume)
        if not self.enabled:
            return False
        self._mixer.volume_music(_volume(volume))
        if path == self._music_path:
            return True
        self.stop_music()
        self.music = (path, volume)
        music = self._mixer.load_music(self._path(path)) if path not in self._failed else None
        if not music:
            self._fail(path, "Mix_LoadMUS")
            return False
        if not self._mixer.play_music(music, loop):
            self._fail(path, "Mix_PlayMusic")
            self._mixer.free_music(music)
            return False
        self._music, self._music_path = music, path
        if self.paused:
            self._mixer.pause_music()
        return True
    def stop_music(self):
        if self.enabled and self._music:
            self._mixer.halt_music()
            self._mixer.free_music(self._music)
        self._music, self._music_path = None, None
        self.music = None
    def set_paused(self, paused):
        if paused == self.paused:
            return
        self.paused = paused
        if not self.enabled:
            return
        if paused:
            self._mixer.pause(-1)
            self._mixer.pause_music()
        else:
            self._mixer.resume(-1)
            self._mixer.resume_music()
    def close(self):
        if not self.enabled:
            return
        self.enabled = False
        self._mixer.halt(-1)
        self.stop_music()
        for chunk in self._chunks.values():
            self._mixer.free(chunk)
        self._chunks = {}
        self._held = {}
        self._mixer.close()
