import base64
import sys
import zlib
from array import array
FORMAT = 1
KINDS = ("number", "angle", "flag")
EMPTY = {"timeline": 0, "fields": [], "interval": 0.0, "data": ""}
SCHEMA = {"timeline": int, "fields": [str], "interval": (float, 0.0, None), "data": str}
def _fields(fields):
    out = []
    for field in fields:
        name, kind = (field, "number") if isinstance(field, str) else field
        if kind not in KINDS:
            raise ValueError("値の種類は、%s のどれか: %r" % (" / ".join(KINDS), kind))
        out.append((str(name), kind))
    if not out:
        raise ValueError("記録する値が、ありません")
    return out
class Recorder:
    def __init__(self, fields, interval=1 / 30):
        self.fields = _fields(fields)
        self.names = [name for name, _ in self.fields]
        self.size = len(self.fields)
        self.interval = float(interval)
        if self.interval <= 0:
            raise ValueError("interval は、0 より大きく")
        self._kinds = [KINDS.index(kind) for _, kind in self.fields]
        self.data = array("f")
    def clear(self):
        self.data = array("f")
    def __len__(self):
        return len(self.data) // self.size
    @property
    def duration(self):
        return max(0, len(self) - 1) * self.interval
    def add(self, values):
        if len(values) != self.size:
            raise ValueError("値の数が、違います（%d 個のはず）" % self.size)
        self.data.extend(float(value) for value in values)
    def at(self, t):
        count = len(self)
        if count == 0:
            return None
        data, size = self.data, self.size
        where = max(0.0, min(count - 1.0, t / self.interval))
        i = min(count - 2, int(where)) if count > 1 else 0
        k = where - i if count > 1 else 0.0
        a = i * size
        b = a + size if count > 1 else a
        near = b if k >= 0.5 else a
        out = []
        for n, kind in enumerate(self._kinds):
            if kind == 0:
                out.append(data[a + n] + (data[b + n] - data[a + n]) * k)
            elif kind == 1:
                out.append((data[a + n] + ((data[b + n] - data[a + n] + 180.0) % 360.0 - 180.0) * k) % 360.0)
            else:
                out.append(data[near + n] >= 0.5)
        return out
    def pack(self, level=6):
        numbers = array("f", self.data)
        if sys.byteorder == "big":
            numbers.byteswap()
        return {"timeline": FORMAT, "fields": ["%s:%s" % field for field in self.fields], "interval": self.interval,
                "data": base64.b64encode(zlib.compress(numbers.tobytes(), level)).decode("ascii")}
    @classmethod
    def unpack(cls, saved, fields=None):
        try:
            if saved["timeline"] != FORMAT or not saved["data"] or not saved["interval"] > 0:
                return None
            found = [tuple(str(field).split(":")) for field in saved["fields"]]
            if fields is not None and found != _fields(fields):
                return None
            recorder = cls(found, saved["interval"])
            numbers = array("f")
            numbers.frombytes(zlib.decompress(base64.b64decode(saved["data"], validate=True)))
        except (KeyError, TypeError, ValueError, zlib.error):
            return None
        if sys.byteorder == "big":
            numbers.byteswap()
        if len(numbers) % recorder.size or len(numbers) < recorder.size:
            return None
        recorder.data = numbers
        return recorder
