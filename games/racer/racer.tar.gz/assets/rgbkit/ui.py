from .gfx import HEIGHT, WIDTH
PANEL = (34, 38, 56)
SELECT = (52, 92, 168)
WHITE = (240, 240, 240)
GRAY = (150, 150, 160)
ACCENT = (110, 200, 255)
DANGER = (235, 90, 90)
SHADE = (0, 0, 0, 170)
ROW_H = 62
DIRECTIONS = ("up", "down", "left", "right")
def moved(inp, name):
    return inp.repeat(name) and inp.only(*DIRECTIONS)
class Overlay:
    def __init__(self, game):
        self.game = game
    def close(self):
        self.game.close(self)
    def update(self, inp):
        pass
    def draw(self, gfx):
        pass
class Menu(Overlay):
    def __init__(self, game, title, items, keep_open=False, visible=9):
        super().__init__(game)
        if visible < 1:
            raise ValueError("visible は、1 以上")
        self.title = title
        self.items = list(items)
        self.keep_open = keep_open
        self.visible = visible
        self.index = 0
    def shown(self):
        count = len(self.items)
        rows = min(count, self.visible)
        top = max(0, min(count - rows, self.index - rows // 2))
        return range(top, top + rows)
    def update(self, inp):
        count = len(self.items)
        if moved(inp, "up"):
            self.index = (self.index - 1) % count
        elif moved(inp, "down"):
            self.index = (self.index + 1) % count
        elif inp.tapped("a"):
            action = self.items[self.index][1]
            if not self.keep_open:
                self.close()
            if action:
                action()
        elif inp.tapped("b") or inp.tapped("start"):
            self.close()
    def draw(self, gfx):
        gfx.rect(0, 0, WIDTH, HEIGHT, SHADE)
        rows = self.shown()
        w = 460
        h = 96 + ROW_H * len(rows) + 56
        x, y = (WIDTH - w) // 2, (HEIGHT - h) // 2
        gfx.rect(x, y, w, h, PANEL)
        gfx.rect(x, y, w, 6, ACCENT)
        gfx.text(WIDTH // 2, y + 28, self.title, 30, WHITE, align="center")
        if len(rows) < len(self.items):
            gfx.text(x + w - 20, y + 34, "%d / %d" % (self.index + 1, len(self.items)), 20, GRAY, align="right")
        row_y = y + 96
        for i in rows:
            if i == self.index:
                gfx.rect(x + 16, row_y + 2, w - 32, ROW_H - 4, SELECT)
            gfx.text(WIDTH // 2, row_y + 12, self.items[i][0], 28, WHITE, align="center")
            row_y += ROW_H
        gfx.text(WIDTH // 2, y + h - 42, "A: 決定   B: 閉じる", 20, GRAY, align="center")
class Confirm(Overlay):
    def __init__(self, game, title, on_yes, lines=(), yes="はい", no="いいえ", danger=False):
        super().__init__(game)
        self.title = title
        self.lines = list(lines)
        self.on_yes = on_yes
        self.labels = (no, yes)
        self.choice = 0
        self.danger = danger
    def update(self, inp):
        if (inp.pressed("left") or inp.pressed("right")) and inp.only(*DIRECTIONS):
            self.choice = 1 - self.choice
        elif inp.tapped("b"):
            self.close()
        elif inp.tapped("a"):
            self.close()
            if self.choice == 1:
                self.on_yes()
    def draw(self, gfx):
        gfx.rect(0, 0, WIDTH, HEIGHT, SHADE)
        h = 190 + 36 * len(self.lines)
        x, y, w = 60, (HEIGHT - h) // 2, WIDTH - 120
        gfx.rect(x, y, w, h, PANEL)
        gfx.rect(x, y, w, 6, DANGER if self.danger else ACCENT)
        gfx.text(WIDTH // 2, y + 26, self.title, 30, WHITE, align="center")
        line_y = y + 84
        for line in self.lines:
            gfx.text(WIDTH // 2, line_y, line, 24, GRAY, align="center")
            line_y += 36
        bw, bh = 220, 56
        by = y + h - bh - 26
        for i, label in enumerate(self.labels):
            bx = WIDTH // 2 - bw - 12 if i == 1 else WIDTH // 2 + 12
            if i == self.choice:
                gfx.rect(bx, by, bw, bh, DANGER if (self.danger and i == 1) else SELECT)
            else:
                gfx.rect(bx, by, bw, bh, GRAY, fill=False)
            gfx.text(bx + bw // 2, by + 11, label, 26, WHITE, align="center")
class Message(Overlay):
    def __init__(self, game, title, lines=(), on_close=None):
        super().__init__(game)
        self.title = title
        self.lines = list(lines)
        self.on_close = on_close
    def update(self, inp):
        if inp.tapped("a") or inp.tapped("b"):
            self.close()
            if self.on_close:
                self.on_close()
    def draw(self, gfx):
        gfx.rect(0, 0, WIDTH, HEIGHT, SHADE)
        h = 150 + 36 * len(self.lines)
        x, y, w = 60, (HEIGHT - h) // 2, WIDTH - 120
        gfx.rect(x, y, w, h, PANEL)
        gfx.rect(x, y, w, 6, ACCENT)
        gfx.text(WIDTH // 2, y + 26, self.title, 30, WHITE, align="center")
        line_y = y + 84
        for line in self.lines:
            gfx.text(WIDTH // 2, line_y, line, 24, GRAY, align="center")
            line_y += 36
        gfx.text(WIDTH // 2, y + h - 40, "A: 閉じる", 20, GRAY, align="center")
BUTTON_NAMES = ("a", "b", "x", "y", "l1", "l2", "r1", "r2", "start", "dpad", "up", "down", "left", "right", "lstick", "rstick")
BUTTON_COLORS = {"body": (48, 54, 78), "edge": (70, 78, 104), "key": (225, 228, 235), "dim": (96, 102, 124),
                 "name": (24, 26, 36), "label": (255, 225, 90)}
BUTTONS_W, BUTTONS_H = 600, 400
ARROWS = (("up", "▲"), ("down", "▼"), ("left", "◀"), ("right", "▶"))
def draw_buttons(gfx, x, y, w, labels, colors=None):
    for name in labels:
        if name == "select":
            raise ValueError("SELECT は、ゲームでは使えません（図では、いつも暗い色）")
        if name not in BUTTON_NAMES:
            raise ValueError("ボタンの名前が違います: %r（使える名前: %s）" % (name, " ".join(BUTTON_NAMES)))
    c = dict(BUTTON_COLORS, **(colors or {}))
    s = w / BUTTONS_W
    def px(value):
        return int(round(value * s))
    def key(name):
        return c["key"] if labels.get(name) else c["dim"]
    def text(tx, ty, words, size, color, align="center"):
        gfx.text(x + px(tx), y + px(ty), words, max(8, px(size)), color, align=align, valign="middle")
    def box(bx, by, bw, bh, color):
        gfx.rect(x + px(bx), y + px(by), px(bw), px(bh), color)
    box(0, 96, 600, 304, c["edge"])
    box(4, 100, 592, 296, c["body"])
    for left, name, shown, tx, ty, align in ((10, "l1", "L1", 10, 22, "left"), (92, "l2", "L2", 92, 46, "left"),
                                             (432, "r2", "R2", 508, 46, "right"), (514, "r1", "R1", 590, 22, "right")):
        box(left, 62, 76, 30, key(name))
        text(left + 38, 77, shown, 20, c["name"])
        if labels.get(name):
            text(tx, ty, labels[name], 20, c["label"], align)
    box(190, 150, 60, 22, c["dim"])
    text(220, 161, "SELECT", 13, c["name"])
    box(312, 150, 60, 22, key("start"))
    text(342, 161, "START", 13, c["name"])
    if labels.get("start"):
        text(342, 128, labels["start"], 20, c["label"])
    cx, cy = 120, 220
    whole = bool(labels.get("dpad"))
    lit = {name: whole or bool(labels.get(name)) for name, _ in ARROWS}
    box(cx - 50, cy - 17, 34, 34, c["key"] if lit["left"] else c["dim"])
    box(cx + 16, cy - 17, 34, 34, c["key"] if lit["right"] else c["dim"])
    box(cx - 17, cy - 50, 34, 34, c["key"] if lit["up"] else c["dim"])
    box(cx - 17, cy + 16, 34, 34, c["key"] if lit["down"] else c["dim"])
    box(cx - 17, cy - 17, 34, 34, c["key"] if any(lit.values()) else c["dim"])
    for (name, arrow), (ax, ay) in zip(ARROWS, ((0, -34), (0, 34), (-34, 0), (34, 0))):
        text(cx + ax, cy + ay, arrow, 15, c["name"])
    words = [labels["dpad"]] if whole else []
    words += ["%s %s" % (arrow, labels[name]) for name, arrow in ARROWS if labels.get(name)]
    if words:
        text(cx, 292, "　".join(words), 20, c["label"])
    bx, by, far, r = 420, 225, 50, 24
    for dx, dy, name in ((0, -far, "x"), (far, 0, "a"), (0, far, "b"), (-far, 0, "y")):
        gfx.circle(x + px(bx + dx), y + px(by + dy), max(2, px(r)), key(name))
        text(bx + dx, by + dy, name.upper(), 24, c["name"])
    for name, tx, ty, align in (("x", bx + 32, by - far, "left"), ("a", bx + far + 30, by, "left"),
                                ("y", bx - far - 30, by, "right"), ("b", bx, by + far + 33, "center")):
        if labels.get(name):
            text(tx, ty, labels[name], 20, c["label"], align)
    for sx, name, tx, align in ((90, "lstick", 126, "left"), (510, "rstick", 474, "right")):
        gfx.circle(x + px(sx), y + px(350), max(2, px(28)), c["edge"])
        gfx.circle(x + px(sx), y + px(350), max(2, px(20)), key(name))
        if labels.get(name):
            text(tx, 350, labels[name], 20, c["label"], align)
    return px(BUTTONS_H)
YELLOW = (255, 225, 90)
PAGE_SHADE = (0, 0, 0, 190)
PAGE_PANEL = (30, 34, 52)
class Pages(Overlay):
    def __init__(self, game, title, pages):
        super().__init__(game)
        self.title = title
        self.pages = [page if isinstance(page, tuple) else ("", page) for page in pages]
        if not self.pages:
            raise ValueError("ページが、ありません")
        self.page = 0
    @staticmethod
    def lines(heading, lines):
        lines = list(lines)
        def draw(gfx, x, y, w, h):
            head_w = max([gfx.text_size(head, 23)[0] for head, _ in lines if head] or [0])
            text_x = x + (head_w + 26 if head_w else 0)
            row = y + 14
            for head, words in lines:
                if head:
                    row += 10
                    gfx.text(x, row, head, 23, YELLOW, valign="middle")
                gfx.text(text_x, row, words, 21, WHITE, valign="middle")
                row += 35
        return heading, draw
    @staticmethod
    def buttons(heading, labels, notes=(), colors=None):
        labels, notes = dict(labels), list(notes)
        wrong = [name for name in labels if name not in BUTTON_NAMES]
        if wrong:
            raise ValueError("ボタンの名前が違います: %r（使える名前: %s）" % (wrong[0], " ".join(BUTTON_NAMES)))
        def draw(gfx, x, y, w, h):
            width = min(w, 540)
            used = draw_buttons(gfx, x + (w - width) // 2, y - 14, width, labels, colors)
            for i, note in enumerate(notes):
                gfx.text(x + w // 2, y + used + 8 + i * 30, note, 21, WHITE if i == 0 else GRAY, align="center", valign="middle")
        return heading, draw
    def update(self, inp):
        if inp.only(*DIRECTIONS) and inp.pressed("right") and not inp.down("left"):
            self.page = min(len(self.pages) - 1, self.page + 1)
        elif inp.only(*DIRECTIONS) and inp.pressed("left") and not inp.down("right"):
            self.page = max(0, self.page - 1)
        elif inp.tapped("a") or inp.tapped("b") or inp.tapped("start"):
            self.close()
    def draw(self, gfx):
        gfx.rect(0, 0, WIDTH, HEIGHT, PAGE_SHADE)
        x, y, w, h = 30, 40, WIDTH - 60, HEIGHT - 80
        gfx.rect(x, y, w, h, PAGE_PANEL)
        gfx.rect(x, y, w, 6, ACCENT)
        gfx.text(WIDTH // 2, y + 22, self.title, 32, WHITE, align="center")
        many = len(self.pages) > 1
        if many:
            gfx.text(x + w - 24, y + 28, "%d / %d" % (self.page + 1, len(self.pages)), 24, GRAY, align="right")
        heading, draw = self.pages[self.page]
        if heading:
            gfx.text(WIDTH // 2, y + 72, heading, 24, YELLOW, align="center")
        draw(gfx, x + 26, y + 116, w - 52, h - 116 - 60)
        gfx.text(WIDTH // 2, y + h - 44, "左右: ページ　　A / B: 閉じる" if many else "A / B: 閉じる", 22, GRAY, align="center")
