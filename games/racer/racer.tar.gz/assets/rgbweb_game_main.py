import math
import sys
from functools import partial
from types import SimpleNamespace as Namespace
from rgbkit import HEIGHT, WIDTH, Game, Progress, Slots, anim, format_time, g3d, g3dtop, gfxfx
import car as carlib
import audio as audiolib
import cars
import courses
import effects
import garage as garagelib
import grandprix as gplib
import guide
import hud
import replay as replaylib
import rival as rivallib
from course import GROUND_Y, Course
VIEW_SIZE = 320
SKY = courses.TRACKS[0].sky
FOG_NEAR, FOG_FAR = 70.0, 220.0
CAMERA_BACK = 7.5
CAMERA_HEIGHT = 2.8
CAMERA_AHEAD = 6.0
ORBIT_RADIUS, ORBIT_HEIGHT = 9.0, 2.6
CAMERA_FOLLOW = 6.0
WHITE = (255, 255, 255)
SHADOW = (20, 30, 50)
FOV, FOV_BOOST = 60.0, 74.0
TANK_FULL, TANK_EMPTY, TANK_FILL = (90, 225, 255), (30, 40, 60), (40, 110, 150)
BOOST_COLOR = (255, 160, 40)
BOOST_COLORS = {0: BOOST_COLOR, 1: BOOST_COLOR, 2: (255, 90, 200), 3: (170, 110, 255)}
DRIVE = ("up", "down", "left", "right", "b", "y", "r1", "r2", "l2", "a")
COUNT_DRIVE = DRIVE[:-1]
LAPS = 3
COUNT_SECONDS = 3.0
REV_UP, REV_DOWN = 0.6, 1.2
ROCKET_FROM = 0.6
RESULT_WAIT = 1.0
GRID = [(8.0, -2.5), (8.0, 2.5), (16.0, -2.5), (16.0, 2.5), (24.0, -2.5), (24.0, 2.5)]
PLAYER_GRID = 5
RIVALS = 5
MAP_SIZE = 150
REPLAY_SLOTS = 3
REPLAY_CAMERAS = ("side", "chase", "top")
SIDE_FOV = (14.0, 60.0)
SIDE_ZOOM = 900.0
PITCH_SIGN = -1.0
CAMERA_RISE = 6.0
TOP_HEIGHT, TOP_BACK = 45.0, 8.0
BUMP_SLOW = 0.9
BUMP_PUSH = 2.0
BUMP_NEAR = 8.0
YELLOW = (255, 225, 90)
RED = (240, 70, 60)
WRONG_WAY = 0.5
DIRECTIONS = ("up", "down", "left", "right")
DRIFT_WINDOW = 0.4
class Racer(Game):
    title = "ドリフトレーサー"
    background = SKY
    step_seconds = 1 / 60
    log_scenes = True
    save_with_command = False
    uses_3d = True
    web_keyboard = {}
    web_touch_layout = {}
    web_sound_band = (300, 6000)
    def controls(self):
        return {"dpad", "left_stick", "a", "b", "x", "y", "r1", "r2", "l2", "start"}
    def start(self):
        view = self.view = g3d.View(self, size=VIEW_SIZE)
        self.tracks = {index: self.build_track(courses.TRACKS[index]) for index in courses.ORDER}
        self.car = carlib.Car(self.tracks[0].course)
        self.car_index = 0
        self.car_meshes = [view.mesh(spec.shape()) for spec in cars.CARS]
        self.smoke = effects.Smoke(view)
        self.dust = effects.Dust(view)
        self.flame = effects.flame(view)
        self.tach = hud.Tachometer()
        self.wind = effects.wind()
        self.recorder = replaylib.Recorder()
        self.player = None
        self.banner = anim.Timer(2.0)
        self.countdown = anim.Countdown(COUNT_SECONDS)
        self.audio = audiolib.Audio(self.sound)
        view.light((0.4, -1.0, 0.5), ambient=0.55)
        self.progress = Progress(self, stages=courses.COUNT, low=10.0)
        self.garage = garagelib.Garage(self.load_json(garagelib.FILE, garagelib.EMPTY, schema=garagelib.SCHEMA, migrate=garagelib.migrate),
                                       prices=[spec.price for spec in cars.CARS], game=self)
        self.earned = 0
        self.log("garage: credits=%d gp_best=%d" % (self.garage.credits, self.garage.gp_best))
        self.set_car(self.garage.car)
        self.log("progress: best=%s" % ",".join("-" if self.progress.best[n] is None else "%.2f" % self.progress.best[n]
                                                for n in range(courses.COUNT)))
        self.use_track(0)
        self.pick = 0
        self.rival_count = RIVALS
        self.items = ["レース", "グランプリ", "リプレイ", "ストア", "操作説明"]
        self.gp = None
        self.shop_cursor = 0
        self.shop_note = anim.Timer(1.5)
        self.shop_reason = ""
        self.slots = Slots(self, count=REPLAY_SLOTS, name="replay%d.json", empty=replaylib.EMPTY, schema=replaylib.SCHEMA,
                           filled=lambda saved: bool(saved["data"]))
        self.log("replay: saved=%s" % ",".join(self.slot_label(n, short=True) for n in range(REPLAY_SLOTS)))
        self.cursor = 0
        self.reset_race()
        self.enter("title")
    def build_track(self, track):
        view = self.view
        course = Course(track.layout, track.surface, track.profile, track.cross)
        road = view.texture_rows(*track.road)
        wall = view.texture_rows(*track.wall)
        fixed = []
        for road_shape, wall_shape, side_shape in course.chunks():
            fixed.append((view.mesh(road_shape, texture=road),) + road_shape.bounds())
            fixed.append((view.mesh(wall_shape, texture=wall),) + wall_shape.bounds())
            if side_shape:
                fixed.append((view.mesh(side_shape, color=track.ground),) + side_shape.bounds())
        bridge = course.bridge()
        if bridge:
            fixed.append((view.mesh(bridge),) + bridge.bounds())
        for shape in course.scenery(style=track.scenery):
            fixed.append((view.mesh(shape),) + shape.bounds())
        pace = rivallib.Pace(course)
        return Namespace(track=track, course=course, fixed=fixed,
                         ground=view.mesh(g3d.plane(FOG_FAR * 3, FOG_FAR * 3, cells=6), color=track.ground),
                         rivals=[rivallib.Rival(course, pace, skill, color) for skill, color in zip(rivallib.SKILLS, rivallib.COLORS)],
                         cameras=replaylib.Cameras(course), map=hud.CourseMap(course, WIDTH - MAP_SIZE - 16, 16, MAP_SIZE),
                         preview=hud.CourseMap(course, 424, 110, 272, line=4))
    def use_track(self, index):
        built = self.tracks[index]
        self.track_index, self.track = index, built.track
        self.course, self.fixed, self.ground = built.course, built.fixed, built.ground
        self.all_rivals, self.cameras, self.map = built.rivals, built.cameras, built.map
        self.car.course = built.course
        self.background = built.track.sky
        self.view.background(built.track.sky)
        self.view.fog(built.track.sky, FOG_NEAR, FOG_FAR)
    def hidden_command(self, text):
        values = self.command_values()
        race = None
        if values.flag("gp"):
            race = values.int("gp", 1, gplib.RACES) if values.text("gp") else 1
            race = race or 1
        track = values.int("course", 0, courses.COUNT - 1)
        if race is not None:
            track = None
        if track is not None:
            if track in self.tracks:
                self.use_track(track)
            else:
                self.log("command: course=%d is not built yet" % track)
        chosen = values.int("car", 0, len(cars.CARS) - 1)
        if chosen is not None:
            self.set_car(chosen)
        at, speed = values.int("at", 0, 99), values.float("speed", 0.0, self.car.max_speed)
        tanks, lap = values.int("nitro", 0, carlib.TANKS), values.int("lap", 1, LAPS)
        rivals = values.int("rivals", 0, RIVALS)
        credits = values.int("credits", 0, garagelib.LIMIT)
        if credits is not None:
            self.garage.credits = credits
        if rivals is not None:
            self.rival_count = rivals
        if values.flag("own"):
            self.garage = self.garage.with_all_cars()
        parts = values.int("parts", 0, len(cars.PARTS))
        if parts is not None:
            self.garage = self.garage.with_parts(parts)
        if values.flag("select"):
            self.open_select()
            return
        if values.flag("store"):
            if chosen is not None:
                self.garage.ride(chosen)
            self.set_car(self.garage.car)
            self.open_store()
            return
        if race is not None:
            self.begin_gp(race)
        self.start_race(count=not values.flag("nocount"))
        if at is not None:
            self.car.place(self.course.total * at / 100.0, values.float("side", -6.0, 6.0) or 0.0)
            self.run = self.car.dist
        if speed is not None:
            self.car.speed = speed
        if tanks is not None:
            self.car.tanks = tanks
        if lap is not None:
            self.run += (lap - 1) * self.course.total
            self.laps_done = lap - 1
            self.lap_times = [None] * (lap - 1)
        self.camera_angle = self.car.travel
        self.camera_y = self.car.y
    def menu_items(self):
        items = []
        if self.scene in ("count", "play") and self.gp is None:
            items.append(("最初からやり直す", self.start_race))
        if self.scene != "title":
            items.append(("タイトルへ戻る", self.go_title if self.gp is None else self.ask_quit_gp))
        items.append(("操作説明", self.open_guide))
        return items
    def save(self):
        self.garage.save()
    def set_car(self, index):
        self.car_index = index
        self.car.equip(cars.CARS[index])
        self.tach.set_top(self.car.max_speed + carlib.NITRO_BONUS)
    def open_guide(self):
        self.open(guide.Guide(self))
    def reset_race(self):
        back, side = GRID[PLAYER_GRID]
        self.car.place(self.course.total - back, side)
        self.run = -back
        self.rivals = self.all_rivals[:self.rival_count]
        for (back, side), rival in zip(GRID, self.rivals):
            rival.place(-back, side)
        self.recorder.clear(len(self.rivals), self.step_seconds, heights=self.course.hilly)
        self.bumps = 0
        self.touching = set()
        self.final_rank = None
        self.laps_done = 0
        self.lap_times = []
        self.time = 0.0
        self.lap_start = 0.0
        self.banner.stop()
        self.banner_text = ""
        self.rev = hud.IDLE
        self.start_kind = ""
        self.new_best = False
        self.earned = 0
        self.audio.quiet()
        self.landed = 0
        self.fallen = 0
        self.wrong = 0.0
        self.credit_due = False
        self.smoke.clear()
        self.dust.clear()
        self.tach.reset()
        self.wind.clear()
        self.fov = FOV
        self.camera_angle = self.car.travel
        self.camera_y = self.car.y
        self.steer, self.accel, self.brake, self.drift, self.nitro = 0, False, False, False, 0
        self.reverse = False
        self.clean = True
        self.slowed_at = -DRIFT_WINDOW * 2
        self.turned_at = None
    def start_race(self, count=True):
        self.reset_race()
        self.log("race: start course=%d car=%d" % (self.track_index, self.car_index))
        if count:
            self.countdown.start()
        self.enter("count" if count else "play")
    def go_title(self):
        self.gp = None
        self.reset_race()
        self.cursor = 0
        self.enter("title")
    def begin_gp(self, race=1):
        self.gp = gplib.GrandPrix(1 + self.rival_count, race)
        self.use_track(self.gp.course)
        self.log("gp: start race=%d cars=%d car=%d" % (race, self.gp.cars, self.car_index))
    def ask_quit_gp(self):
        self.confirm("グランプリをやめますか？", self.quit_gp, yes="やめる", no="続ける",
                     lines=["第 %d 戦。次は、第 1 戦から" % self.gp.race, "もらったクレジットは、残ります"])
    def quit_gp(self):
        self.log("gp: quit race=%d" % self.gp.race)
        self.go_title()
    def gp_ranks(self):
        return gplib.places(self.final_rank, [rival.run for rival in self.rivals])
    def open_standings(self):
        gp = self.gp
        self.enter("standings")
        self.log("gp: standings race=%d place=%d points=%s" % (gp.race, gp.place(), ",".join(str(n) for n in gp.totals)))
        if gp.final:
            place = gp.place()
            new = not self.command and self.garage.record_gp(place)
            if new:
                self.garage.save()
            self.log("gp: final place=%d/%d best=%d%s" % (place, gp.cars, self.garage.gp_best, " new" if new else ""))
            self.audio.play("gp")
    def update_standings(self, dt):
        inp = self.input
        self.audio.music(audiolib.MUSIC_MENU)
        if inp.tapped("a", since=self.entered, wait=RESULT_WAIT):
            self.audio.play("decide")
            if self.gp.advance():
                self.use_track(self.gp.course)
                self.start_race()
            else:
                self.go_title()
    def finish(self):
        self.final_rank = self.rank
        self.new_best = self.progress.record(self.track_index, self.time)
        self.progress.save()
        base = garagelib.reward(self.final_rank)
        if self.gp is not None:
            self.gp.score(self.gp_ranks())
            base = gplib.credits(base, self.gp.race)
        self.earned = self.garage.earn(base)
        self.garage.save()
        best = self.progress.best[self.track_index]
        self.log("race: finish course=%d rank=%d/%d time=%.2f laps=%s best=%s%s credits=+%d total=%d" % (
            self.track_index, self.final_rank, len(self.rivals) + 1, self.time,
            ",".join("-" if lap is None else "%.2f" % lap for lap in self.lap_times), "-" if best is None else "%.2f" % best, " new" if self.new_best else "",
            self.earned, self.garage.credits))
        if self.gp is not None:
            gp = self.gp
            self.log("gp: race=%d course=%d rank=%d points=+%d total=%d x%.1f" % (
                gp.race, self.track_index, self.final_rank, gp.gained[0], gp.totals[0], gplib.multiplier(gp.race)))
        self.recorder.add(self.car, self.rivals, force=True)
        self.recorder.laps = [sum(lap for lap in self.lap_times[:n + 1] if lap is not None) for n in range(len(self.lap_times))]
        self.audio.quiet()
        self.audio.play("record" if self.new_best else "goal")
        self.credit_due = self.earned > 0
        self.enter("result")
    def slot_label(self, n, short=False):
        saved = self.slots.data(n)
        if saved is None:
            return "-" if short else "%d:  （空き）" % (n + 1)
        if short:
            return "%d/%d:%.2f" % (saved["rank"], saved["cars"], saved["time"]) + ("@%d" % saved["track"] if saved["track"] else "")
        track = courses.TRACKS.get(saved["track"])
        return "%d:  %s  %d 位  %s" % (n + 1, track.name if track else "?", saved["rank"], format_time(saved["time"]))
    def rival_sides(self):
        return [(rival.side, rival.color) for rival in self.rivals]
    def open_save(self):
        self.slots.pick("リプレイを保存", lambda n, saved: self.slot_label(n), self.save_replay)
    def save_replay(self, n):
        data = replaylib.pack(self.recorder, self.course, self.rank, len(self.rivals) + 1, self.time, self.rival_sides(),
                              car=self.car_index, track=self.track_index)
        if not self.slots.write(n, data):
            return
        self.log("replay: save slot=%d rank=%d time=%.2f samples=%d chars=%d" % (
            n + 1, data["rank"], data["time"], len(self.recorder), len(data["data"])))
        self.message("保存しました", [self.slot_label(n), "タイトルの「リプレイ」から、見られます"])
    def open_saved(self):
        self.slots.pick("保存したリプレイ", lambda n, saved: self.slot_label(n), self.view_saved, confirm=None)
    def view_saved(self, n):
        saved = self.slots.data(n)
        if saved and saved["track"] in self.tracks:
            self.use_track(saved["track"])
        found = replaylib.unpack(saved, self.course) if saved else None
        if found is None:
            self.message("リプレイ %d" % (n + 1), ["まだ、保存されていません" if saved is None else "このリプレイは、読めません"])
            return
        self.log("replay: view slot=%d" % (n + 1))
        self.start_replay(found[0], found[1], back="title", car=saved["car"] if saved["car"] < len(cars.CARS) else 0)
    def start_replay(self, recorder=None, sides=None, back="result", car=None):
        self.replay_rec = self.recorder if recorder is None else recorder
        self.replay_back = back
        self.replay_car = self.car_index if car is None else car
        self.player = replaylib.Player(self.replay_rec, self.course, self.rival_sides() if sides is None else sides)
        self.replay_time = 0.0
        self.replay_camera = 0
        self.shot = self.player.at(0.0)
        self.replay_angle = self.shot.travel
        self.replay_fov = FOV
        self.replay_spot = None
        self.smoke.clear()
        self.dust.clear()
        self.audio.quiet()
        self.enter("replay")
    def end_replay(self):
        self.player = None
        self.smoke.clear()
        self.dust.clear()
        self.audio.quiet()
        if self.replay_back == "title":
            self.go_title()
        else:
            self.enter("result")
    @property
    def lap(self):
        return min(LAPS, self.laps_done + 1)
    @property
    def rank(self):
        if self.final_rank is not None:
            return self.final_rank
        return 1 + sum(1 for rival in self.rivals if rival.run >= self.run)
    def update_title(self, dt):
        inp = self.input
        self.audio.music(audiolib.MUSIC_MENU)
        before = self.cursor
        self.cursor = max(0, min(len(self.items) - 1, self.cursor + inp.cursor("up", "down", among=DIRECTIONS)))
        if self.cursor != before:
            self.audio.play("select")
        if inp.tapped("a", since=self.entered):
            item = self.items[self.cursor]
            self.audio.play("decide")
            if item == "レース":
                self.open_select()
            elif item == "グランプリ":
                self.begin_gp()
                self.start_race()
            elif item == "リプレイ":
                self.open_saved()
            elif item == "ストア":
                self.open_store()
            else:
                self.open_guide()
    def open_select(self):
        self.pick = courses.ORDER.index(self.track_index)
        self.enter("select")
    def update_select(self, dt):
        inp = self.input
        self.audio.music(audiolib.MUSIC_MENU)
        before = self.pick
        self.pick = max(0, min(len(courses.ORDER) - 1, self.pick + inp.cursor("up", "down", among=DIRECTIONS)))
        if self.pick != before:
            self.audio.play("select")
        if inp.tapped("a"):
            self.audio.play("decide")
            self.use_track(courses.ORDER[self.pick])
            self.start_race()
        elif inp.tapped("b"):
            self.audio.play("back")
            self.go_title()
    def draw_select(self, gfx):
        gfx.rect(0, 0, WIDTH, HEIGHT, (26, 30, 46))
        gfx.text(24, 26, "コースを選ぶ", 48, WHITE)
        for row, index in enumerate(courses.ORDER):
            y = 120 + row * 70
            if row == self.pick:
                gfx.rect(16, y - 6, 392, 62, (52, 92, 168))
            gfx.text(32, y, courses.TRACKS[index].name, 30, WHITE)
            best = self.progress.best[index]
            gfx.text(396, y + 6, format_time(best) if best is not None else "--:--.-", 26, WHITE, align="right")
        built = self.tracks[courses.ORDER[self.pick]]
        built.preview.draw_outline(gfx)
        gfx.text(560, 410, built.track.name, 30, YELLOW, align="center")
        gfx.text(560, 456, "1 周 %s m" % format(int(round(built.course.total)), ","), 24, WHITE, align="center")
        gfx.text(560, 492, built.track.note, 24, WHITE, align="center")
        gfx.text(560, 528, self.best_text(built.track.index), 24, WHITE, align="center")
        gfx.text(WIDTH // 2, HEIGHT - 56, "上下: 選ぶ　A: 走る　B: もどる", 26, WHITE, align="center")
    def open_store(self):
        self.shop_cursor = self.garage.car
        self.shop_note.stop()
        self.enter("store")
    def update_store(self, dt):
        inp = self.input
        self.audio.music(audiolib.MUSIC_MENU)
        self.shop_note.update(dt)
        before = self.shop_cursor
        last = len(cars.CARS) + len(cars.PARTS) - 1
        self.shop_cursor = max(0, min(last, self.shop_cursor + inp.cursor("up", "down", among=DIRECTIONS)))
        if self.shop_cursor != before:
            self.audio.play("select")
        if inp.tapped("a"):
            if self.shop_cursor < len(cars.CARS):
                self.pick_car(self.shop_cursor)
            else:
                self.pick_part(cars.PARTS[self.shop_cursor - len(cars.CARS)])
        elif inp.tapped("b"):
            self.audio.play("back")
            self.go_title()
    def pick_car(self, n):
        spec, garage = cars.CARS[n], self.garage
        if garage.owned[n]:
            if garage.ride(n):
                self.audio.play("decide")
                self.ride_done(n, "ride")
        elif garage.can_buy(n):
            self.audio.play("decide")
            self.confirm("買いますか？", partial(self.buy_car, n), yes="買う", no="やめる",
                         lines=["%s　%s CR" % (spec.name, format(spec.price, ",")),
                                "残り　%s CR" % format(garage.credits - spec.price, ",")])
        else:
            self.deny("クレジットが足りません")
    def pick_part(self, part):
        garage, price = self.garage, self.garage.price(part.key)
        if garage.has(part.key):
            return
        if garage.can_buy_part(part.key):
            self.audio.play("decide")
            self.confirm("買いますか？", partial(self.buy_part, part), yes="買う", no="やめる",
                         lines=["%s　%s CR" % (part.name, format(price, ",")), "残り　%s CR" % format(garage.credits - price, ",")])
        else:
            self.deny("ダブルニトロが要ります" if garage.needs(part.key) else "クレジットが足りません")
    def deny(self, text):
        self.shop_reason = text
        self.shop_note.start()
        self.audio.play("deny")
    def buy_car(self, n):
        if self.garage.buy(n):
            self.audio.play("buy")
            self.ride_done(n, "buy")
    def buy_part(self, part):
        if self.garage.buy_part(part.key):
            self.audio.play("buy")
            self.garage.save()
            self.log("store: buy part=%s credits=%d" % (part.key, self.garage.credits))
    def ride_done(self, n, how):
        self.set_car(n)
        self.garage.save()
        self.log("store: %s car=%d credits=%d" % (how, n, self.garage.credits))
    def shop_label(self, n):
        garage, dim = self.garage, (130, 135, 150)
        if n < len(cars.CARS):
            spec = cars.CARS[n]
            if garage.owned[n]:
                return (spec.name,) + (("乗っている", YELLOW) if garage.car == n else ("持っている", WHITE))
            return spec.name, "%s CR" % format(spec.price, ","), WHITE if garage.credits >= spec.price else dim
        part = cars.PARTS[n - len(cars.CARS)]
        if garage.has(part.key):
            return part.name, "持っている", WHITE
        if garage.needs(part.key):
            return part.name, "ダブルが要る", dim
        price = garage.price(part.key)
        return part.name, "%s CR" % format(price, ","), WHITE if garage.credits >= price else dim
    def draw_store(self, gfx):
        garage, n = self.garage, self.shop_cursor
        gfx.rect(0, 0, WIDTH, HEIGHT, (26, 30, 46))
        px, py, size = 424, 110, 272
        gfx.rect(px - 4, py - 4, size + 8, size + 8, (70, 78, 104))
        gfx.text(24, 26, "ストア", 48, WHITE)
        gfx.text(WIDTH - 24, 36, "%s CR" % format(garage.credits, ","), 36, YELLOW, align="right")
        for row in range(len(cars.CARS) + len(cars.PARTS)):
            y = 112 + row * 64
            if row == n:
                gfx.rect(16, y - 6, 392, 56, (52, 92, 168))
            name, label, color = self.shop_label(row)
            gfx.text(32, y, name, 30, WHITE)
            gfx.text(396, y + 6, label, 26, color, align="right")
        if n < len(cars.CARS):
            chosen = cars.CARS[n]
            self.draw_world(orbit=self.scene_time * 30.0, look=0.6, rivals=[], look_car=n, show=(px, py, size, size))
            gfx.text(px + size // 2, py + size + 20, chosen.name, 30, YELLOW, align="center")
            bars = (("加速", chosen.accel / 44.0), ("最高速", (chosen.max_speed - 55.0) / 17.0), ("すべり", chosen.drift_turn / 140.0))
            for i, (name, value) in enumerate(bars):
                y = py + size + 70 + i * 36
                gfx.text(px, y, name, 24, WHITE, valign="middle")
                gfxfx.bar(gfx, px + 92, y - 8, size - 92, 16, value, TANK_FULL, back=TANK_EMPTY, edge=SHADOW)
            gfx.text(WIDTH // 2, 604, chosen.note, 24, WHITE, align="center", valign="middle")
            hint = "乗っている" if garage.car == n else ("A: 乗る" if garage.owned[n] else "A: 買う")
        else:
            part = cars.PARTS[n - len(cars.CARS)]
            gfx.rect(px, py, size, size, (34, 40, 60))
            gfx.text(px + size // 2, py + 40, part.name, 30, YELLOW, align="center", valign="middle")
            gfx.text(px + size // 2, py + 100, "%s x%d" % (part.button, part.count), 48, TANK_FULL, align="center", valign="middle")
            for i, text in enumerate(part.lines):
                gfx.text(px + size // 2, py + 158 + i * 30, text, 20, WHITE, align="center", valign="middle")
            hint = "持っている" if garage.has(part.key) else "A: 買う"
        if self.shop_note.active:
            gfx.text(212, 512, self.shop_reason, 26, (255, 140, 120), align="center")
        gfx.text(WIDTH // 2, HEIGHT - 56, "上下: 選ぶ　%s　B: もどる" % hint, 26, WHITE, align="center")
    def update_count(self, dt):
        inp = self.input
        self.audio.music(None)
        revving = inp.only(*COUNT_DRIVE) and inp.down("b") and not inp.down("y")
        self.rev = anim.approach(self.rev, 1.0 if revving else hud.IDLE, (REV_UP if revving else REV_DOWN) * dt)
        self.tach.rev(self.rev, dt)
        self.audio.drive(self.rev, revving)
        told = self.countdown.update(dt)
        if told and told != "go":
            self.audio.play("count")
        if told == "go":
            self.start_kind = "spin" if self.rev >= hud.RED_ZONE else ("rocket" if self.rev >= ROCKET_FROM else "")
            self.car.start(self.start_kind)
            self.log("race: go rev=%.2f %s" % (self.rev, self.start_kind or "normal"))
            self.audio.play("go")
            if self.start_kind:
                self.audio.play(self.start_kind)
            self.enter("play")
    def update_play(self, dt):
        inp = self.input
        self.audio.music(audiolib.MUSIC_RACE)
        drive = inp.only(*DRIVE)
        steer = inp.direction()[0] if drive else 0
        reverse = drive and inp.down("a")
        brake = drive and inp.down("y") and not reverse
        accel = drive and inp.down("b") and not brake and not reverse
        clean = inp.none_but(*DRIVE) and not self.car.air
        if clean and self.clean:
            now = inp.now()
            slowed = (self.accel and not accel) or (brake and not self.brake)
            turned = steer != 0 and steer != self.steer
            if slowed:
                self.slowed_at = now
            if turned:
                self.turned_at = now
            if ((slowed or turned) and steer and not accel and not reverse and self.turned_at is not None
                    and abs(self.slowed_at - self.turned_at) <= DRIFT_WINDOW):
                self.drift = True
        if not steer:
            self.turned_at = None
        self.steer, self.accel, self.brake, self.clean, self.reverse = steer, accel, brake, clean, reverse
        if drive and not reverse and self.car.speed >= 0.0:
            asked = [count for count, button, part in ((3, "l2", "triple"), (2, "r2", "double"), (1, "r1", None))
                     if inp.pressed(button) and (part is None or self.garage.has(part))]
            usable = [count for count in asked if count <= self.car.tanks]
            if usable:
                self.nitro = usable[0]
        self.fov = anim.follow(self.fov, FOV_BOOST if self.car.boost > 0 else FOV, 4.0, dt)
        self.tach.update(abs(self.car.speed), dt)
        self.wind.update(dt, self.car.draft)
        car = self.car
        self.audio.drive(min(1.0, abs(car.speed) / car.max_speed), accel or reverse or car.boost > 0, car.drifting or car.spin > 0, car.boost > 0, car.draft)
        self.audio.watch(car.tanks, car.boost > 0, car.hits, self.bumps, car.kind, car.landings)
        self.camera_angle = anim.follow_angle(self.camera_angle, self.car.travel, CAMERA_FOLLOW, dt)
        if not self.car.air:
            self.camera_y = anim.follow(self.camera_y, self.car.y, CAMERA_RISE, dt)
    def update_result(self, dt):
        inp = self.input
        self.audio.music(audiolib.MUSIC_MENU)
        if self.credit_due and self.scene_time >= RESULT_WAIT:
            self.credit_due = False
            self.audio.play("credit")
        if inp.tapped("a", since=self.entered, wait=RESULT_WAIT):
            self.audio.play("decide")
            if self.gp is None:
                self.start_race()
            else:
                self.open_standings()
        elif inp.tapped("b", since=self.entered, wait=RESULT_WAIT) and self.gp is None:
            self.audio.play("back")
            self.go_title()
        elif inp.tapped("x", since=self.entered, wait=RESULT_WAIT) and len(self.recorder) > 1:
            self.audio.play("decide")
            self.start_replay()
        elif inp.tapped("y", since=self.entered, wait=RESULT_WAIT) and self.can_save():
            self.audio.play("decide")
            self.open_save()
    def can_save(self):
        return len(self.recorder) > 1 and not self.command
    def update_replay(self, dt):
        inp = self.input
        self.audio.music(audiolib.MUSIC_RACE)
        shot = self.shot
        self.audio.drive(min(1.0, shot.speed / cars.CARS[self.replay_car].max_speed), True, shot.drifting or shot.spin > 0, shot.boost > 0)
        if inp.tapped("a"):
            self.audio.play("select")
            self.replay_camera = (self.replay_camera + 1) % len(REPLAY_CAMERAS)
        elif inp.tapped("b"):
            self.end_replay()
            self.audio.play("back")
    def step_replay(self):
        dt = self.step_seconds
        self.replay_time += dt
        self.shot = self.player.at(self.replay_time)
        self.replay_angle = anim.follow_angle(self.replay_angle, self.shot.travel, CAMERA_FOLLOW, dt)
        self.smoke.step(dt, self.shot)
        self.dust.step(dt, self.shot, self.course.surface)
        if self.replay_time >= self.replay_rec.duration:
            self.end_replay()
    def step_play(self):
        dt = self.step_seconds
        car, total = self.car, self.course.total
        self.banner.update(dt)
        for rival in self.rivals:
            rival.step(dt)
        before = (car.x, car.z, car.segment, car.dist, car.side)
        behind = rivallib.slipstream(self.rivals, car.x, car.z, self.run, car.y)
        car.step(dt, self.steer, self.accel, self.brake, self.drift, self.nitro, behind, self.reverse)
        self.drift, self.nitro = False, 0
        moved = self.course.advance(before[3], car.dist)
        if car.falls > self.fallen:
            self.fallen = car.falls
            cross = self.course.cross
            moved = (car.dist - cross[1]) - (before[3] - cross[0]) - (cross[0] - cross[1])
            self.log("air: fall dist=%d to=%d speed=%.1f angle=%d wrong=%s" % (before[3], car.dist, car.speed, car.angle,
                     "yes" if abs(carlib.wrap(car.travel - self.course.points[car.segment][2])) > 90.0 else "no"))
            self.camera_angle = car.travel
        if self.bump(self.run + moved):
            car.x, car.z, car.segment, car.dist, car.side = before
            moved = 0.0
        rivallib.queue(self.rivals)
        backward = abs(carlib.wrap(car.travel - self.course.points[car.segment][2])) > 90.0
        self.wrong = self.wrong + dt if backward else 0.0
        if car.landings > self.landed:
            self.landed = car.landings
            self.log("air: land dist=%d speed=%.1f flight=%.2f peak=%.2f" % (car.dist, car.speed, car.flight, car.peak))
            (self.dust if self.course.surface.dust else self.smoke).burst(car)
        self.smoke.step(dt, car)
        self.dust.step(dt, car, self.course.surface)
        self.recorder.add(car, self.rivals)
        self.time += dt
        self.run += moved
        if self.run >= (self.laps_done + 1) * total:
            self.laps_done += 1
            self.lap_times.append(self.time - self.lap_start)
            self.lap_start = self.time
            if self.laps_done >= LAPS:
                self.finish()
            else:
                self.banner_text = "FINAL LAP" if self.laps_done == LAPS - 1 else "LAP %d" % (self.laps_done + 1)
                self.banner.start()
                self.audio.play("final" if self.laps_done == LAPS - 1 else "lap")
    def step_result(self):
        dt = self.step_seconds
        for rival in self.rivals:
            rival.step(dt)
        self.car.step(dt, 0, False, True)
        self.smoke.step(dt, self.car)
        self.dust.step(dt, self.car, self.course.surface)
    def bump(self, run):
        car, mine, blocked = self.car, None, False
        for rival in self.rivals:
            if abs(rival.run - run) > BUMP_NEAR or abs(rival.y - car.y) > rivallib.APART:
                self.touching.discard(rival)
                continue
            mine = mine or car.box()
            if not g3dtop.overlap(mine, rival.box()):
                self.touching.discard(rival)
                continue
            if rival not in self.touching:
                self.touching.add(rival)
                self.bumps += 1
            if run < rival.run:
                car.speed = min(car.speed, rival.speed * BUMP_SLOW)
                rival.speed += BUMP_PUSH
                blocked = True
            elif car.speed < 0.0:
                car.speed = 0.0
                blocked = True
            else:
                rival.back(car.speed * BUMP_SLOW)
                car.speed += BUMP_PUSH if car.speed > 1.0 else 0.0
        return blocked
    def best_text(self, index=None):
        best = self.progress.best[self.track_index if index is None else index]
        return "BEST " + (format_time(best) if best is not None else "--:--.-")
    def draw_title(self, gfx):
        self.draw_world(orbit=self.scene_time * 20.0, look=-0.6)
        gfx.text(WIDTH // 2, 60, "ドリフトレーサー", 80, WHITE, align="center", shadow=SHADOW, offset=4)
        for i, item in enumerate(self.items):
            chosen = i == self.cursor
            y = 360 + i * 52
            width = gfx.text(WIDTH // 2, y, ("▶ " if chosen else "") + item, 40, YELLOW if chosen else WHITE,
                             align="center", shadow=SHADOW)
            if item == "グランプリ" and self.garage.gp_best:
                gfx.text(WIDTH // 2 + width // 2 + 16, y + 12, "BEST %d 位" % self.garage.gp_best, 24, WHITE, shadow=SHADOW)
        gfx.text(WIDTH - 24, 158, "%s CR" % format(self.garage.credits, ","), 32, YELLOW, align="right", shadow=SHADOW)
        gfx.text(WIDTH // 2, HEIGHT - 92, "上下: 選ぶ　A: 決定", 28, WHITE, align="center", shadow=SHADOW)
    def draw_count(self, gfx):
        self.draw_world()
        self.draw_race(gfx)
        if self.gp is not None:
            gfx.text(WIDTH // 2, 380, "第 %d 戦　%s" % (self.gp.race, self.track.name), 36, WHITE, align="center", shadow=SHADOW)
        gfx.text(WIDTH // 2, 250, "%d" % max(1, self.countdown.number), 200, YELLOW, align="center", valign="middle", shadow=SHADOW, offset=6)
    def draw_play(self, gfx):
        self.draw_world()
        self.wind.draw(gfx)
        self.draw_race(gfx)
        if self.scene_time < 1.0:
            gfx.text(WIDTH // 2, 250, "GO!", 160, YELLOW, align="center", valign="middle", shadow=SHADOW, offset=6)
            if self.start_kind:
                gfx.text(WIDTH // 2, 360, "ROCKET START!" if self.start_kind == "rocket" else "WHEEL SPIN", 40,
                         YELLOW if self.start_kind == "rocket" else WHITE, align="center", valign="middle", shadow=SHADOW)
        elif self.banner.active:
            gfx.text(WIDTH // 2, 170, self.banner_text, 64, YELLOW, align="center", valign="middle", shadow=SHADOW, offset=3)
        if self.wrong >= WRONG_WAY:
            gfx.text(WIDTH // 2, 240, "逆走", 96, RED, align="center", valign="middle", shadow=SHADOW, offset=4)
    def draw_race(self, gfx):
        width = gfx.text(20, 8, "%d" % self.rank, 56, WHITE, shadow=SHADOW)
        gfx.text(26 + width, 30, "/ %d" % (len(self.rivals) + 1), 32, WHITE, shadow=SHADOW)
        gfx.text(20, 76, "LAP %d / %d" % (self.lap, LAPS), 32, WHITE, shadow=SHADOW)
        gfx.text(WIDTH // 2, 12, format_time(self.time), 40, WHITE, align="center", shadow=SHADOW)
        if self.lap_times and self.lap_times[-1] is not None:
            gfx.text(WIDTH // 2, 60, "LAP %d  %s" % (len(self.lap_times), format_time(self.lap_times[-1])), 28, WHITE,
                     align="center", shadow=SHADOW)
        self.map.draw(gfx, (self.car.x, self.car.z), cars.CARS[self.car_index].color,
                      [(rival.x, rival.z, rival.color) for rival in self.rivals])
        self.tach.draw(gfx, WIDTH - 112, HEIGHT - 112, abs(self.car.speed))
        self.draw_nitro(gfx)
    def draw_result(self, gfx):
        self.draw_world(orbit=self.camera_angle + 180.0 + self.scene_time * 25.0, look=4.2)
        gfx.text(WIDTH // 2, 36, "%d 位" % self.rank, 120, YELLOW, align="center", shadow=SHADOW, offset=5)
        gfx.text(WIDTH // 2, 188, format_time(self.time), 64, WHITE, align="center", shadow=SHADOW, offset=3)
        for i in range(LAPS):
            lap = self.lap_times[i] if i < len(self.lap_times) else None
            gfx.text(WIDTH // 2, 272 + i * 36, "LAP %d   %s" % (i + 1, format_time(lap) if lap is not None else "--:--.-"),
                     30, WHITE, align="center", shadow=SHADOW)
        gfx.text(WIDTH // 2, 386, self.best_text(), 30, WHITE, align="center", shadow=SHADOW)
        if self.new_best:
            gfx.text(WIDTH // 2, 424, "NEW RECORD", 36, YELLOW, align="center", shadow=SHADOW)
        gp = self.gp
        earned = "+%s CR" % format(self.earned, ",")
        if gp is not None:
            gfx.text(20, 20, "第 %d 戦" % gp.race, 32, WHITE, shadow=SHADOW)
            earned += "（x%.1f）" % gplib.multiplier(gp.race)
        gfx.text(WIDTH // 2, 474, earned, 40, YELLOW, align="center", shadow=SHADOW)
        if gp is not None:
            gfx.text(WIDTH // 2, 522, "+%d pt" % gp.gained[0], 32, YELLOW, align="center", shadow=SHADOW)
        gfx.text(WIDTH // 2, 522 if gp is None else 566, "%s CR" % format(self.garage.credits, ","), 28, WHITE, align="center", shadow=SHADOW)
        if self.scene_time >= RESULT_WAIT:
            keys = "A: もう一度　B: タイトル　X: リプレイ" if gp is None else "A: 次へ　X: リプレイ"
            gfx.text(WIDTH // 2, HEIGHT - 60, keys + ("　Y: 保存" if self.can_save() else ""), 26, WHITE, align="center", shadow=SHADOW)
    def draw_standings(self, gfx):
        gp = self.gp
        gfx.rect(0, 0, WIDTH, HEIGHT, (26, 30, 46))
        gfx.text(WIDTH // 2, 28, "グランプリ　結果" if gp.final else "グランプリ　第 %d 戦 終了" % gp.race, 44, WHITE, align="center")
        mine = cars.CARS[self.car_index].color
        for row, car in enumerate(gp.standings()):
            y = 110 + row * 60
            me = car == 0
            if me:
                gfx.rect(40, y - 6, WIDTH - 80, 54, (52, 92, 168))
            color = YELLOW if me else WHITE
            gfx.text(76, y, "%d" % (row + 1), 32, color, align="center")
            gfx.rect(116, y + 6, 30, 30, mine if me else rivallib.COLORS[(car - 1) % len(rivallib.COLORS)])
            gfx.text(166, y, gplib.name(car), 32, color)
            gfx.text(520, y, "+%d" % gp.gained[car], 32, color, align="right")
            gfx.text(640, y, "%d" % gp.totals[car], 32, color, align="right")
        bottom = 110 + gp.cars * 60 + 20
        if gp.final:
            gfx.text(WIDTH // 2, bottom, "総合 %d 位" % gp.place(), 96, YELLOW, align="center")
        else:
            gfx.text(WIDTH // 2, bottom, "NEXT: %s（クレジット x%.1f）" % (courses.TRACKS[gp.next_course].name, gplib.multiplier(gp.race + 1)),
                     30, WHITE, align="center")
        if self.scene_time >= RESULT_WAIT:
            gfx.text(WIDTH // 2, HEIGHT - 60, "A: 次へ", 26, WHITE, align="center")
    def draw_replay(self, gfx):
        shot, kind = self.shot, REPLAY_CAMERAS[self.replay_camera]
        if kind == "side":
            spot = self.cameras.pick(self.player.dist)
            ex, ez = self.cameras.spots[spot]
            fov = max(SIDE_FOV[0], min(SIDE_FOV[1], SIDE_ZOOM / max(1.0, math.hypot(shot.x - ex, shot.z - ez))))
            self.replay_fov = fov if spot != self.replay_spot else anim.follow(self.replay_fov, fov, 6.0, 1 / self.fps)
            self.replay_spot = spot
            aim = ((ex, self.cameras.heights[spot], ez), (shot.x, shot.y + 0.8, shot.z), self.replay_fov)
        elif kind == "chase":
            ex, ez = g3dtop.world(shot.x, shot.z, self.replay_angle, -CAMERA_BACK, 0.0)
            ax, az = g3dtop.world(shot.x, shot.z, self.replay_angle, CAMERA_AHEAD, 0.0)
            aim = ((ex, shot.y + CAMERA_HEIGHT, ez), (ax, shot.y + 1.0, az), FOV)
            self.replay_spot = None
        else:
            ex, ez = g3dtop.world(shot.x, shot.z, self.replay_angle, -TOP_BACK, 0.0)
            aim = ((ex, shot.y + TOP_HEIGHT, ez), (shot.x, shot.y, shot.z), 50.0)
            self.replay_spot = None
        self.draw_world(car=shot, rivals=shot.rivals, aim=aim, time=self.replay_time, look_car=self.replay_car)
        if int(self.scene_time) % 2 == 0:
            gfx.text(20, 12, "REPLAY", 40, YELLOW, shadow=SHADOW)
        gfx.text(WIDTH - 20, 12, format_time(self.replay_time), 32, WHITE, align="right", shadow=SHADOW)
        gfx.text(WIDTH - 20, 52, "LAP %d / %d" % (min(LAPS, self.replay_rec.lap(self.replay_time)), LAPS), 28, WHITE,
                 align="right", shadow=SHADOW)
        gfx.text(WIDTH // 2, HEIGHT - 60, "A: カメラ　B: もどる", 28, WHITE, align="center", shadow=SHADOW)
    def draw_nitro(self, gfx):
        car = self.car
        x, y, h = 20, HEIGHT - 52, 24
        gfx.text(x, y - 34, "NITRO", 24, WHITE, shadow=SHADOW)
        total = gfxfx.cells(gfx, x, y, carlib.TANKS, car.tanks, part=car.gauge, w=48, h=h, gap=8, full=TANK_FULL,
                            empty=TANK_EMPTY, fill=TANK_FILL, edge=SHADOW)
        if car.boost > 0:
            gfxfx.bar(gfx, x, y + h + 8, total, 8, car.boost / car.shot, BOOST_COLORS[car.kind], edge=SHADOW)
        hx = x + total + 14
        for part in cars.PARTS:
            if self.garage.has(part.key):
                gfx.text(hx, y + h // 2, "%s x%d" % (part.button, part.count), 24,
                         WHITE if car.tanks >= part.count else (120, 125, 140), valign="middle", shadow=SHADOW)
                hx += 96
    def draw_world(self, orbit=None, look=0.8, car=None, rivals=None, aim=None, time=None, look_car=None, show=None):
        view = self.view
        car = self.car if car is None else car
        rivals = self.rivals if rivals is None else rivals
        moment = self.time if time is None else time
        bump = effects.shake(moment, car.speed, self.car.max_speed) if self.course.surface.dust else 0.0
        cy = getattr(car, "y", 0.0)
        if aim is not None:
            view.camera(eye=aim[0], look_at=aim[1], fov=aim[2])
        elif orbit is None:
            ex, ez = g3dtop.world(car.x, car.z, self.camera_angle, -CAMERA_BACK, 0.0)
            ax, az = g3dtop.world(car.x, car.z, self.camera_angle, CAMERA_AHEAD, 0.0)
            view.camera(eye=(ex, self.camera_y + CAMERA_HEIGHT + bump * 0.6, ez), look_at=(ax, self.camera_y + 1.0, az), fov=self.fov)
        else:
            view.orbit((car.x, cy + look, car.z), ORBIT_RADIUS, ORBIT_HEIGHT - look, orbit, fov=FOV)
        view.draw(self.ground, pos=(car.x, GROUND_Y, car.z))
        for mesh, center, radius in self.fixed:
            if view.reaches(center, radius):
                view.draw(mesh)
        course = self.course
        for n, rival in enumerate(rivals):
            ry = getattr(rival, "y", 0.0)
            if view.reaches((rival.x, ry, rival.z), 3.0):
                view.shadow((rival.x, course.ground(rival.run), rival.z), radius=1.7, strength=0.45)
                view.draw(self.car_meshes[rivallib.LOOKS[n % len(rivallib.LOOKS)]], pos=(rival.x, ry, rival.z),
                          rot=(self.pitch_of(rival), rival.angle, 0), color=rival.color)
        view.shadow((car.x, course.ground(car.dist), car.z), radius=1.7, strength=0.45)
        mine = self.car_index if look_car is None else look_car
        view.draw(self.car_meshes[mine], pos=(car.x, cy + bump, car.z), rot=(PITCH_SIGN * getattr(car, "pitch", 0.0), car.angle, 0),
                  color=cars.CARS[mine].color)
        self.smoke.draw()
        self.dust.draw()
        effects.draw_flame(self.flame, car, self.time if time is None else time)
        view.show(*show) if show else view.show()
    def pitch_of(self, rival):
        if not self.course.hilly:
            return 0.0
        return PITCH_SIGN * math.degrees(math.atan(self.course.slope(rival.run)))
    def debug_state(self):
        car = self.car
        return {"scene": self.scene, "lap": self.lap, "time": round(self.time, 2), "run": int(self.run),
                "laps": [None if lap is None else round(lap, 2) for lap in self.lap_times],
                "best": None if self.progress.best[self.track_index] is None else round(self.progress.best[self.track_index], 2),
                "course": self.track_index, "pick": self.pick, "y": round(car.y, 2), "air": car.air, "lift": round(car.y - self.course.ground(car.dist), 2), "cam_y": round(self.camera_y, 2),
                "slope": round(self.course.slope(car.dist), 3), "landings": car.landings, "falls": car.falls, "wrong": self.wrong >= WRONG_WAY,
                "new_best": self.new_best, "cursor": self.cursor, "rank": self.rank, "bumps": self.bumps,
                "rivals": [int(rival.run) for rival in self.rivals], "speed": round(car.speed, 1), "angle": round(car.angle, 1),
                "travel": round(car.travel, 1), "drifting": car.drifting, "slip": round(car.slip, 1),
                "side": round(car.side, 2), "dist": int(car.dist), "hits": car.hits, "grass": car.grass, "tanks": car.tanks, "gauge": round(car.gauge, 2),
                "boost": car.boost > 0, "draft": car.draft, "rev": round(self.rev, 2), "start": self.start_kind, "gear": self.tach.gear, "rpm": round(self.tach.rpm, 2), "smoke": len(self.smoke),
                "x": round(car.x, 1), "z": round(car.z, 1), "samples": len(self.recorder),
                "saved": [self.slots.data(n)["rank"] if self.slots.data(n) else None for n in range(REPLAY_SLOTS)],
                "credits": self.garage.credits, "earned": self.earned, "car": self.car_index,
                "gp": self.gp is not None, "race": self.gp.race if self.gp else None, "points": list(self.gp.totals) if self.gp else None,
                "total_rank": self.gp.place() if self.gp else None, "gp_best": self.garage.gp_best,
                "owned": [n for n, have in enumerate(self.garage.owned) if have], "shop": self.shop_cursor,
                "parts": self.garage.has("double") + self.garage.has("triple"), "kind": car.kind,
                **self.audio.state(),
                "replay_from": self.replay_back if self.scene == "replay" else None,
                "guide": self.overlays[-1].page + 1 if self.overlays and isinstance(self.overlays[-1], guide.Guide) else None,
                "replay": round(self.replay_time, 2) if self.scene == "replay" else None,
                "camera": REPLAY_CAMERAS[self.replay_camera] if self.scene == "replay" else None,
                "shot": [round(self.shot.x, 1), round(self.shot.z, 1)] if self.scene == "replay" else None}
if __name__ == "__main__":
    sys.exit(Racer().run())
