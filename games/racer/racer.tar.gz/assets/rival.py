import math
from car import EDGE_HIT, FALL_LOSS, GRAVITY, LENGTH, WIDTH
from course import wrap
BASE_SPEED = 65.0
SKILLS = (0.97, 0.94, 0.91, 0.88, 0.85)
LOOKS = (2, 1, 0, 3, 1)
COLORS = ((60, 110, 235), (245, 205, 50), (70, 190, 110), (235, 235, 240), (170, 90, 220))
ACCEL = 30.0
BRAKE = 30.0
GRIP = 40.0
class Pace:
    def __init__(self, course):
        count = course.count
        top = BASE_SPEED * course.surface.speed
        grip = course.surface.rival_grip
        limit = []
        for i in range(count):
            turn = abs(math.radians(wrap(course.points[(i + 1) % count][2] - course.points[i][2])))
            limit.append(min(top, math.sqrt(grip * course.length[i] / turn)) if turn > 1e-9 else top)
        for _ in range(2):
            for i in range(count - 1, -1, -1):
                ahead = limit[(i + 1) % count]
                limit[i] = min(limit[i], math.sqrt(ahead * ahead + 2.0 * BRAKE * course.length[i]))
        self.limit = limit
GAP = LENGTH + 0.6
def queue(rivals):
    for one in rivals:
        for other in rivals:
            if other is not one and other.side == one.side and 0.0 < other.run - one.run < GAP:
                one.back(other.speed)
                break
DRAFT_FROM, DRAFT_TO = 3.0, 25.0
DRAFT_SIDE = 1.6
DRAFT_NEAR = 30.0
APART = 3.0
def slipstream(rivals, x, z, run, y=None):
    for one in rivals:
        if 0.0 < one.run - run < DRAFT_NEAR and (y is None or abs(one.y - y) <= APART):
            a = math.radians(one.angle)
            dx, dz = x - one.x, z - one.z
            front = dx * math.sin(a) + dz * math.cos(a)
            if -DRAFT_TO <= front <= -DRAFT_FROM and abs(dx * math.cos(a) - dz * math.sin(a)) <= DRAFT_SIDE:
                return True
    return False
class Rival:
    def __init__(self, course, pace, skill, color):
        self.course, self.pace, self.skill, self.color = course, pace, skill, color
        self.place(0.0, 0.0)
    def place(self, run, side):
        self.run, self.side, self.speed = run, side, 0.0
        self.before = run
        self.x, self.z, self.angle, self.segment = self.course.place(run, side)
        self.y, self.vy, self.air = self.course.height(run), 0.0, False
        self.grade = self.course.slope(run)
    def box(self):
        return (self.x, self.z, LENGTH / 2, WIDTH / 2, self.angle)
    def step(self, dt):
        top = BASE_SPEED * self.course.surface.speed * self.skill
        target = self.pace.limit[self.segment] * self.skill
        if self.speed < target:
            self.speed = min(target, self.speed + ACCEL * max(0.0, 1.05 - self.speed / top) * dt)
        else:
            self.speed = max(target, self.speed - BRAKE * 1.5 * dt)
        self.before = self.run
        self.run += self.speed * dt
        self.x, self.z, self.angle, self.segment = self.course.place(self.run, self.side)
        course = self.course
        hole = course.hole(self.run)
        ground = course.floor if hole else course.height(self.run)
        grade, before = course.slope(self.run), self.grade
        self.grade = grade
        if self.air:
            self.y += self.vy * dt - 0.5 * GRAVITY * dt * dt
            self.vy -= GRAVITY * dt
            if not hole and self.y < ground - EDGE_HIT and course.hole(self.before):
                self.run, self.speed = self.before, 0.0
                self.x, self.z, self.angle, self.segment = course.place(self.run, self.side)
            elif self.y <= ground:
                if hole:
                    self.run -= course.cross[0] - course.cross[1]
                    self.before = self.run
                    self.speed *= FALL_LOSS
                    self.x, self.z, self.angle, self.segment = course.place(self.run, self.side)
                    self.grade = course.slope(self.run)
                self.y, self.air, self.vy = ground, False, 0.0
        elif hole:
            self.air, self.vy = True, before * self.speed
        elif course.hilly and (before - grade) * self.speed > GRAVITY * dt:
            self.air, self.vy, self.y = True, before * self.speed, ground
        else:
            self.y, self.vy = ground, grade * self.speed
    def back(self, speed):
        self.run = self.before
        self.speed = min(self.speed, speed)
        self.x, self.z, self.angle, self.segment = self.course.place(self.run, self.side)
