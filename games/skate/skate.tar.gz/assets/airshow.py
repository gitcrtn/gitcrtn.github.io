import math
from rgbkit import anim
GOLD, ORANGE, WHITE, EDGE = (255, 215, 90), (255, 150, 50), (255, 250, 240), (60, 25, 10)
SHOW_TIME = 1.5
POP_TIME = 0.25
POP = anim.Curve([(0.0, 1.35), (0.35, 0.94), (0.7, 1.03), (1.0, 1.0)])
FADE = anim.Curve([(0.0, 1.0), (0.8, 1.0), (1.0, 0.0)])
SPARKS = 18
SPARK_SPEED = 420.0
LIVE = (74, 122, 172)
BANNER = (72, 112, 162)
class AirShow:
    def __init__(self, play):
        self.play = play
        self.reset()
    def reset(self):
        self.live = None
        self.halves = 0
        self.steps = 0
        self.height_pop = self.turn_pop = POP_TIME
        self.banner = None
        self.banner_time = 0.0
        self.sparks = []
    def fly(self, height, halves):
        if self.live is None:
            self.halves, self.steps, self.banner = 0, 0, None
        if halves > self.halves:
            self.halves = halves
            self.turn_pop = 0.0
            self.play("tick")
        steps = int(height * 2.0)
        if steps > self.steps:
            self.steps = steps
            self.height_pop = 0.0
        self.live = (height, halves)
    def land(self, height, turns, points):
        self.live = None
        self.banner = (height, turns, points)
        self.banner_time = 0.0
        self.height_pop = 0.0
        self.sparks = []
        for i in range(SPARKS):
            angle = math.tau * i / SPARKS
            speed = SPARK_SPEED * (0.6 + 0.4 * ((i * 7) % 5) / 4)
            self.sparks.append([360.0, float(BANNER[2]), math.cos(angle) * speed, math.sin(angle) * speed,
                                GOLD if i % 2 else ORANGE])
        self.play("air")
    def stop(self):
        self.live = None
        self.banner = None
        self.sparks = []
    def update(self, dt):
        self.height_pop += dt
        self.turn_pop += dt
        if self.banner is not None:
            self.banner_time += dt
            if self.banner_time >= SHOW_TIME:
                self.banner = None
        for spark in self.sparks:
            spark[0] += spark[2] * dt
            spark[1] += spark[3] * dt
            spark[3] += 600.0 * dt
        if self.banner is None:
            self.sparks = []
    @property
    def showing(self):
        return self.live is not None or self.banner is not None
    def draw(self, gfx):
        if self.live is not None:
            height, halves = self.live
            _outlined(gfx, 360, LIVE[0], "AIR", 30, ORANGE)
            _outlined(gfx, 360, LIVE[1], "%.1f m" % height, round(56 * _pop(self.height_pop)), GOLD)
            if halves > 0:
                _outlined(gfx, 360, LIVE[2], "%s 回転" % _turns(halves / 2.0), round(40 * _pop(self.turn_pop)),
                          ORANGE if self.turn_pop < POP_TIME else WHITE)
        elif self.banner is not None:
            height, turns, points = self.banner
            alpha = round(255 * FADE.at(self.banner_time / SHOW_TIME))
            for x, y, _vx, _vy, color in self.sparks:
                gfx.circle(round(x), round(y), 7, color + (alpha,))
            scale = _pop(self.banner_time)
            _outlined(gfx, 360, BANNER[0], "AIR", round(30 * scale), ORANGE)
            line = "%.1f m   %s 回転" % (height, _turns(turns)) if turns > 0 else "%.1f m" % height
            _outlined(gfx, 360, BANNER[1], line, round(36 * scale), WHITE)
            _outlined(gfx, 360, BANNER[2], "+%d" % points, round(52 * scale), GOLD)
def _pop(t):
    return POP.at(min(1.0, t / POP_TIME))
def _turns(value):
    return ("%.1f" % value).rstrip("0").rstrip(".")
def _outlined(gfx, x, y, text, size, color):
    for dx, dy in ((-3, 0), (3, 0), (0, -3), (0, 3), (3, 4)):
        gfx.text(x + dx, y + dy, text, size, EDGE, align="center", valign="middle")
    gfx.text(x, y, text, size, color, align="center", valign="middle")
