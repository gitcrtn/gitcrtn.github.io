import math
from rgbkit import anim, g3drig, g3drot
from rgbkit.g3drot import angle, apply, cross, dot, mul, orthonormal, turn_about, unit
RATE = 450.0
SLACK = 45.0
SETTLE = 450.0
ACCEL = 1800.0
CRASH = 720.0
GET_UP = 0.74
LEAN_MIN = 0.2
FROM = 0.5
SPIN = 300.0
SPIN_FROM = 0.5
SPIN_ACCEL = 1200.0
GRAB_SPIN = 1.5
FOLLOW = 300.0
FOLLOW_FROM = 1.0
FACE = {"ground": 200.0, "wall": 500.0, "grind": 500.0}
JUMP_RATE = 1500.0
JUMP_MIN = 6.0
UP = (0.0, 1.0, 0.0)
FALL_ANGLE = 90.0
FALL = anim.Curve([(0.0, 0.0), (0.07, 22.0), (0.17, FALL_ANGLE), (0.215, FALL_ANGLE - 9.0), (0.26, FALL_ANGLE),
                   (0.74, FALL_ANGLE), (0.86, 50.0), (1.0, 0.0)])
SETTLE_ANGLES = tuple(range(40, 141, 5))
SETTLE_RATE = 0.25
SETTLE_MOVE = 0.05
MAX_SPEED = 9.0
PUSH = 2.5
PUSH_FAST = 1.0
PUSH_TOP = 11.0
FRICTION = 0.6
BRAKE = 8.0
TURN = 140.0
GRAVITY = 18.0
POP = 6.0
SLIDE_FRICTION = 8.0
GRIND_FRICTION = 0.5
GRIND_MIN = 2.0
BAIL_SLIDE = 12.0
BOUNCE = 0.3
SLAM_ANGLE = 45.0
SLAM_STOP = 0.3
SLAM_SPEED = 2.5
def _up_along(normal):
    up = tuple(UP[i] - normal[1] * normal[i] for i in range(3))
    length = math.sqrt(dot(up, up))
    return None if length < 1e-6 else tuple(c / length for c in up)
def normal_of(tilt):
    t = math.radians(tilt)
    return (-math.sin(t), math.cos(t), 0.0)
class Attitude:
    def __init__(self, heading=0.0, speed=0.0):
        self.trace = []
        self.reset(heading, speed)
    def reset(self, heading=0.0, speed=0.0):
        self.heading = heading % 360.0
        self.speed = speed
        self.surf_v = (0.0, 0.0, 0.0)
        self.R = g3drot.yaw(heading)
        self.normal = UP
        self.air = False
        self.axis = self.chest()
        self.pitch = 0.0
        self.way = 0
        self.allow = 0
        self.strength = 0.0
        self.spin_rate = self.rate_max = self.rate_release = self.air_time = 0.0
        self.lean = 0.0
        self.held = False
        self.rolling = False
        self.upright = False
        self.by_stick = 0.0
        self.by_inertia = 0.0
        self.landed_pitch = 0.0
        self.stance = 0.0
        self.unwind = None
        self.spun = 0.0
        self.spin_vel = 0.0
        self.lip = False
        self.follow_travel = None
        self.follow_debt = 0.0
        self.last_yaw = 0.0
        self.falling = None
        self.last_toward = 0.0
        self.last_chest = 0.0
        self.last_lie = 0.0
        self.settles = 0
        self.rebased = False
        self.start_R = self.R
        self.moves = []
    @property
    def base(self):
        return None if self.falling is None else self.falling.base
    @property
    def tumbling(self):
        return self.falling is not None and self.falling.tumbling
    @property
    def lie(self):
        return self.last_lie if self.falling is None else self.falling.lie
    @property
    def lying(self):
        return 0.0 if self.falling is None else self.falling.lying
    @property
    def fall(self):
        return 0.0 if self.falling is None else self.falling.fall
    @property
    def fall_toward(self):
        return self.last_toward if self.falling is None else self.falling.toward
    def chest(self):
        return apply(self.R, (1.0, 0.0, 0.0))
    def up(self):
        return apply(self.R, (0.0, 1.0, 0.0))
    def forward(self):
        return apply(self.R, (0.0, 0.0, 1.0))
    @property
    def flipping(self):
        return self.air and abs(self.pitch) > 0.5
    @property
    def tilt(self):
        tilt = angle(self.normal, UP)
        return -tilt if self.normal[0] + self.normal[2] > 0 else tilt
    def phase(self, normal=None):
        found = turn_about(self.axis, self.normal if normal is None else normal, self.up())
        return 0.0 if found is None else found
    def yaw(self, travel):
        forward = self.forward()
        if self.air:
            forward = apply(g3drot.about(self.axis, -self.phase()), forward)
        found = None if travel is None else turn_about(self.normal, travel, forward)
        if found is not None:
            self.last_yaw = found
        return self.last_yaw
    def unflipped(self):
        if self.base is not None:
            return self.R
        return mul(g3drot.about(self.axis, -self.phase()), self.R)
    def unbent(self):
        return self.base if self.base is not None else self.R
    def standing(self):
        return self.base if self.base is not None else self.unflipped()
    def facing(self, travel):
        return self.stance + anim.wrap(self.yaw(travel) - self.stance)
    def backward(self, travel):
        return math.cos(math.radians(self.yaw(travel))) < 0
    def sliding(self, travel):
        return abs(math.sin(math.radians(self.yaw(travel) - self.stance)))
    def align(self, travel, step):
        self.stance = round(self.yaw(travel) / step) * step % 360.0
    def rotate(self, axis, degrees, why):
        axis = None if axis is None else unit(axis)
        if axis is None or not degrees:
            return
        self.R = orthonormal(mul(g3drot.about(axis, degrees), self.R))
        self.moves.append((why, degrees))
    def begin_frame(self):
        self.start_R = self.R
        self.moves = []
        self.rebased = False
    def frame_turn(self):
        amount = g3drot.between(self.start_R, self.R)
        if amount < 1e-6:
            return 0.0, None
        d = mul(self.R, tuple(tuple(self.start_R[j][i] for j in range(3)) for i in range(3)))
        return amount, unit((d[2][1] - d[1][2], d[0][2] - d[2][0], d[1][0] - d[0][1]))
    def frame_jump(self, dt):
        amount = g3drot.between(self.start_R, self.R)
        if amount > JUMP_MIN and amount > JUMP_RATE * max(dt, 1 / 60):
            return amount, list(self.moves)
        return None
    def take_off(self, travel, stick=0.0, lip=False):
        self.air = True
        travel = unit(travel)
        self.axis, way, self.strength, lean = g3drot.launch(self.R, travel or (0.0, 0.0, 0.0), lean_min=LEAN_MIN)
        self.lean = lean
        self.allow = 0 if lip else way
        self.lip = lip
        self.spin_vel = 0.0
        self.follow_travel, self.follow_debt = travel, 0.0
        self.pitch = self.phase()
        self.way = 0
        self.held = abs(stick) > FROM
        self.rolling = False
        self.by_stick = self.by_inertia = 0.0
        self.spin_rate = 0.0
        self.rate_max = self.rate_release = 0.0
        self.air_time = 0.0
        self.spun = 0.0
        self.trace = ["takeoff=%s lean=%d allow=%s axis=(%.2f,%.2f,%.2f)" % (
            "lip" if lip else "ground", round(lean), {1: "front", -1: "back", 0: "none"}[self.allow], *self.axis)]
    def turn_flip(self, step, why):
        self.rotate(self.axis, step, why)
        self.pitch += step
    def fly(self, dt, stick):
        if self.held:
            if abs(stick) <= FROM:
                self.held = False
            stick = 0.0
        want = 0 if abs(stick) <= FROM else (-1 if stick > 0 else 1)
        amount = max(0.0, abs(stick) - FROM) / (1.0 - FROM)
        was_rolling = self.rolling
        self.rolling = bool(want) and want == self.allow
        self.air_time += dt
        if self.rolling:
            target = amount * self.strength * RATE
            self.spin_rate = anim.approach(self.spin_rate, max(self.spin_rate, target), ACCEL * dt)
            self.rate_max = max(self.rate_max, self.spin_rate)
            step = want * self.spin_rate * dt
            self.turn_flip(step, "flip")
            self.by_stick += step
            self.way = want
        else:
            if was_rolling:
                self.rate_release = self.spin_rate
            if self.committed():
                step = anim.approach(self.pitch, self.whole(), self.spin_rate * dt) - self.pitch
                self.turn_flip(step, "inertia")
                self.by_inertia += step
                if self.pitch == self.whole():
                    self.spin_rate = 0.0
            else:
                self.spin_rate = 0.0
    def spin(self, dt, steer, travel, grab=False):
        turn = max(0.0, abs(steer) - SPIN_FROM) / (1.0 - SPIN_FROM) * (1 if steer > 0 else -1)
        if turn:
            self.unwind = None
            boost = GRAB_SPIN if grab else 1.0
            target = turn * SPIN * boost
            if target * self.spin_vel >= 0 and abs(target) <= abs(self.spin_vel):
                pass
            else:
                self.spin_vel = anim.approach(self.spin_vel, target, SPIN_ACCEL * boost * dt)
        if self.unwind is None:
            step = self.spin_vel * dt
        else:
            step = max(-SPIN * dt, min(SPIN * dt, anim.wrap(self.unwind - self.yaw(travel))))
        self.rotate(self.up(), step, "spin")
        self.spun += step
    def follow(self, dt, travel, along):
        if not self.lip:
            return
        before, self.follow_travel = self.follow_travel, travel
        if before is not None and abs(along) >= FOLLOW_FROM:
            self.follow_debt += turn_about(self.normal, before, travel) or 0.0
        step = max(-FOLLOW * dt, min(FOLLOW * dt, self.follow_debt))
        self.follow_debt -= step
        self.rotate(self.normal, step, "follow")
        self.spun += step
    def expect(self, normal):
        if angle(normal, self.normal) < 1e-6:
            return
        before = self.phase()
        self.normal = normal
        self.pitch += anim.wrap(self.phase() - before)
        self.rebased = True
        self.trace.append("expect=(%.2f,%.2f,%.2f) rel=%d" % (*normal, round(self.pitch)))
    def committed(self):
        return self.way != 0 and SLACK < self.past() < 360.0 - 1e-6
    def past(self):
        if self.way > 0:
            return self.pitch - math.floor(self.pitch / 360.0) * 360.0
        if self.way < 0:
            return math.ceil(self.pitch / 360.0) * 360.0 - self.pitch
        return 0.0
    def whole(self):
        if self.way > 0:
            return math.ceil(self.pitch / 360.0) * 360.0
        if self.way < 0:
            return math.floor(self.pitch / 360.0) * 360.0
        return round(self.pitch / 360.0) * 360.0
    def touch(self, normal):
        self.upright = angle(normal, self.normal) > 1.0 and angle(normal, UP) > 1.0 and angle(self.up(), UP) <= SLACK
        self.spin_vel, self.lip, self.follow_debt = 0.0, False, 0.0
        self.expect(normal)
        self.air = False
        self.trace.append("surface=%d rel=%d" % (round(self.tilt), round(self.pitch)))
    def fault(self):
        if angle(self.up(), self.normal) <= SLACK or self.upright:
            return None
        return "flip angle=%d" % round(self.pitch)
    def landed(self):
        turns = round(self.pitch / 360.0)
        self.landed_pitch = self.pitch
        self.pitch = anim.wrap(self.pitch)
        self.way, self.rolling, self.upright = 0, False, False
        return int(turns)
    def carry(self, normal):
        if angle(normal, self.normal) > 1e-6:
            axis = unit(cross(self.normal, normal))
            if axis is None:
                self.normal = normal
                return
            amount = angle(self.normal, normal)
            turn = g3drot.about(axis, amount)
            self.rotate(axis, amount, "carry")
            if self.base is not None:
                self.falling.base = orthonormal(mul(turn, self.base))
            self.axis = apply(turn, self.axis)
            if self.follow_travel is not None:
                self.follow_travel = apply(turn, self.follow_travel)
            self.normal = normal
    def on_surface(self, dt, normal, travel, kind, steered=0.0):
        self.air = False
        self.spin_vel, self.lip, self.follow_debt = 0.0, False, 0.0
        self.carry(normal)
        if kind == "bail":
            return
        up = self.up()
        off = angle(up, normal)
        if off > 1e-9:
            self.rotate(unit(cross(up, normal)) or self.axis, min(off, SETTLE * dt), "settle")
        self.pitch = self.phase()
        if steered:
            self.rotate(normal, steered, "steer")
        if travel is None:
            return
        yaw = self.yaw(travel)
        if kind == "wall":
            self.stance = 0.0 if abs(anim.wrap(yaw)) <= 90.0 else 180.0
        step = anim.wrap(self.stance - yaw)
        rate = FACE[kind] * dt
        self.rotate(normal, max(-rate, min(rate, step)), "face")
    def crash(self, travel=None):
        self.rolling = False
        if travel is not None:
            self.stance = 0.0 if abs(anim.wrap(self.yaw(travel))) <= 90.0 else 180.0
        if self.falling is None:
            self.falling = g3drig.Fall(self.R, up=self.normal, flip=(self.axis, self.way, self.pitch), curve=FALL,
                                       angle=FALL_ANGLE, rate=CRASH, get_up=GET_UP, slack=SLACK, angles=SETTLE_ANGLES,
                                       settle_rate=SETTLE_RATE, settle_move=SETTLE_MOVE)
            self.falling.toward, self.falling.chest_turn = self.last_toward, self.last_chest
        else:
            self.falling.up = self.normal
            self.falling.pitch = self.pitch
        self.falling.again(travel)
        self.R = self.falling.m
        self.trace.append("crash=%s" % ("tumble lie=%d" % round(self.lie) if self.tumbling else "fall"))
    def crash_step(self, dt, part, after=None):
        before, pitch = self.R, self.falling.pitch
        self.falling.up = self.normal
        self.R = self.falling.step(dt, part, after)
        if self.tumbling:
            if self.falling.pitch != pitch:
                self.moves.append(("tumble", self.falling.pitch - pitch))
        else:
            self.moves.append(("fall", g3drot.between(before, self.R)))
        self.pitch = self.falling.pitch
    def rest_on(self, shape, feet, surfaces, thick, clear, depth=None, contact=None, height=0.0):
        if self.falling is None:
            return
        count = self.falling.settles
        self.falling.rest_on(shape, feet, surfaces, thick, clear, depth=depth, contact=contact, height=height)
        self.settles += self.falling.settles - count
        self.R = self.falling.m
    def rest_lift(self):
        return 0.0 if self.falling is None else self.falling.lift()
    def stand(self):
        if self.falling is not None:
            self.last_toward, self.last_chest, self.last_lie = self.falling.toward, self.falling.chest_turn, self.falling.lie
            self.R = self.falling.stand()
            self.falling = None
        self.pitch, self.way = self.phase(), 0
    def ground_travel(self):
        way = math.radians(self.heading)
        return (math.sin(way), 0.0, math.cos(way))
    def velocity(self, vy=0.0):
        way = math.radians(self.heading)
        return (math.sin(way) * self.speed, vy, math.cos(way) * self.speed)
    def push(self, top=PUSH_TOP):
        if self.speed < MAX_SPEED:
            self.speed = min(MAX_SPEED, self.speed + PUSH)
        elif top > MAX_SPEED:
            self.speed += PUSH_FAST * max(0.0, (top - self.speed) / (top - MAX_SPEED))
    def steer(self, dt, amount):
        turn = amount * TURN * dt
        self.heading = (self.heading + turn) % 360.0
        return turn
    def roll(self, dt, brake):
        sliding = self.sliding(self.ground_travel())
        drag = (BRAKE if brake else FRICTION) + SLIDE_FRICTION * sliding
        self.speed = anim.approach(self.speed, 0.0, drag * dt)
        return sliding
    def grinding(self, dt):
        self.speed = max(GRIND_MIN, anim.approach(self.speed, 0.0, GRIND_FRICTION * dt))
    def sliding_down(self, dt):
        self.speed = anim.approach(self.speed, 0.0, BAIL_SLIDE * dt)
    def stop(self):
        self.speed = 0.0
        forward = self.forward()
        if abs(forward[0]) + abs(forward[2]) > 1e-6:
            self.heading = math.degrees(math.atan2(forward[0], forward[2])) % 360.0
            self.stance = 0.0
    def enter_grind(self, axis):
        ways = (90.0, 270.0) if axis == "x" else (0.0, 180.0)
        self.heading = max(ways, key=lambda way: math.cos(math.radians(self.heading - way)))
        self.speed = max(self.speed, GRIND_MIN)
    def glided(self, heading, speed):
        if speed > 0.0:
            self.heading = heading % 360.0
        self.speed = speed
    def collide(self, was, before, grinding, bailing):
        turned = abs(anim.wrap(self.heading - was))
        if not bailing and (grinding or before >= SLAM_SPEED) and (turned > SLAM_ANGLE or self.speed < before * SLAM_STOP):
            return "hit%s speed=%.1f->%.1f turned=%d" % (" grind" if grinding else "", before, self.speed, round(turned))
        return None
    def climb(self, normal):
        up = _up_along(normal)
        return 0.0 if up is None else dot(self.surf_v, up)
    def enter_wall(self, normal, vy):
        v = self.velocity(vy)
        into = dot(v, normal)
        self.surf_v = tuple(v[i] - into * normal[i] for i in range(3))
    def wall_force(self, part, normal, falling):
        g = (0.0, -GRAVITY, 0.0)
        along = dot(g, normal)
        v = tuple(self.surf_v[i] + (g[i] - along * normal[i]) * part for i in range(3))
        if falling:
            up = _up_along(normal)
            if up is not None:
                rise = dot(v, up)
                if rise > 0:
                    v = tuple(v[i] - rise * up[i] for i in range(3))
                rise = min(0.0, rise)
                side = tuple(v[i] - rise * up[i] for i in range(3))
                length = math.sqrt(dot(side, side))
                keep = max(0.0, length - BAIL_SLIDE * part) / length if length > 1e-9 else 0.0
                v = tuple(rise * up[i] + side[i] * keep for i in range(3))
        else:
            speed = math.sqrt(dot(v, v))
            if speed > 0:
                keep = max(0.0, speed - FRICTION * part) / speed
                v = tuple(c * keep for c in v)
        self.surf_v = v
    def constrain(self, normal):
        v = self.surf_v
        speed = math.sqrt(dot(v, v))
        into = dot(v, normal)
        v = tuple(v[i] - into * normal[i] for i in range(3))
        length = math.sqrt(dot(v, v))
        self.surf_v = tuple(c * speed / length for c in v) if length > 1e-9 else v
    def constrain_lip(self, out):
        vx, vy, vz = self.surf_v
        speed = math.hypot(vx, vz)
        into = vx * out[0] + vz * out[1]
        vx, vz = vx - into * out[0], vz - into * out[1]
        length = math.hypot(vx, vz)
        if length > 1e-9:
            vx, vz = vx * speed / length, vz * speed / length
        self.surf_v = (vx, vy, vz)
    def wall_pop(self, normal):
        up = _up_along(normal) or UP
        self.surf_v = tuple(self.surf_v[i] + POP * up[i] for i in range(3))
    def jump_off(self, normal):
        self.surf_v = tuple(self.surf_v[i] + POP * normal[i] for i in range(3))
        return self.surf_v
    def lip_force(self, part):
        vx, vy, vz = self.surf_v
        self.surf_v = (vx, vy - GRAVITY * part, vz)
    def unfold(self, normal, out, lat, air):
        v = self.surf_v
        up = v[1] if air else self.climb(normal)
        side = dot(v, lat)
        self.speed = math.hypot(up, side)
        if self.speed >= 1e-3:
            dx, dz = out[0] * up + lat[0] * side, out[1] * up + lat[2] * side
            if math.hypot(dx, dz) > 1e-6:
                self.heading = math.degrees(math.atan2(dx, dz)) % 360.0
    def to_floor(self):
        vx, vy, vz = self.surf_v
        self.speed = math.sqrt(vx * vx + vy * vy + vz * vz)
        if math.hypot(vx, vz) > 1e-6:
            self.heading = math.degrees(math.atan2(vx, vz)) % 360.0
    def leave_wall(self, world):
        vx, vy, vz = world
        self.speed = math.hypot(vx, vz)
        if self.speed > 1e-3:
            self.heading = math.degrees(math.atan2(vx, vz)) % 360.0
        return vy
    def summary(self, result):
        return "motion: %s stick=%d inertia=%d rate_max=%d rate_release=%d air=%.2f %s" % (
            " ".join(self.trace), round(self.by_stick), round(self.by_inertia), round(self.rate_max), round(self.rate_release),
            self.air_time, result)
