import math
from rgbkit import anim, g3drig, g3drot
import attitude
SKIN, SHIRT, PANTS, SHOE, CAP = (235, 190, 150), (240, 130, 40), (50, 60, 110), (245, 245, 240), (40, 40, 50)
LEG = 0.37
ANKLE = 0.08
TORSO = 0.50
HEAD = 0.24
ARM = 0.46
STANCE = 0.20
GROUND = -0.11
BLEND = 10.0
PUSH_TIME = 0.5
GET_UP = 0.74
LAND_TIME = 0.3
STAND = dict(hip=0.79, shift=0.0, lean=(0.02, 0.0), front=(0.06, 0.74, 0.30), back=(0.06, 0.74, -0.30))
RIDE = dict(hip=0.71, shift=0.0, lean=(0.08, 0.03), front=(0.14, 0.86, 0.44), back=(0.10, 0.82, -0.42))
BRAKE = dict(hip=0.63, shift=-0.12, lean=(0.06, -0.20), front=(0.20, 1.10, 0.52), back=(0.16, 0.98, -0.62))
CROUCH = dict(hip=0.52, shift=0.0, lean=(0.17, 0.0), front=(0.24, 0.62, 0.38), back=(0.22, 0.60, -0.38))
GRIND = dict(hip=0.62, shift=0.0, lean=(0.10, 0.0), front=(0.10, 1.02, 0.66), back=(0.10, 1.02, -0.66))
AIR = dict(hip=0.60, shift=0.0, lean=(0.12, 0.0), front=(0.16, 1.16, 0.50), back=(0.12, 1.12, -0.50))
PUSHING = dict(hip=0.66, shift=0.06, lean=(0.12, 0.16), front=(0.10, 0.80, 0.20), back=(0.14, 0.84, -0.30))
TUCK = dict(hip=0.52, shift=0.0, lean=(0.18, 0.0), front=(0.30, 0.58, 0.12), back=(0.30, 0.55, -0.12), lift=0.18)
GRAB = dict(hip=0.55, shift=0.0, lean=(0.65, 0.0), front=(0.12, 0.47, 0.08), back=(-0.10, 1.75, -0.45), lift=0.45)
TRICK = dict(hip=0.84, shift=0.0, lean=(0.14, 0.0), front=(0.20, 1.22, 0.56), back=(0.16, 1.18, -0.56), lift=0.30)
BAIL = dict(hip=ANKLE + LEG * 2 - 0.005, shift=0.0, lean=(0.0, 0.0), front=(-0.03, 1.95, 0.34), back=(-0.05, 1.42, -0.80))
POSES = (STAND, RIDE, BRAKE, CROUCH, GRIND, AIR, PUSHING, TRICK, BAIL, TUCK, GRAB)
for _pose in POSES:
    _pose.setdefault("lift", 0.0)
THICK = 0.13
CLEAR = 0.10
HAND_REACH = 0.3
LOW = 0.02
PUSH_FOOT = anim.Curve([(0.0, (0.0, ANKLE, -STANCE)), (0.2, (0.24, GROUND + ANKLE, 0.10)),
                        (0.65, (0.24, GROUND + ANKLE, -0.58)), (0.82, (0.20, 0.22, -0.50)), (1.0, (0.0, ANKLE, -STANCE))])
PUSH_SWING = anim.Curve([(0.0, 0.0), (0.2, -0.25), (0.65, 0.30), (1.0, 0.0)])
PUSH_WEIGHT = anim.Curve([(0.0, 0.0), (0.2, 1.0), (0.7, 1.0), (1.0, 0.0)])
LAND_WEIGHT = anim.Curve([(0.0, 0.0), (0.25, 0.8), (1.0, 0.0)])
BONES = [("hip", "neck", 0.24, 0.42, SHIRT), ("neck", "head", 0.22, 0.22, SKIN), ("head", "cap", 0.24, 0.26, CAP)]
for _side in ("front", "back"):
    BONES += [(_side + "_hip", _side + "_knee", 0.16, 0.16, PANTS), (_side + "_knee", _side + "_ankle", 0.14, 0.14, PANTS),
              (_side + "_ankle", _side + "_sole", 0.14, 0.26, SHOE), (_side + "_shoulder", _side + "_hand", 0.11, 0.11, SHIRT)]
class Figure:
    def __init__(self, view, cube):
        self.rig = g3drig.Rig(view, cube, BONES) if view is not None else None
        self.reset()
    def reset(self):
        self.drop = 0.0
        self.bail_part = None
        self.gap = None
        self.board_up = 0.0
        self.nudge = (0.0, 0.0, 0.0)
        self.last = None
        self.frame = None
        self.shifts = []
        self.pose = dict(STAND)
        self.pushing = g3drig.Layer(PUSH_TIME, weight=PUSH_WEIGHT)
        self.landing = g3drig.Layer(LAND_TIME, weight=LAND_WEIGHT)
        self.backward = False
        self.state = "stand"
        self.grab_backward = False
    def push(self):
        self.pushing.start()
    def land(self):
        self.landing.start()
    def update(self, dt, speed, grounded, brake, crouch=False, trick=False, bail=None, backward=False, grind=False, wall=False,
               flip=False, tumble=False, grab=False):
        self.backward = backward and bail is None
        self.landing.update(dt)
        if not grounded:
            self.landing.stop()
        self.bail_part = bail
        self.tumble = tumble and bail is not None
        if bail is not None and tumble:
            self.state, target = "bail", TUCK
            self.pushing.stop()
            self.landing.stop()
        elif bail is not None:
            self.state, target = "bail", BAIL
            self.pushing.stop()
            self.landing.stop()
        elif not grounded and trick:
            self.state, target = "trick", TRICK
            self.pushing.stop()
        elif not grounded and grab:
            if self.state != "grab":
                self.grab_backward = self.backward
            self.backward = self.grab_backward
            self.state, target = "grab", GRAB
            self.pushing.stop()
        elif not grounded:
            self.state, target = ("flip" if flip else "air"), AIR
            self.pushing.stop()
        elif crouch:
            self.state, target = "crouch", CROUCH
            self.pushing.stop()
        elif grind:
            self.state, target = "grind", GRIND
            self.pushing.stop()
        elif wall:
            self.state, target = "wall", RIDE
            self.pushing.stop()
        elif brake and speed > 0.3:
            self.state, target = "brake", BRAKE
            self.pushing.stop()
        elif speed > 0.5:
            self.state, target = "ride", RIDE
        else:
            self.state, target = "stand", STAND
        self.pushing.update(dt)
        if self.pushing.active:
            self.state = "push"
        rate = min(1.0, (BLEND * 2 if self.state in ("air", "flip", "crouch", "trick", "bail", "grab") else BLEND) * dt)
        self.board_up = anim.follow(self.board_up, GRAB["lift"] if self.state == "grab" else 0.0, BLEND * 2, dt)
        self.pose = g3drig.mix(self.pose, target, rate)
    def joints(self):
        pose = self.pose
        foot = (0.0, ANKLE + pose["lift"], -STANCE)
        if self.landing.active:
            pose = g3drig.mix(pose, CROUCH, self.landing.weight)
        if self.pushing.active:
            t = self.pushing.t
            pose = g3drig.mix(pose, PUSHING, self.pushing.weight)
            swing = PUSH_SWING.at(t)
            pose["front"] = (pose["front"][0], pose["front"][1], pose["front"][2] + swing)
            pose["back"] = (pose["back"][0], pose["back"][1], pose["back"][2] - swing)
            foot = PUSH_FOOT.at(t)
        hip = (0.0, pose["hip"], pose["shift"])
        lean = g3drot.unit((pose["lean"][0], TORSO, pose["lean"][1]))
        neck = tuple(hip[i] + lean[i] * TORSO for i in range(3))
        points = {"hip": hip, "neck": neck, "head": tuple(neck[i] + lean[i] * HEAD for i in range(3)),
                  "cap": tuple(neck[i] + lean[i] * (HEAD + 0.07) for i in range(3))}
        for side, sign, ankle, hand in (("front", 1, (0.0, ANKLE + pose["lift"], STANCE), pose["front"]), ("back", -1, foot, pose["back"])):
            joint = (hip[0], hip[1], hip[2] + sign * 0.11)
            shoulder = (neck[0], neck[1] - 0.06, neck[2] + sign * 0.25)
            reach = g3drot.unit((hand[0] - shoulder[0], hand[1] - shoulder[1], hand[2] - shoulder[2])) or (0.0, -1.0, 0.0)
            points[side + "_hip"] = joint
            points[side + "_ankle"] = ankle
            points[side + "_sole"] = (ankle[0] + 0.02, ankle[1] - ANKLE, ankle[2])
            points[side + "_knee"] = g3drig.bend(joint, ankle, LEG, toward=(1.0, 0.0, 0.0))
            points[side + "_shoulder"] = shoulder
            points[side + "_hand"] = tuple(shoulder[i] + reach[i] * ARM for i in range(3))
        if self.backward:
            points = g3drig.mirror(points, "z")
        return points
    def settle_shape(self):
        joints = self.joints()
        local = [p for name, p in joints.items() if not name.endswith("_hand")]
        local.append(tuple((a + b) / 2 for a, b in zip(joints["hip"], joints["neck"])))
        return local
    def place(self, pos, rot, roll=0.0, ground=None, normal=attitude.UP, stand=None, upright=None, rebased=False,
              tumble=False, solid=None, base=None, height=0.0, lying=0.0, fall=0.0, lift=0.0, unbent=None):
        if tumble:
            lying = fall = lift = 0.0
        rest = math.sin(math.radians(fall)) * THICK + lift
        joints = self.joints()
        stand = rot if stand is None else stand
        upright = stand if upright is None else upright
        bend = g3drot.about((0.0, 0.0, 1.0), roll)
        lifted = g3drot.apply(upright, (0.0, rest + height, 0.0))
        hip_local = g3drot.apply(bend, joints["hip"])
        center = tuple(pos[i] + lifted[i] + v for i, v in enumerate(g3drot.apply(stand, hip_local)))
        unbent = rot if unbent is None else unbent
        hip_unbent = g3drot.back(unbent, g3drot.apply(rot, hip_local))
        slid = (0.0, 0.0, 0.0) if base is None else tuple(a - b for a, b in zip(pos, base))
        self.frame = (tuple(c - d for c, d in zip(center, slid)), unbent, (hip_unbent[0], hip_unbent[1] + rest + height, hip_unbent[2]))
        self.shifts = []
        points = {}
        for name, p in joints.items():
            x, y, z = (center[i] + v for i, v in enumerate(g3drot.apply(rot, tuple(a - b for a, b in zip(g3drot.apply(bend, p), hip_local)))))
            if lying > 0 and ground is not None and name.endswith("_hand"):
                top = ground(x, z)
                if top - y < HAND_REACH:
                    y = max(y, top + CLEAR * lying)
            points[name] = (x, y, z)
        whole = g3drot.mul(rot, bend)
        chest, ahead = g3drot.apply(whole, (1.0, 0.0, 0.0)), g3drot.apply(whole, (0.0, 0.0, 1.0))
        target = 0.0
        lying_flip = tumble and (self.bail_part is None or self.bail_part < GET_UP)
        if lying_flip and solid is not None and getattr(self, "gap", None) is not None:
            target = max(0.0, self.drop + self.gap)
        self.drop = anim.follow(getattr(self, "drop", 0.0), target, 12.0, 1 / 60)
        if self.drop > 1e-4:
            self.shift(points, tuple(-v * self.drop for v in normal))
        hip = points["hip"]
        if self.last is not None and rebased:
            self.nudge = tuple(self.last[i] - hip[i] for i in range(3))
        else:
            self.nudge = tuple(anim.follow(v, 0.0, 10.0, 1 / 60) for v in self.nudge)
        if any(abs(v) > 1e-4 for v in self.nudge):
            self.shift(points, self.nudge)
        self.contact = None
        self.gap = None
        if solid is not None:
            base = pos if base is None else base
            name, (depth, out) = max(((name, solid(*p, base)) for name, p in points.items() if not name.endswith("_hand")),
                                     key=lambda item: item[1][0])
            self.contact = (name, depth, max(0.0, depth))
            self.gap = -depth
            if depth > 0.0:
                self.shift(points, tuple(v * depth for v in out))
            for key in [key for key in points if key.endswith("_hand")]:
                hand_depth, hand_out = solid(*points[key], base)
                if hand_depth > 0.0:
                    points[key] = tuple(points[key][i] + hand_out[i] * hand_depth for i in range(3))
                if hand_depth > self.contact[1]:
                    self.contact = (key, hand_depth, max(self.contact[2], hand_depth))
        self.last = points["hip"]
        return points, chest, ahead
    def shift(self, points, by):
        self.shifts.append(by)
        for name, p in points.items():
            points[name] = (p[0] + by[0], p[1] + by[1], p[2] + by[2])
    def to_world(self, local):
        center, rot, hip_local = self.frame
        p = g3drot.apply(rot, (local[0] - hip_local[0], local[1] - hip_local[1], local[2] - hip_local[2]))
        p = tuple(center[i] + p[i] for i in range(3))
        for by in self.shifts:
            p = (p[0] + by[0], p[1] + by[1], p[2] + by[2])
        return p
