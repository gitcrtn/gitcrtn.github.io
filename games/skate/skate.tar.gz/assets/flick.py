import math
FAR = 0.6
WINDOW = 0.2
SET = "set"
ZONES = {"up": (337.5, 22.5), "upright": (22.5, 67.5), "right": (67.5, 112.5), "left": (247.5, 292.5),
         "upleft": (292.5, 337.5)}
def zone(x, y):
    if math.hypot(x, y) < FAR:
        return None
    angle = math.degrees(math.atan2(x, -y)) % 360.0
    if 135.0 <= angle <= 225.0:
        return SET
    for name, (start, end) in ZONES.items():
        if (start <= angle < end) if start < end else (angle >= start or angle < end):
            return name
    return None
class Flick:
    def __init__(self):
        self.counts = {"set": 0, "late": 0}
        self.took_total = self.took_max = 0.0
        self.reset()
    def reset(self):
        self.crouch = False
        self._since = None
    def summary(self):
        hits = sum(count for name, count in self.counts.items() if name not in ("set", "late"))
        return "flick: %s average=%.0fms max=%.0fms" % (
            " ".join("%s=%d" % item for item in sorted(self.counts.items())),
            self.took_total / hits * 1000 if hits else 0, self.took_max * 1000)
    def update(self, x, y, dt, ready):
        if not ready:
            self.reset()
            return None
        now = zone(x, y)
        if now == SET:
            if not self.crouch:
                self.counts["set"] += 1
            self.crouch, self._since = True, None
            return None
        if self.crouch:
            self.crouch, self._since = False, 0.0
        elif self._since is not None:
            self._since += dt
            if self._since > WINDOW:
                self._since = None
                self.counts["late"] += 1
        if self._since is not None and now is not None:
            self.counts[now] = self.counts.get(now, 0) + 1
            self.took_total += self._since
            self.took_max = max(self.took_max, self._since)
            self._since = None
            return now
        return None
