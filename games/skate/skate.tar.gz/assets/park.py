from rgbkit import g3d, g3dbody
from pipe import Bowl, Pipe, Quarter
LEFT, RIGHT, FRONT, BACK = -20.0, 20.0, -60.0, 60.0
GROUND = 64.0
CURB = 0.3
FENCE_HEIGHT = 1000.0
THICK = 0.4
SKY = (150, 195, 235)
CONCRETE = (190, 186, 178)
RED = (205, 95, 70)
FENCE = (95, 100, 112)
OBJECTS = [
    ("box1", (0.0, -4.0), (6.0, 0.4, 3.0), CONCRETE),
    ("box2", (-10.0, 6.0), (3.0, 0.4, 6.0), CONCRETE),
    ("steps", (11.0, 11.0), (10.0, 0.4, 10.0), CONCRETE),
    ("steps2", (13.0, 13.0), (6.0, 0.8, 6.0), (170, 166, 160)),
    ("curb1", (8.0, -8.0), (6.0, 0.3, 0.6), RED),
    ("curb2", (-8.0, -10.0), (0.6, 0.3, 6.0), RED),
    ("gapa", (-3.0, 24.0), (6.0, 0.4, 4.0), CONCRETE),
    ("gapb", (-3.0, 32.0), (6.0, 0.4, 4.0), CONCRETE),
]
LEAPS = [
    ("GAP", "gapa", "gapb"),
    ("GAP", "gapb", "gapa"),
]
RAILS = [
    ("rail1", (2.0, 3.0), 8.0, 0.45, "x"),
    ("rail2", (-4.0, 14.0), 6.0, 0.40, "x"),
    ("rail3", (-15.0, -3.0), 7.0, 0.60, "z"),
]
RAIL_WIDTH = 0.12
RAIL_COLOR = (235, 200, 60)
PIPE = Pipe(-7.5, 7.5, -56.0, -26.0, flat=10.0, radius=2.0)
BOWL = Bowl(10.2, 17.8, -48.0, -36.0, radius=2.0, channel=(13.2, 14.8, 3.0, 10.0))
QP = Quarter(-19.0, 17.0, 55.5, radius=3.5, back=1.0)
PIPE.name, BOWL.name, QP.name = "pipe", "bowl", "qp"
CURVES = (PIPE, BOWL, QP)
RAIL_PAD = 0.25
SPOTS = {
    "start": (0.0, -15.0, 0.0),
    "box1": (0.0, -10.0, 0.0),
    "box2": (-10.0, -2.0, 0.0),
    "steps": (11.0, 1.0, 0.0),
    "curb1": (2.0, -8.0, 90.0),
    "wall": (-14.0, 27.0, 270.0),
    "open": (-18.0, -17.0, 90.0),
    "ledge": (-2.9, -10.0, 0.0),
    "rail1": (-7.0, 3.0, 90.0),
    "rail2": (-12.0, 14.0, 90.0),
    "rail3": (-15.0, -12.0, 0.0),
    "gap": (-3.0, 16.0, 0.0),
    "qp": (-11.0, QP.foot - 8.0, 0.0),
    "qpwall": (-11.0, QP.foot - 1.0, 0.0),
    "qpside": (QP.x1 + 2.5, QP.foot + 2.5, 270.0),
    "pipe": (PIPE.mid, PIPE.z1 + 4.0, 180.0),
    "pipewall": (PIPE.edge(-1) + 1.0, (PIPE.z0 + PIPE.z1) / 2, 270.0),
    "pipeback": (PIPE.x0 - 3.0, (PIPE.z0 + PIPE.z1) / 2, 90.0),
    "bowl": ((BOWL.bx0 + BOWL.bx1) / 2, BOWL.zend + 4.0, 180.0),
    "bowldrop": ((BOWL.bx0 + BOWL.bx1) / 2, BOWL.bz0 - BOWL.radius - 4.0, 0.0),
    "bowlin": ((BOWL.bx0 + BOWL.bx1) / 2, (BOWL.bz0 + BOWL.bz1) / 2, 90.0),
}
TILE = ["bbbbbbbbbbbbbbbb"] + ["baaaaaaaaaaaaaaa"] * 15
TILE_COLORS = {"a": (158, 160, 166), "b": (128, 130, 138)}
def floor_at(x, z):
    return BOWL.floor if BOWL.over(x, z) else 0.0
def height(x, z):
    if BOWL.over(x, z):
        return BOWL.height(x, z)
    found = g3dbody.top(surfaces(), x, z)
    if PIPE.inside(x, z):
        found = max(found, PIPE.height(x, z))
    elif QP.over(x, z):
        found = max(found, QP.height(x, z) or 0.0)
    return found
def depth(x, y, z, side=None):
    best = PIPE.depth(x, y, z) if PIPE.inside(x, z, 1.0) else (BOWL.bowl_depth(x, y, z)
                                                              or (QP.near(x, z, 1.0) and QP.bowl_depth(x, y, z)) or (-y, (0.0, 1.0, 0.0)))
    found = g3dbody.depth(solids(), x, y, z, side=side, floor=None)
    if found[1] is not None and found[0] > best[0]:
        best = found
    return best
def solids():
    if not _SOLIDS:
        _SOLIDS.extend(box for box in boxes() if box.tag not in ("pipe_step", "fence"))
        _SOLIDS.extend(_fences(CURB, "curb"))
    return _SOLIDS
_SOLIDS = []
def surfaces():
    if not _SURFACES:
        _SURFACES.extend(box.grown(RAIL_PAD) if is_rail(box) else box for box in boxes()
                         if box.tag not in ("pipe_step", "fence"))
        _SURFACES.extend(_fences(CURB, "curb"))
    return _SURFACES
def _fences(height, tag):
    x0, x1, z0, z1 = LEFT - THICK, RIGHT + THICK, FRONT - THICK, BACK + THICK
    return [g3dbody.Box(x0, x1, 0.0, height, BACK, z1, tag=tag), g3dbody.Box(x0, x1, 0.0, height, z0, FRONT, tag=tag),
            g3dbody.Box(RIGHT, x1, 0.0, height, z0, z1, tag=tag), g3dbody.Box(x0, LEFT, 0.0, height, z0, z1, tag=tag)]
_SURFACES = []
def boxes():
    found = [g3dbody.Box.at((x, h / 2, z), (w, h, d), tag=name) for name, (x, z), (w, h, d), _color in OBJECTS]
    for name, (x, z), length, h, axis in RAILS:
        found.append(g3dbody.Box.at((x, h / 2, z), (length, h, RAIL_WIDTH) if axis == "x" else (RAIL_WIDTH, h, length), tag=name))
    return found + PIPE.boxes() + QP.boxes() + _fences(FENCE_HEIGHT, "fence")
def is_rail(box):
    return getattr(box, "tag", None) in {rail[0] for rail in RAILS}
def ground_shape():
    middle = (FRONT + BACK) / 2
    hx0, hx1, hz0, hz1 = BOWL.hole()
    shape = g3d.Shape([], [])
    for z in (middle - GROUND / 2, middle + GROUND / 2):
        shape.add(g3d.plane(GROUND, GROUND, int(GROUND / 2), skip=(hx0, hx1, hz0 - z, hz1 - z)), pos=(0.0, 0.0, z))
    return shape
def objects_shape():
    shape = g3d.Shape([], [])
    for _name, (x, z), (w, h, d), color in OBJECTS:
        shape.add(g3d.box(w, h, d), pos=(x, h / 2, z), color=color)
    for _name, (x, z), length, h, axis in RAILS:
        bar = (length, 0.08, 0.08) if axis == "x" else (0.08, 0.08, length)
        shape.add(g3d.box(*bar), pos=(x, h - 0.04, z), color=RAIL_COLOR)
        posts = int(length // 2) + 1
        for i in range(posts):
            along = (i / (posts - 1) - 0.5) * (length - 0.2)
            px, pz = (x + along, z) if axis == "x" else (x, z + along)
            shape.add(g3d.box(0.06, h - 0.08, 0.06), pos=(px, (h - 0.08) / 2, pz), color=(150, 130, 50))
    shape.add(PIPE.shape())
    shape.add(BOWL.shape())
    shape.add(QP.shape())
    for box in _fences(CURB, "curb"):
        shape.add(g3d.box(*box.size), pos=box.center, color=FENCE)
    return shape
def board_shape():
    shape = g3d.Shape([], [])
    shape.add(g3d.box(0.22, 0.03, 0.80), pos=(0, 0.095, 0), color=(60, 60, 70))
    shape.add(g3d.box(0.22, 0.03, 0.10), pos=(0, 0.11, 0.42), rot=(-25, 0, 0), color=(230, 180, 60))
    shape.add(g3d.box(0.22, 0.03, 0.10), pos=(0, 0.11, -0.42), rot=(25, 0, 0), color=(60, 60, 70))
    for x in (-0.09, 0.09):
        for z in (-0.26, 0.26):
            shape.add(g3d.box(0.05, 0.07, 0.07), pos=(x, 0.035, z), color=(240, 240, 235))
    return shape
