import math
from rgbkit import g3d, g3dbody
STEP = 1 / 120
SIDE_MARGIN = 0.25
WALL_COLOR = (178, 186, 198)
CAP_COLOR = (150, 156, 168)
BACK_COLOR = (130, 136, 150)
COPING_COLOR = (235, 200, 60)
BOTTOM_COLOR = (150, 152, 160)
DECK_COLOR = (158, 160, 166)
COLUMNS = 3
UP = (0.0, 1.0, 0.0)
LIP_MARGIN = 0.25
SMALL_WALL = 0.5
ENTER_STEP = 0.05
class Surface:
    name = None
    def __init__(self, bottom, radius, floor, walls, ends=None, channel=None):
        self.bx0, self.bx1, self.bz0, self.bz1 = bottom
        self.radius, self.floor, self.walls, self.ends, self.channel = radius, floor, walls, ends, channel
        self.top = floor + radius
        self.arc = math.pi / 2 * radius
        if channel is None:
            self.ramp, self.ramp_from = 0.0, self.bz1
        else:
            self.ramp, self.ramp_from = channel[3], self.bz1 + channel[2]
        self.zend = self.ramp_from + self.ramp
    def base(self, cz):
        if self.ramp <= 0.0 or cz <= self.ramp_from:
            return self.floor
        t = min(1.0, (cz - self.ramp_from) / self.ramp)
        return self.floor + self.radius * (1.0 - math.cos(math.pi * t)) / 2.0
    def slope_at(self, cz):
        if self.ramp <= 0.0 or not self.ramp_from < cz < self.zend:
            return 0.0
        t = (cz - self.ramp_from) / self.ramp
        return self.radius * math.pi / (2.0 * self.ramp) * math.sin(math.pi * t)
    def radius_at(self, cz):
        return self.top - self.base(cz)
    def on_ramp(self, cz):
        return self.ramp > 0.0 and cz > self.ramp_from
    def nearest(self, x, z):
        cx = min(self.bx1, max(self.bx0, x)) if "x" in self.walls else x
        cz = min(self.bz1, max(self.bz0, z)) if "z" in self.walls else z
        if self.channel is None:
            return cx, cz
        best = (math.hypot(x - cx, z - cz), cx, cz)
        c0, c1, rho = self.channel[0], self.channel[1], self.channel[2]
        px, pz = min(c1, max(c0, x)), min(self.zend, max(self.bz1, z))
        far = math.hypot(x - px, z - pz)
        if far < best[0]:
            best = (far, px, pz)
        for fx, lo, hi in ((c0 - rho, c0 - rho, c0), (c1 + rho, c1, c1 + rho)):
            fz = self.bz1 + rho
            if lo <= x <= hi and self.bz1 <= z <= fz:
                d = math.hypot(x - fx, z - fz)
                if d >= rho:
                    return x, z
                if d > 1e-9 and rho - d < best[0]:
                    best = (rho - d, fx + (x - fx) * rho / d, fz + (z - fz) * rho / d)
        return best[1], best[2]
    def reach(self, x, z):
        cx, cz = self.nearest(x, z)
        e = math.hypot(x - cx, z - cz)
        if e < 1e-9:
            return 0.0, None
        return e, ((x - cx) / e, (z - cz) / e)
    def along(self, x, z):
        if self.ends is None:
            return True
        at = x if self.walls == "z" else z
        return self.ends[0] <= at <= self.ends[1]
    def over(self, x, z, margin=0.0):
        if not self.along(x, z):
            return False
        cx, cz = self.nearest(x, z)
        e = math.hypot(x - cx, z - cz)
        if e < 1e-9:
            return cz < self.zend or self.ramp <= 0.0
        return e < self.radius_at(cz) + margin
    def height(self, x, z):
        cx, cz = self.nearest(x, z)
        e, r = math.hypot(x - cx, z - cz), self.radius_at(cz)
        if e < 1e-9:
            return self.base(cz)
        if e >= r + 1e-9:
            return None
        return self.top - math.sqrt(max(0.0, r * r - e * e))
    def ramp_normal(self, cz):
        k = self.slope_at(cz)
        length = math.sqrt(1.0 + k * k)
        return (0.0, 1.0 / length, -k / length)
    def wall_normal(self, x, y, z, cx, cz):
        grow = 0.0
        if abs(cz - z) < 1e-9 and self.on_ramp(cz):
            grow = -self.slope_at(cz) * self.radius_at(cz)
        v = (cx - x, self.top - min(y, self.top), cz - z + grow)
        length = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
        return (v[0] / length, v[1] / length, v[2] / length)
    def ride_normal(self, x, y, z, cx, cz):
        r = self.radius_at(cz)
        if r >= 2.0 * SMALL_WALL:
            return self.wall_normal(x, y, z, cx, cz)
        part = min(1.0, math.hypot(x - cx, z - cz) / r) if r > 1e-9 else 1.0
        ramp = self.ramp_normal(cz)
        flat = tuple(ramp[i] * (1.0 - part) + UP[i] * part for i in range(3))
        length = math.sqrt(sum(c * c for c in flat))
        flat = tuple(c / length for c in flat)
        if r <= SMALL_WALL:
            return flat
        k = (r - SMALL_WALL) / SMALL_WALL
        wall = self.wall_normal(x, y, z, cx, cz)
        v = tuple(flat[i] * (1.0 - k) + wall[i] * k for i in range(3))
        length = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
        return tuple(c / length for c in v)
    def normal(self, x, y, z):
        cx, cz = self.nearest(x, z)
        e = math.hypot(x - cx, z - cz)
        if e < 1e-9:
            return self.ramp_normal(cz)
        return self.wall_normal(x, y, z, cx, cz)
    def bowl_depth(self, x, y, z):
        if not self.over(x, z):
            return None
        cx, cz = self.nearest(x, z)
        e, r = math.hypot(x - cx, z - cz), self.radius_at(cz)
        if e < 1e-9:
            return self.base(cz) - y, self.ramp_normal(cz)
        if y >= self.top:
            return self.top - y, UP
        d = (x - cx, y - self.top, z - cz)
        length = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
        return length - r, (-d[0] / length, -d[1] / length, -d[2] / length)
class Pipe(Surface):
    def __init__(self, x0, x1, z0, z1, flat=2.0, radius=2.0, segments=12):
        self.x0, self.x1, self.z0, self.z1 = x0, x1, z0, z1
        self.flat, self.segments = flat, segments
        self.mid = (x0 + x1) / 2
        self.back = (x1 - x0 - flat - 2 * radius) / 2
        super().__init__((self.mid - flat / 2, self.mid + flat / 2, z0, z1), radius, 0.0, "x", ends=(z0, z1))
    def edge(self, side):
        return self.mid + side * self.flat / 2
    def lip(self, side):
        return self.mid + side * (self.flat / 2 + self.radius)
    def inside(self, x, z, margin=0.0):
        return self.lip(-1) <= x <= self.lip(1) and self.z0 - margin <= z <= self.z1 + margin
    def side(self, x):
        if x < self.edge(-1):
            return -1
        if x > self.edge(1):
            return 1
        return 0
    def height(self, x, z=None):
        across = min(self.radius, self.reach(x, self.z0 if z is None else z)[0])
        return self.top - math.sqrt(self.radius * self.radius - across * across)
    def depth(self, x, y, z, side=None):
        best = (-y, (0.0, 1.0, 0.0))
        if not self.z0 <= z <= self.z1:
            return best
        side = -1 if x < self.mid else 1
        lip = self.lip(side)
        if side * (x - self.edge(side)) > 0 and y < self.top:
            if side * (x - lip) >= 0:
                up, inward = self.top - y, side * (x - lip)
                found = (up, (0.0, 1.0, 0.0)) if up < inward else (inward, (-side, 0.0, 0.0))
            else:
                cx, cy = self.edge(side), self.radius
                far = math.hypot(x - cx, y - cy)
                found = (far - self.radius, ((cx - x) / far, (cy - y) / far, 0.0)) if far > 1e-6 else best
            if found[0] > best[0]:
                best = found
        return best
    def point(self, side, s):
        angle = s / self.radius
        return self.edge(side) + side * self.radius * math.sin(angle), self.radius - self.radius * math.cos(angle)
    def boxes(self):
        found = []
        for side in (-1, 1):
            lip = self.lip(side)
            outer = lip + side * self.back
            found.append(g3dbody.Box(min(lip, outer), max(lip, outer), 0.0, self.top, self.z0, self.z1, tag="pipe_back"))
            for i in range(COLUMNS):
                a, b = lip - side * 0.5 * i, lip - side * 0.5 * (i + 1)
                found.append(g3dbody.Box(min(a, b), max(a, b), 0.0, self.height(a), self.z0, self.z1, tag="pipe_step"))
        return found
    def shape(self):
        shape = g3d.Shape([], [])
        for side in (-1, 1):
            ring = [self.point(side, self.arc * i / self.segments) for i in range(self.segments + 1)]
            for i in range(self.segments):
                (xa, ya), (xb, yb) = ring[i], ring[i + 1]
                angle = (i + 0.5) / self.segments * math.pi / 2
                inward = (-side * math.sin(angle), math.cos(angle), 0.0)
                _face(shape, [(xa, ya, self.z0), (xb, yb, self.z0), (xb, yb, self.z1), (xa, ya, self.z1)], inward, WALL_COLOR)
            corner = (self.lip(side), 0.0)
            for z, out in ((self.z0, -1.0), (self.z1, 1.0)):
                _face(shape, [(corner[0], corner[1], z)] + [(x, y, z) for x, y in ring], (0.0, 0.0, out), CAP_COLOR)
            lip = self.lip(side)
            width = self.back
            shape.add(g3d.box(width, self.top, self.z1 - self.z0),
                      pos=(lip + side * width / 2, self.top / 2, (self.z0 + self.z1) / 2), color=BACK_COLOR)
            shape.add(g3d.box(0.1, 0.1, self.z1 - self.z0), pos=(lip + side * 0.05, self.top - 0.03, (self.z0 + self.z1) / 2),
                      color=COPING_COLOR)
        return shape
class Quarter(Surface):
    def __init__(self, x0, x1, z, radius=3.5, back=1.0, segments=16, steps=7):
        self.x0, self.x1 = x0, x1
        self.foot = z
        self.lip_z = z + radius
        self.back, self.segments, self.steps = back, segments, steps
        super().__init__((x0, x1, -1e9, z), radius, 0.0, "z", ends=(x0, x1))
    def nearest(self, x, z):
        return x, min(self.bz1, z)
    def near(self, x, z, margin=0.0):
        return self.x0 - margin <= x <= self.x1 + margin and self.foot - margin <= z <= self.lip_z + self.back + margin
    def wall_height(self, z):
        e = min(self.radius, max(0.0, z - self.foot))
        return self.top - math.sqrt(self.radius * self.radius - e * e)
    def boxes(self):
        found = [g3dbody.Box(self.x0, self.x1, 0.0, self.top, self.lip_z, self.lip_z + self.back, tag="qp_back")]
        step = self.radius / self.steps
        for i in range(self.steps):
            z0, z1 = self.foot + step * i, self.foot + step * (i + 1)
            if self.wall_height(z1) < 0.06:
                continue
            for a, b in ((self.x0, self.x0 + 0.25), (self.x1 - 0.25, self.x1)):
                found.append(g3dbody.Box(a, b, 0.0, self.wall_height(z1), z0, z1, tag="pipe_step"))
        return found
    def shape(self):
        shape = g3d.Shape([], [])
        ring = []
        for i in range(self.segments + 1):
            angle = math.pi / 2 * i / self.segments
            ring.append((self.foot + self.radius * math.sin(angle), self.radius - self.radius * math.cos(angle)))
        for i in range(self.segments):
            (za, ya), (zb, yb) = ring[i], ring[i + 1]
            angle = (i + 0.5) / self.segments * math.pi / 2
            inward = (0.0, math.cos(angle), -math.sin(angle))
            _face(shape, [(self.x0, ya, za), (self.x1, ya, za), (self.x1, yb, zb), (self.x0, yb, zb)], inward, WALL_COLOR)
        for x, out in ((self.x0, -1.0), (self.x1, 1.0)):
            _face(shape, [(x, 0.0, self.lip_z)] + [(x, y, z) for z, y in ring], (out, 0.0, 0.0), CAP_COLOR)
        length = self.x1 - self.x0
        shape.add(g3d.box(length, self.top, self.back), pos=((self.x0 + self.x1) / 2, self.top / 2, self.lip_z + self.back / 2),
                  color=BACK_COLOR)
        shape.add(g3d.box(length, 0.1, 0.1), pos=((self.x0 + self.x1) / 2, self.top - 0.03, self.lip_z + 0.05), color=COPING_COLOR)
        return shape
class Bowl(Surface):
    def __init__(self, x0, x1, z0, z1, radius=2.0, channel=None, segments=12, corner_segments=6, ramp_segments=16, cell=0.5):
        super().__init__((x0, x1, z0, z1), radius, -radius, "xz", channel=channel)
        self.segments, self.corner_segments, self.ramp_segments, self.cell = segments, corner_segments, ramp_segments, cell
    def hole(self):
        r = self.radius
        return (2.0 * math.floor((self.bx0 - r) / 2.0), 2.0 * math.ceil((self.bx1 + r) / 2.0),
                2.0 * math.floor((self.bz0 - r) / 2.0), 2.0 * math.ceil(self.zend / 2.0))
    def outside(self, x, z):
        cx, cz = self.nearest(x, z)
        return math.hypot(x - cx, z - cz) - self.radius_at(cz)
    def _rim(self):
        c0, c1, rho = self.channel[0], self.channel[1], self.channel[2]
        x0, x1, z0, z1 = self.bx0, self.bx1, self.bz0, self.bz1
        fz = z1 + rho
        rows = [self.ramp_from + self.ramp * k / self.ramp_segments for k in range(self.ramp_segments, -1, -1)]
        found = [(c1, z, 1.0, 0.0) for z in rows]
        found += [(c1 + rho + rho * math.cos(t), fz + rho * math.sin(t), -math.cos(t), -math.sin(t))
                  for t in (math.pi + math.pi / 2 * k / self.corner_segments for k in range(self.corner_segments + 1))]
        found += [(x1, z1, math.cos(t), math.sin(t)) for t in (math.pi / 2 - math.pi / 2 * k / self.corner_segments
                                                                for k in range(self.corner_segments + 1))]
        found += [(x1, z0, math.cos(t), math.sin(t)) for t in (-math.pi / 2 * k / self.corner_segments
                                                                for k in range(self.corner_segments + 1))]
        found += [(x0, z0, math.cos(t), math.sin(t)) for t in (-math.pi / 2 - math.pi / 2 * k / self.corner_segments
                                                                for k in range(self.corner_segments + 1))]
        found += [(x0, z1, math.cos(t), math.sin(t)) for t in (math.pi - math.pi / 2 * k / self.corner_segments
                                                                for k in range(self.corner_segments + 1))]
        found += [(c0 - rho + rho * math.cos(t), fz + rho * math.sin(t), -math.cos(t), -math.sin(t))
                  for t in (-math.pi / 2 + math.pi / 2 * k / self.corner_segments for k in range(self.corner_segments + 1))]
        found += [(c0, z, -1.0, 0.0) for z in reversed(rows)]
        return found
    def shape(self):
        shape = g3d.Shape([], [])
        top, n = self.top, self.segments
        c0, c1, rho = self.channel[0], self.channel[1], self.channel[2]
        x0, x1, z0, z1 = self.bx0, self.bx1, self.bz0, self.bz1
        _face(shape, [(x0, self.floor, z0), (x1, self.floor, z0), (x1, self.floor, z1), (x0, self.floor, z1)], UP, BOTTOM_COLOR)
        zs = [z1] + [self.ramp_from + self.ramp * k / self.ramp_segments for k in range(self.ramp_segments + 1)]
        for za, zb in zip(zs, zs[1:]):
            ya, yb = self.base(za), self.base(zb)
            _face(shape, [(c0, ya, za), (c1, ya, za), (c1, yb, zb), (c0, yb, zb)], self.ramp_normal((za + zb) / 2), BOTTOM_COLOR)
        m = self.corner_segments
        for corner, fx in (((c0, z1), c0 - rho), ((c1, z1), c1 + rho)):
            ring = [(fx + rho * math.cos(t), self.floor, z1 + rho + rho * math.sin(t))
                    for t in ((-math.pi / 2 + math.pi / 2 * k / m) if fx < c0 else (math.pi + math.pi / 2 * k / m) for k in range(m + 1))]
            for a, b in zip(ring, ring[1:]):
                _face(shape, [(corner[0], self.floor, corner[1]), a, b], UP, BOTTOM_COLOR)
        rim = self._rim()
        for (ax, az, aox, aoz), (bx, bz, box, boz) in zip(rim, rim[1:]):
            ra, rb = self.radius_at(az), self.radius_at(bz)
            if ra < 1e-6 and rb < 1e-6:
                continue
            for i in range(n):
                p, q = math.pi / 2 * i / n, math.pi / 2 * (i + 1) / n
                quad = [(ax + aox * ra * math.sin(p), top - ra * math.cos(p), az + aoz * ra * math.sin(p)),
                        (bx + box * rb * math.sin(p), top - rb * math.cos(p), bz + boz * rb * math.sin(p)),
                        (bx + box * rb * math.sin(q), top - rb * math.cos(q), bz + boz * rb * math.sin(q)),
                        (ax + aox * ra * math.sin(q), top - ra * math.cos(q), az + aoz * ra * math.sin(q))]
                if math.dist(quad[0], quad[1]) < 1e-6 and math.dist(quad[2], quad[3]) < 1e-6:
                    continue
                mid, ox, oz = (p + q) / 2, (aox + box) / 2, (aoz + boz) / 2
                _face(shape, quad, (-ox * math.sin(mid), math.cos(mid), -oz * math.sin(mid)), WALL_COLOR)
            if ra >= SMALL_WALL and rb >= SMALL_WALL:
                a, b = (ax + aox * (ra + 0.05), az + aoz * (ra + 0.05)), (bx + box * (rb + 0.05), bz + boz * (rb + 0.05))
                length = math.hypot(b[0] - a[0], b[1] - a[1])
                if length > 1e-6:
                    shape.add(g3d.box(0.1, 0.1, length + 0.02), pos=((a[0] + b[0]) / 2, top - 0.03, (a[1] + b[1]) / 2),
                              rot=(0.0, math.degrees(math.atan2(b[0] - a[0], b[1] - a[1])), 0.0), color=COPING_COLOR)
        self._deck(shape)
        return shape
    def _deck(self, shape):
        hx0, hx1, hz0, hz1 = self.hole()
        step = self.cell
        cols, rows = int(round((hx1 - hx0) / step)), int(round((hz1 - hz0) / step))
        value = [[self.outside(hx0 + i * step, hz0 + j * step) for i in range(cols + 1)] for j in range(rows + 1)]
        for j in range(rows):
            za, zb = hz0 + j * step, hz0 + (j + 1) * step
            run = None
            for i in range(cols + 1):
                full = i < cols and min(value[j][i], value[j][i + 1], value[j + 1][i], value[j + 1][i + 1]) >= 0.0
                if full and run is None:
                    run = i
                if not full and run is not None:
                    xa, xb = hx0 + run * step, hx0 + i * step
                    _face(shape, [(xa, self.top, za), (xb, self.top, za), (xb, self.top, zb), (xa, self.top, zb)], UP, DECK_COLOR)
                    run = None
                if i < cols and not full:
                    corners = [(hx0 + i * step, za, value[j][i]), (hx0 + (i + 1) * step, za, value[j][i + 1]),
                               (hx0 + (i + 1) * step, zb, value[j + 1][i + 1]), (hx0 + i * step, zb, value[j + 1][i])]
                    poly = []
                    for k in range(4):
                        (xa_, za_, fa), (xb_, zb_, fb) = corners[k], corners[(k + 1) % 4]
                        if fa >= 0.0:
                            poly.append((xa_, self.top, za_))
                        if (fa >= 0.0) != (fb >= 0.0):
                            t = fa / (fa - fb)
                            poly.append((xa_ + (xb_ - xa_) * t, self.top, za_ + (zb_ - za_) * t))
                    if len(poly) >= 3:
                        _face(shape, poly, UP, DECK_COLOR)
def _face(shape, corners, toward, color):
    a, b, c = corners[0], corners[1], corners[2]
    u = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
    v = (c[0] - a[0], c[1] - a[1], c[2] - a[2])
    cross = (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
    if cross[0] * toward[0] + cross[1] * toward[1] + cross[2] * toward[2] > 0:
        corners = [corners[0]] + list(reversed(corners[1:]))
    shape.add(g3d.Shape(corners, [tuple(range(len(corners)))], colors=[color] * len(corners)))
class Ride:
    def __init__(self, surface, att, normal):
        self.surface = surface
        self.att = att
        self.phase = "wall"
        self.n = normal
        self.out = (0.0, 0.0)
        self.p = (0.0, 0.0, 0.0)
    @property
    def side(self):
        return 0 if abs(self.out[0]) < 0.5 else (1 if self.out[0] > 0 else -1)
    @property
    def s(self):
        if self.phase == "air":
            return self.surface.arc
        surf = self.surface
        cx, cz = surf.nearest(self.p[0], self.p[2])
        e, r = math.hypot(self.p[0] - cx, self.p[2] - cz), surf.radius_at(cz)
        return 0.0 if r < 1e-9 else surf.radius * math.asin(min(1.0, e / r))
    @property
    def slope(self):
        return min(self.s, self.surface.arc) / self.surface.radius
    @property
    def angle(self):
        return math.degrees(self.slope)
    def lat(self):
        ox, oz = self.out
        lx, lz = -oz, ox
        if lz < -1e-9 or (abs(lz) <= 1e-9 and lx < 0):
            lx, lz = -lx, -lz
        return (lx, 0.0, lz)
    @property
    def u(self):
        if self.phase == "air":
            return 0.0
        return self.att.climb(self.n)
    @property
    def w(self):
        v, lat = self.att.surf_v, self.lat()
        return v[0] * lat[0] + v[2] * lat[2]
    @property
    def vy(self):
        return self.att.surf_v[1]
    @property
    def ramp(self):
        surf = self.surface
        if self.phase != "wall":
            return False
        cx, cz = surf.nearest(self.p[0], self.p[2])
        return math.hypot(self.p[0] - cx, self.p[2] - cz) < 1e-9 and surf.on_ramp(cz)
    def normal(self):
        return self.n
    def world(self):
        return self.att.surf_v
    def _set(self, body, p):
        body.x, body.y, body.z = p
        self.p = p
    def update(self, body, dt, falling=False):
        surf, att = self.surface, self.att
        count = max(1, math.ceil(dt / STEP - 1e-6))
        part = dt / count
        for _ in range(count):
            if self.phase == "wall":
                att.wall_force(part, self.n, falling)
                v = att.surf_v
                p = (body.x + v[0] * part, body.y + v[1] * part, body.z + v[2] * part)
                if not surf.along(p[0], p[2]):
                    self._set(body, p)
                    return "out"
                cx, cz = surf.nearest(p[0], p[2])
                e = math.hypot(p[0] - cx, p[2] - cz)
                if e < 1e-9:
                    if not surf.on_ramp(cz):
                        self._set(body, (p[0], surf.floor, p[2]))
                        return "bottom"
                    if cz >= surf.zend - 1e-6:
                        self._set(body, (p[0], surf.top, p[2]))
                        return "deck"
                    self.n = surf.ramp_normal(cz)
                    self.out = (0.0, 1.0)
                    att.constrain(self.n)
                    self._set(body, (p[0], surf.base(cz), p[2]))
                    continue
                out = ((p[0] - cx) / e, (p[2] - cz) / e)
                self.out = out
                r = surf.radius_at(cz)
                if r < SMALL_WALL:
                    if e >= r:
                        self._set(body, (p[0], surf.top, p[2]))
                        return "deck"
                    at = (p[0], surf.top - math.sqrt(r * r - e * e), p[2])
                    self.n = surf.ride_normal(*at, cx, cz)
                    att.constrain(self.n)
                    self._set(body, at)
                    continue
                d = (p[0] - cx, min(0.0, p[1] - surf.top), p[2] - cz)
                length = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
                at = (cx + d[0] * r / length, surf.top + d[1] * r / length, cz + d[2] * r / length)
                self.n = surf.ride_normal(*at, cx, cz)
                if p[1] >= surf.top and v[1] > 0:
                    lip = (cx + out[0] * r, surf.top, cz + out[1] * r)
                    self.n = surf.ride_normal(*lip, cx, cz)
                    att.constrain(self.n)
                    self.phase = "air"
                    self._set(body, lip)
                    return "launch"
                att.constrain(self.n)
                self._set(body, at)
            elif surf.ends is None:
                att.lip_force(part)
                v = att.surf_v
                p = (body.x + v[0] * part, body.y + v[1] * part, body.z + v[2] * part)
                cx, cz = surf.nearest(p[0], p[2])
                e, out = surf.reach(p[0], p[2])
                r = surf.radius_at(cz)
                if out is None or r < SMALL_WALL:
                    self._set(body, p)
                    return "out"
                lip = (cx + out[0] * r, surf.top, cz + out[1] * r)
                self.out = out
                self.n = surf.ride_normal(*lip, cx, cz)
                att.constrain_lip(out)
                if att.surf_v[1] < 0 and p[1] <= surf.top:
                    att.constrain(self.n)
                    self.phase = "wall"
                    self._set(body, lip)
                    return "attach"
                self._set(body, (lip[0], p[1], lip[2]))
            else:
                att.lip_force(part)
                v = att.surf_v
                p = (body.x + v[0] * part, body.y + v[1] * part, body.z + v[2] * part)
                cx, cz = surf.nearest(p[0], p[2])
                if not surf.over(p[0], p[2], LIP_MARGIN) or surf.reach(p[0], p[2])[1] is None \
                        or math.hypot(p[0] - cx, p[2] - cz) < surf.radius_at(cz) - LIP_MARGIN:
                    self._set(body, p)
                    return "out"
                if v[1] < 0 and p[1] <= surf.top:
                    cx, cz = surf.nearest(p[0], p[2])
                    e, out = surf.reach(p[0], p[2])
                    r = surf.radius_at(cz)
                    lip = (cx + out[0] * r, surf.top, cz + out[1] * r)
                    self.out = out
                    self.n = surf.ride_normal(*lip, cx, cz)
                    att.constrain(self.n)
                    self.phase = "wall"
                    self._set(body, lip)
                    return "attach"
                self._set(body, p)
        return None
def enter(surface, body, att):
    if not surface.over(body.x, body.z):
        return None
    cx, cz = surface.nearest(body.x, body.z)
    e, out = surface.reach(body.x, body.z)
    if out is None and not surface.on_ramp(cz):
        return None
    height = surface.height(body.x, body.z)
    if height is None or body.y > height + (ENTER_STEP if body.grounded else 1e-6):
        return None
    normal = surface.ride_normal(body.x, height, body.z, cx, cz) if out is not None else surface.ramp_normal(cz)
    att.enter_wall(normal, 0.0 if body.grounded else body.vy)
    ride = Ride(surface, att, normal)
    ride.out = out or (0.0, 1.0)
    ride._set(body, (body.x, height, body.z))
    body.vy = 0.0
    body.grounded = True
    return ride
