import math
import sys
from rgbkit import Game, Progress, anim, format_time, g3d, g3dfx, g3drig, g3drot
import attitude
import park
import scenery
import figure as figure_module
from figure import Figure
from flick import Flick
from airshow import AirShow
from score import Combo
from skater import BAIL_TIME, Skater
TITLE_RADIUS, TITLE_HEIGHT = 44.0, 16.0
FOG_NEAR, FOG_FAR = 30.0, 110.0
CAMERA_BACK = 4.5
CAMERA_HEIGHT = 2.2
CAMERA_LOOK = 1.0
CAMERA_FOLLOW = 4.0
CAMERA_RISE = 5.0
PIPE_BACK = 7.0
CAMERA_NEAR = 8.0
CAMERA_SAMPLES = 16
CAMERA_CLEAR = 0.2
CAMERA_MIN = 0.25
CAMERA_LIFT = 4
PIPE_RISE = 10.0
BOARD = 0.11
LEAN = 14.0
NOSE = 3.0
NOSE_MAX = 16.0
EDGE_TILT = 18.0
PLAY_TIME = 120.0
MODES = ("timed", "free")
WHITE, SHADOW, RED, GOLD, DIM = (255, 255, 255), (20, 30, 50), (255, 90, 80), (255, 215, 90), (200, 210, 225)
AIR_POINTS = 100
BOARD_ASIDE = 40.0
BOARD_STEP = 0.5
BOARD_SLIDE = 1.3
SHAPE_TIME = 0.5
SHAPE_EVERY = 3
POS_EVERY = 0.5
STUCK_TIME = 1.0
STUCK_MOVE = 0.1
GRAB_NEAR = (0.25, 0.15, 0.55)
ROLL_FROM = 0.3
ROLL_VOLUME = (0.15, 0.6)
GRIND_VOLUME = 0.45
DUST_FROM = 1.0
DUST_EVERY = 0.05
SOUNDS = ("roll", "grind", "push", "pop", "land", "bail", "score", "ten", "timeup", "tick", "air")
FLICKS = {"up": "ollie", "upleft": "kickflip", "upright": "heelflip", "left": "shuvit_left",
          "right": "shuvit_right"}
BOARD_AWAY = anim.Curve([(0.0, 0.0), (0.35, 1.0), (0.8, 1.0), (1.0, 0.0)])
def _unit3(v):
    return g3drot.unit(v) or (0.0, 0.0, 0.0)
def _hidden(seen, eye):
    length = math.dist(seen, eye)
    back = CAMERA_CLEAR / length if length > 1e-6 else 0.0
    for k in range(1, CAMERA_SAMPLES + 1):
        t = k / CAMERA_SAMPLES
        if park.depth(*(seen[i] + (eye[i] - seen[i]) * t for i in range(3)))[0] > 0.0:
            return max(0.0, t - 1.0 / CAMERA_SAMPLES - back)
    return None
class Skate(Game):
    title = "skate"
    background = park.SKY
    save_with_command = False
    uses_3d = True
    fps = 40
    web_keyboard = {}
    web_touch_layout = {}
    web_sound_band = (300, 6000)
    def controls(self):
        return {"dpad", "a", "b", "r1", "start", "left_stick", "right_stick"}
    def start(self):
        self.input.left_stick_counts = False
        view = self.view = g3d.View(self, size=320)
        self.ground = view.mesh(park.ground_shape(), texture=view.texture_rows(park.TILE, park.TILE_COLORS))
        self.objects = view.mesh(park.objects_shape())
        self.board = view.mesh(park.board_shape())
        self.grass = view.mesh(scenery.grass_shape())
        windows = view.texture_rows(scenery.WINDOW, scenery.WINDOW_COLORS)
        self.scenery = [(view.mesh(shape), shape.bounds()) for shape in scenery.wood_shapes()] \
            + [(view.mesh(shape, texture=windows), shape.bounds()) for shape in scenery.city_shapes()]
        self.shown_sections = 0
        self.figure = Figure(view, view.mesh(g3d.box()))
        view.background(park.SKY)
        view.fog(park.SKY, FOG_NEAR, FOG_FAR)
        view.light((0.45, -1.0, 0.6), ambient=0.55)
        self.skater = Skater(park.boxes())
        self.flick = Flick()
        self.tricks = 0
        self.trick = ""
        self.landed = 0
        self.bails = 0
        self.grinds = 0
        self.leaps = 0
        self.last_leap = None
        self.lean = 0.0
        self.progress = Progress(self, stages=1, lower_is_better=False, low=0.0)
        self.mode = "timed"
        self.combo = Combo()
        self.time_left = PLAY_TIME
        self.popup = anim.Timer(1.5)
        self.gained = 0
        self.new_record = False
        for name in SOUNDS:
            self.sound.load(self.sfx(name))
        self.dust = g3dfx.Puffs(view, life=0.5, limit=30, rise=0.6, vary=(0.7, 1.3),
                                size=anim.Curve([(0.0, 0.10), (0.4, 0.28), (1.0, 0.0)]),
                                color=anim.Curve([(0.0, (190, 188, 182)), (1.0, (165, 165, 168))]))
        self.dust_clock = 0.0
        self.watch = anim.Watch()
        self.restart()
        self.to_title()
    def restart(self, spot="start", speed=0.0):
        self.skater.place(*park.SPOTS[spot], speed=speed)
        self.camera_angle = self.skater.heading
        self.camera_y = self.skater.body.y
        self.camera_back = CAMERA_BACK
        self.camera_reach = 1.0
        self.camera_lift = 0.0
        self.flick.reset()
        self.lean = 0.0
        self.tilt = (0.0, 0.0)
        self.board_away = 0.0
        self.board_at = (0.0, 0.0, 0.0)
        self.figure.reset()
        self.combo = Combo()
        self.time_left = PLAY_TIME
        self.popup = anim.Timer(1.5)
        self.air_popup = anim.Timer(1.5)
        self.air_shown = (0.0, 0, 0)
        if not hasattr(self, "airshow"):
            self.airshow = AirShow(lambda name: self.sound.play(self.sfx(name), volume=0.7))
        self.airshow.reset()
        self.air_last = (0.0, 0, 0)
        self.shape = None
        self.pos_time = 0.0
        self.drawn = None
        self.grab_t = None
        self.still = None
        self.calm()
        self.enter("play")
    def to_title(self):
        self.cursor = 0
        self.calm()
        self.enter("title")
    def calm(self):
        self.sound.stop_held()
        self.dust.clear()
        self.dust_clock = 0.0
        self.watch.reset()
    @staticmethod
    def sfx(name):
        return "sounds/%s.wav" % name
    def hidden_command(self, text):
        values = self.command_values()
        spot = values.text("at")
        speed = values.float("speed", 0.0, attitude.MAX_SPEED)
        if spot is not None and spot not in park.SPOTS:
            self.log("command: unknown at=%s" % spot)
            spot = None
        mode = values.text("mode")
        if mode is not None and mode not in MODES:
            self.log("command: unknown mode=%s" % mode)
            mode = None
        seconds = values.float("time", 1.0, 600.0)
        self.mode = "timed" if seconds is not None else (mode or "timed")
        self.restart(spot or "start", speed or 0.0)
        if seconds is not None:
            self.time_left = seconds
        if values.flag("bail"):
            self.bail()
        self.skater.trace = values.flag("trace")
        fps = values.int("fps", 20, 60)
        if fps is not None:
            self.fps = fps
    def update_title(self, dt):
        inp = self.input
        if inp.pressed("up") and inp.only("up", "down"):
            self.cursor = 0
        elif inp.pressed("down") and inp.only("up", "down"):
            self.cursor = 1
        if inp.tapped("a", since=self.entered):
            self.mode = MODES[self.cursor]
            self.restart()
    def update_result(self, dt):
        if self.input.tapped("a", since=self.entered, wait=1.0):
            self.to_title()
    def finish(self):
        self.combo.drop()
        score = self.combo.score
        self.new_record = score > 0 and self.progress.record(0, float(score))
        if self.new_record:
            self.progress.save()
        self.log("result: score=%d best=%s new=%s" % (score, self.progress.best[0], self.new_record))
        self.calm()
        self.sound.play(self.sfx("timeup"))
        self.enter("result")
    def update_play(self, dt):
        inp = self.input
        skater = self.skater
        combo = self.combo
        flew = not skater.grounded
        if skater.bailing:
            self.flick.reset()
            steer, brake, tumble, grab = 0.0, False, 0.0, False
        else:
            if inp.pressed("b") and inp.only("b"):
                if skater.push():
                    self.figure.push()
                    self.sound.play(self.sfx("push"), volume=0.6)
            way = self.flick.update(*inp.stick("right"), dt, skater.grounded)
            if way and skater.pop(FLICKS[way]):
                self.sound.play(self.sfx("pop"))
                self.tricks += 1
                self.trick = FLICKS[way]
                combo.trick(self.trick)
            steer, tumble = inp.stick("left")
            grab = inp.only("r1")
            brake = inp.only("a") and skater.grind is None and skater.wall is None
        was_grab_time = skater.grab_time
        happened = skater.update(dt, steer, brake, tumble, grab)
        if skater.grabbing:
            combo.grab(dt, was_grab_time == 0.0)
        if skater.trace:
            what = next((event for event in happened if event in ("bail", "wall", "land", "grind")), None)
            if what is not None:
                self.shape = [what, SHAPE_TIME, 0.0]
            elif self.shape is not None:
                self.shape[1] -= dt
                self.shape[2] += dt
                if self.shape[1] <= 0.0:
                    self.shape = None
        if skater.trace and not skater.bailing:
            self.log_pos(dt, inp, steer, brake, tumble)
        elif skater.trace:
            self.log_pos(dt, inp, 0.0, False, 0.0)
        for line in skater.notes:
            self.log(line)
        skater.notes.clear()
        for event in happened:
            if event == "land":
                self.landed += 1
                self.figure.land()
                self.sound.play(self.sfx("land"))
                if flew:
                    for _ in range(6):
                        self.dust.emit((skater.body.x, skater.body.y + 0.05, skater.body.z), size=1.0, spread=0.35)
                if flew:
                    combo.spin(skater.air_turn)
                    combo.flip(skater.air_flip)
                    self.air_bonus()
                self.leap()
                if combo.active:
                    self.gained = combo.bank()
                    self.popup.start()
                    if self.gained > 0:
                        self.sound.play(self.sfx("score"), volume=0.5)
            elif event == "wall":
                self.landed += 1
                self.figure.land()
                self.sound.play(self.sfx("land"))
                combo.spin(skater.air_turn)
                combo.flip(skater.air_flip)
                self.air_bonus()
            elif event in ("bottom", "deck"):
                if combo.active:
                    self.gained = combo.bank()
                    self.popup.start()
                    if self.gained > 0:
                        self.sound.play(self.sfx("score"), volume=0.5)
            elif event == "grind":
                self.grinds += 1
                self.figure.land()
                self.sound.play(self.sfx("land"), volume=0.7)
                if flew:
                    combo.spin(skater.air_turn)
                    combo.flip(skater.air_flip)
                    self.air_bonus()
                self.leap()
                combo.grind()
            elif event == "bail":
                self.bails += 1
                combo.drop()
                self.sound.play(self.sfx("bail"))
                self.log("bail: %s" % skater.why)
                self.flick.reset()
        with self.measure("figure_update"):
            self.figure.update(dt, skater.speed, skater.grounded, brake, self.flick.crouch, skater.turning,
                               skater.bail_time / BAIL_TIME if skater.bailing else None,
                               backward=skater.att.backward(skater.travel()), grind=skater.grind is not None,
                               wall=skater.wall is not None, flip=skater.att.flipping, tumble=skater.tumbling,
                               grab=skater.grabbing)
        if skater.grind is not None:
            combo.grinding(dt)
        self.popup.update(dt)
        self.air_popup.update(dt)
        if skater.lip_air and not skater.grounded:
            self.airshow.fly(skater.lip_height(), skater.air_halves())
        elif skater.bailing and self.airshow.showing:
            self.airshow.stop()
        self.airshow.update(dt)
        rolling = skater.grounded and not skater.bailing and skater.grind is None and skater.speed > ROLL_FROM
        low, high = ROLL_VOLUME
        self.sound.hold(self.sfx("roll"), rolling, volume=low + (high - low) * min(1.0, skater.speed / attitude.MAX_SPEED))
        self.sound.hold(self.sfx("grind"), skater.grind is not None and not skater.bailing, volume=GRIND_VOLUME)
        self.dust.step(dt)
        if brake and rolling and skater.speed > DUST_FROM:
            self.dust_clock += dt
            while self.dust_clock >= DUST_EVERY:
                self.dust_clock -= DUST_EVERY
                self.dust.emit((skater.body.x, skater.body.y + 0.05, skater.body.z), size=0.8, spread=0.2)
        else:
            self.dust_clock = 0.0
        if self.mode == "timed":
            self.time_left = max(0.0, self.time_left - dt)
            if self.watch.rose("ten", self.time_left < 10.0) and self.time_left > 0.0:
                self.sound.play(self.sfx("ten"), volume=0.6)
            if self.time_left <= 0.0:
                self.finish()
        piped = skater.wall is not None
        self.camera_y = anim.follow(self.camera_y, skater.body.y, PIPE_RISE if piped else CAMERA_RISE, dt)
        self.camera_back = anim.follow(self.camera_back, PIPE_BACK if piped else CAMERA_BACK, 2.0, dt)
        if skater.wall is None and not skater.bailing:
            self.camera_angle = anim.follow_angle(self.camera_angle, skater.heading, CAMERA_FOLLOW, dt)
        self.lean = anim.follow(self.lean, skater.steer * min(1.0, skater.speed / 3.0), 8.0, dt)
    def draw_world(self, eye, look):
        view = self.view
        view.draw(self.grass)
        self.shown_sections = 0
        for mesh, (center, radius) in self.scenery:
            if scenery.seen(eye, look, center, radius) and view.reaches(center, radius):
                view.draw(mesh)
                self.shown_sections += 1
        view.draw(self.ground)
        view.draw(self.objects)
    def draw(self, gfx):
        view = self.view
        if self.scene == "title":
            center, angle = (0.0, 0.0, (park.FRONT + park.BACK) / 2), self.scene_time * 6.0
            view.orbit(center, TITLE_RADIUS, TITLE_HEIGHT, angle)
            a = math.radians(angle)
            self.draw_world((center[0] + math.sin(a) * TITLE_RADIUS, center[1] + TITLE_HEIGHT, center[2] + math.cos(a) * TITLE_RADIUS),
                            center)
            view.show()
            self.draw_scene(gfx)
            return
        skater = self.skater
        body = skater.body
        angle = math.radians(self.camera_angle)
        look = (body.x, self.camera_y + CAMERA_LOOK, body.z)
        eye = (body.x - math.sin(angle) * self.camera_back, self.camera_y + CAMERA_HEIGHT, body.z - math.cos(angle) * self.camera_back)
        with self.measure("camera"):
            eye = self.clear_eye(look, eye, (body.x, body.y + CAMERA_LOOK, body.z))
        view.camera(eye=eye, look_at=look)
        self.draw_world(eye, look)
        if skater.wall is None and not skater.att.tilt:
            view.shadow((body.x, body.below(skater.boxes), body.z), radius=0.45)
        roll = -self.lean * LEAN
        nose = 0.0 if skater.grounded else max(-NOSE_MAX, min(NOSE_MAX, -body.vy * NOSE))
        flip, turn = skater.board_turn()
        target = BOARD_AWAY.at(skater.bail_time / BAIL_TIME) * BOARD_SLIDE \
            if skater.bailing and skater.wall is None and not skater.tumbling else 0.0
        self.board_away = anim.follow(self.board_away, target, 20.0, 1 / self.fps)
        away = self.board_away
        bx, by, bz = self.board_spot(away)
        tip = lift = 0.0
        if skater.grind is not None and skater.grind.out is not None:
            ox, oz = skater.grind.out
            ahead = skater.att.forward()
            way = math.atan2(ahead[0], ahead[2]) + math.radians(turn)
            right = math.cos(way) * ox - math.sin(way) * oz
            front = math.sin(way) * ox + math.cos(way) * oz
            self.tilt = (anim.follow(self.tilt[0], -EDGE_TILT * right, 14.0, 1 / self.fps),
                         anim.follow(self.tilt[1], EDGE_TILT * front, 14.0, 1 / self.fps))
        else:
            self.tilt = (anim.follow(self.tilt[0], 0.0, 14.0, 1 / self.fps), anim.follow(self.tilt[1], 0.0, 14.0, 1 / self.fps))
        roll += self.tilt[0]
        tip = self.tilt[1]
        lift = (abs(math.sin(math.radians(self.tilt[0]))) * 0.11 + abs(math.sin(math.radians(tip))) * 0.40) * 0.6
        att = skater.att
        feet = lift + BOARD * (1.0 - min(1.0, away * 4))
        with self.measure("figure_points_bail" if skater.bailing else "figure_points"):
            loose = skater.wall is None and not skater.tumbling
            ground = park.height if loose else None
            contact = (body.x, body.y, body.z)
            pos = contact
            rest_feet = contact if ground is not None and att.lying > 0 else None
            boxed = rest_feet is not None and not park.BOWL.over(body.x, body.z)
            att.rest_on(self.figure.settle_shape(), rest_feet, park.surfaces() if boxed else (),
                        figure_module.THICK, figure_module.CLEAR, depth=park.depth, contact=contact, height=feet)
            points, chest, _ahead = self.figure.place(pos, att.R, roll - self.tilt[0] * 0.6, ground,
                                                      normal=att.normal, stand=att.unflipped(), upright=att.standing(),
                                                      unbent=att.unbent(), rebased=att.rebased,
                                                      tumble=skater.tumbling,
                                                      lying=att.lying, fall=att.fall, lift=att.rest_lift(),
                                                      solid=park.depth if skater.bailing or park.PIPE.inside(body.x, body.z, 1.0)
                                                      or park.BOWL.over(body.x, body.z, 1.0) or park.QP.near(body.x, body.z, 1.0)
                                                      else None, base=contact, height=feet, frame=1 / self.fps)
        gap = (bx - body.x, by + lift + self.figure.board_up - body.y, bz - body.z)
        aside = g3drot.back(att.unbent(), (gap[0], 0.0, gap[2]))
        board_pos = self.figure.to_world((aside[0], aside[1] + gap[1], aside[2]))
        board_turn = g3drot.mul(g3drot.about(attitude.UP, turn + away * 60),
                                  g3drot.mul(g3drot.about((1.0, 0.0, 0.0), nose + tip), g3drot.about((0.0, 0.0, 1.0), roll + flip)))
        board_rot = g3drot.euler(g3drot.mul(att.unbent(), board_turn))
        view.draw(self.board, pos=board_pos, rot=board_rot)
        self.board_at = board_pos
        if self.shape is not None and (self.shape[2] == 0.0 or self.frame % SHAPE_EVERY == 0):
            self.log_shape(points, board_rot)
        if skater.trace:
            self.log_grab(points, board_pos, board_rot)
            self.log_drawn(points, chest)
        with self.measure("figure_bones"):
            self.figure.rig.draw(points, face=chest)
        self.dust.draw()
        view.show()
        self.draw_scene(gfx)
    def clear_eye(self, look, eye, seen):
        x, z = look[0], look[2]
        reach, lift = 1.0, 0.0
        if park.BOWL.over(x, z, CAMERA_NEAR) or park.PIPE.inside(x, z, CAMERA_NEAR) or park.QP.near(x, z, CAMERA_NEAR):
            for up in range(0, CAMERA_LIFT + 1):
                hidden = _hidden(seen, (eye[0], eye[1] + up, eye[2]))
                reach, lift = (1.0 if hidden is None else hidden), float(up)
                if reach >= CAMERA_MIN:
                    break
            else:
                reach, lift = CAMERA_MIN, float(CAMERA_LIFT) / CAMERA_MIN
        self.camera_reach = reach if reach < self.camera_reach else anim.follow(self.camera_reach, reach, 3.0, 1 / self.fps)
        self.camera_lift = lift if lift > self.camera_lift else anim.follow(self.camera_lift, lift, 3.0, 1 / self.fps)
        placed = self._place_eye(seen, eye)
        if (self.camera_reach, self.camera_lift) != (reach, lift) and _hidden(seen, placed) is not None:
            self.camera_reach, self.camera_lift = reach, lift
            placed = self._place_eye(seen, eye)
        return placed
    def _place_eye(self, seen, eye):
        eye = (eye[0], eye[1] + self.camera_lift, eye[2])
        return tuple(seen[i] + (eye[i] - seen[i]) * self.camera_reach for i in range(3))
    def leap(self):
        skater = self.skater
        if skater.leap is None:
            return
        takeoff, landing = skater.leap
        skater.leap = None
        name = self.combo.leap(takeoff, landing, park.LEAPS)
        if name is not None:
            self.leaps += 1
            self.last_leap = name
            self.log("leap: %s from=%s to=%s" % (name, takeoff, landing))
    def air_bonus(self):
        skater = self.skater
        if skater.air_result is None:
            return
        height, halves = skater.air_result
        skater.air_result = None
        turns = halves // 2
        points = int(round(height * AIR_POINTS)) * max(1, turns)
        if points > 0:
            self.combo.air(height, turns, points)
            self.air_shown = (height, turns, points)
            self.air_last = (height, turns, points)
            self.air_popup.start()
            self.airshow.land(height, halves / 2.0, points)
    def draw_play(self, gfx):
        combo = self.combo
        self.airshow.draw(gfx)
        gfx.text(24, 18, "%d" % combo.score, 36, WHITE, shadow=SHADOW)
        if self.mode == "timed":
            gfx.text(696, 18, format_time(self.time_left), 36, RED if self.time_left < 10 else WHITE, align="right",
                     shadow=SHADOW)
        else:
            gfx.text(696, 18, "FREE", 36, WHITE, align="right", shadow=SHADOW)
        if combo.active:
            gfx.text(360, 610, combo.names(), 28, WHITE, align="center", shadow=SHADOW)
            gfx.text(360, 650, "%d x %d" % (combo.points, len(combo.parts)), 32, GOLD, align="center", shadow=SHADOW)
        elif self.popup.active and combo.banked is not None:
            names, points, count = combo.banked
            gfx.text(360, 610, names, 28, WHITE, align="center", shadow=SHADOW)
            gfx.text(360, 650, "%d x %d" % (points, count), 32, GOLD, align="center", shadow=SHADOW)
        if self.popup.active:
            gfx.text(360, 205, "+%d" % self.gained, 48, GOLD, align="center", shadow=SHADOW)
        if self.skater.bailing:
            gfx.text(360, 300, "BAIL", 64, RED, align="center", valign="middle", shadow=SHADOW)
    def shown_names(self):
        if self.combo.active:
            return self.combo.names()
        if self.popup.active and self.combo.banked is not None:
            return self.combo.banked[0]
        return None
    def draw_title(self, gfx):
        gfx.text(360, 120, "SKATE", 96, WHITE, align="center", shadow=SHADOW)
        best = self.progress.best[0]
        if best is not None:
            gfx.text(696, 18, "最高点 %d" % best, 28, WHITE, align="right", shadow=SHADOW)
        for row, (label, y) in enumerate((("2 分モード", 330), ("フリーモード", 390))):
            picked = row == self.cursor
            gfx.text(250, y, ("▶ " if picked else "   ") + label, 36, GOLD if picked else DIM, shadow=SHADOW)
        gfx.text(360, 460, "上 / 下: 選ぶ　A: スタート", 28, WHITE, align="center", shadow=SHADOW)
        for i, line in enumerate(("左スティック: 曲がる", "右スティック: 下にためて、はじく", "B: プッシュ", "A: ブレーキ")):
            gfx.text(360, 536 + i * 34, line, 24, DIM, align="center", shadow=SHADOW)
    def draw_result(self, gfx):
        gfx.text(360, 150, "TIME UP", 64, WHITE, align="center", shadow=SHADOW)
        gfx.text(360, 240, "%d" % self.combo.score, 96, GOLD, align="center", shadow=SHADOW)
        best = self.progress.best[0]
        gfx.text(360, 370, "最高点 %d" % (best if best is not None else 0), 32, WHITE, align="center", shadow=SHADOW)
        if self.new_record:
            gfx.text(360, 420, "NEW RECORD", 40, RED, align="center", shadow=SHADOW)
        if self.scene_time >= 1.0:
            gfx.text(360, 560, "A: タイトルへ", 28, WHITE, align="center", shadow=SHADOW)
    def board_spot(self, away):
        skater = self.skater
        body = skater.body
        way = math.radians(skater.att.fall_toward - BOARD_ASIDE)
        dx, dz = math.sin(way), math.cos(way)
        if away <= 0.3:
            return body.x + dx * away, body.y, body.z + dz * away
        floor = park.height(body.x, body.z)
        for part in (1.0, 0.75, 0.5, 0.25, 0.0):
            x, z = body.x + dx * away * part, body.z + dz * away * part
            ground = park.height(x, z)
            if ground - floor <= BOARD_STEP:
                return x, ground, z
        return body.x, body.y, body.z
    def log_pos(self, dt, inp, steer, brake, tumble):
        skater, body = self.skater, self.skater.body
        held = [name for name in ("a", "b", "r1", "up", "down", "left", "right") if inp.down(name)]
        right = inp.stick("right")
        acting = bool(held) or abs(steer) > 0.3 or abs(tumble) > 0.3 or math.hypot(*right) > 0.3
        here = (body.x, body.y, body.z)
        if self.still is None or math.dist(self.still[0], here) > STUCK_MOVE:
            self.still = [here, 0.0, False]
        elif acting:
            self.still[1] += dt
        self.pos_time -= dt
        stuck = self.still[1] >= STUCK_TIME and not self.still[2]
        if self.pos_time > 0.0 and not stuck:
            return
        if self.pos_time <= 0.0:
            self.pos_time = POS_EVERY
        ride = skater.wall
        wall = "-" if ride is None else "%s side=%d s=%.2f u=%.2f w=%.2f vy=%.2f" % (ride.phase, ride.side, ride.s, ride.u, ride.w, ride.vy)
        touching = sorted({box.tag or "box" for box in park.boxes()
                           if box.x0 - 0.3 <= body.x <= box.x1 + 0.3 and box.y0 - 0.1 <= body.y <= box.y1 + 0.1
                           and box.z0 - 0.3 <= body.z <= box.z1 + 0.3})
        line = ("pos=(%.2f,%.2f,%.2f) speed=%.2f heading=%d vy=%.2f grounded=%d wall=[%s] grind=%s bail=%s motion=%s "
                "held=%s steer=%.2f tumble=%.2f right=(%.2f,%.2f) touching=%s still=%.1f" % (
                    body.x, body.y, body.z, skater.speed, round(skater.heading), body.vy, body.grounded, wall,
                    "-" if skater.grind is None else "on", "-" if skater.bail_time is None else "%.2f" % skater.bail_time,
                    self.figure.state, "+".join(held) or "-", steer, tumble, right[0], right[1], ",".join(touching) or "-",
                    self.still[1]))
        if stuck:
            self.still[2] = True
            self.log("stuck: " + line)
        else:
            self.log("pos: " + line)
    def log_drawn(self, points, chest):
        skater, body = self.skater, self.skater.body
        hip, neck = points["hip"], points["neck"]
        spine = [b - a for a, b in zip(hip, neck)]
        bent = sum(a * b for a, b in zip(spine, chest))
        up = _unit3([a - bent * b for a, b in zip(spine, chest)])
        if not skater.flying or skater.bailing:
            if self.drawn is not None and self.drawn["axis"] is not None:
                d = self.drawn
                self.log("drawn: front=%d back=%d off=%d travel=(%.2f,%.2f,%.2f)" % (round(d["front"]), round(d["back"]), round(d["off"]),
                                                                                    *d["travel"]))
            self.drawn = None
            return
        if self.drawn is None:
            if skater.wall is not None:
                travel = skater.wall.world()
            else:
                travel = skater.att.velocity(body.vy)
            travel = _unit3(travel)
            along = sum(a * b for a, b in zip(chest, travel))
            axis = _unit3([a - along * b for a, b in zip(chest, travel)])
            if sum(a * b for a, b in zip(axis, g3drot.cross(up, travel))) < 0:
                axis = tuple(-a for a in axis)
            self.drawn = {"axis": axis if sum(a * a for a in axis) > 0.5 else None, "up": up, "travel": travel,
                          "front": 0.0, "back": 0.0, "off": 0.0}
            return
        d = self.drawn
        axis = d["axis"]
        if axis is None:
            return
        def flat(v):
            along = sum(a * b for a, b in zip(v, axis))
            return _unit3([a - along * b for a, b in zip(v, axis)]), math.degrees(math.asin(max(-1.0, min(1.0, along))))
        (was, was_rise), (now, rise) = flat(d["up"]), flat(up)
        turn = math.degrees(math.atan2(sum(a * b for a, b in zip(g3drot.cross(was, now), axis)), sum(a * b for a, b in zip(was, now))))
        if turn >= 0:
            d["front"] += turn
        else:
            d["back"] += turn
        d["off"] += abs(rise - was_rise)
        d["up"] = up
    def log_grab(self, points, board_pos, board_rot):
        figure = self.figure
        grabbing = figure.state == "grab"
        if not grabbing and self.grab_t is None:
            return
        if not grabbing:
            self.log("grab: end t=%.2f" % self.grab_t)
            self.grab_t = None
            return
        first = self.grab_t is None
        self.grab_t = 0.0 if first else self.grab_t + 1 / self.fps
        if not first and self.frame % SHAPE_EVERY:
            return
        axes = [g3drig.turn(axis, board_rot) for axis in ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))]
        local = {}
        for side in ("front", "back"):
            d = [a - b for a, b in zip(points[side + "_hand"], board_pos)]
            local[side] = tuple(sum(x * y for x, y in zip(d, axis)) for axis in axes)
        near = [side for side, (x, y, z) in local.items() if abs(x) <= GRAB_NEAR[0] and -GRAB_NEAR[1] <= y <= GRAB_NEAR[1] + 0.11
                and abs(z) <= GRAB_NEAR[2]]
        skater = self.skater
        self.log("grab: %s t=%.2f near=%s backward=%d front=(%.2f,%.2f,%.2f) back=(%.2f,%.2f,%.2f) board_up=%.2f "
                 "pitch=%d tilt=%d spin=%d vy=%.2f" % (
                     "start" if first else "hold", self.grab_t, "+".join(near) or "none", figure.backward,
                     *local["front"], *local["back"], figure.board_up, round(skater.att.pitch), round(skater.att.tilt),
                     round(skater.facing()), skater.body.vy))
    def log_shape(self, points, board_rot):
        skater = self.skater
        what, _left, t = self.shape
        att = skater.att
        normal = att.normal
        deck = g3drig.turn((0.0, 1.0, 0.0), board_rot)
        wheels = "down" if sum(a * b for a, b in zip(deck, normal)) > 0 else "up"
        contact = self.figure.contact or ("-", 0.0, 0.0)
        hip = points["hip"]
        board = self.board_at
        self.log("shape: %s t=%.2f rel=%d tumbling=%d lowest=%s depth=%.2f pushed=%.2f wheels=%s tilt=%d hip=(%.2f,%.2f,%.2f) "
                 "board=(%.2f,%.2f,%.2f) board_floor=%.2f" % (
                     what, t, round(att.pitch), att.tumbling, contact[0], contact[1], contact[2], wheels, round(att.tilt),
                     hip[0], hip[1], hip[2], board[0], board[1], board[2], park.height(board[0], board[2])))
    def bail(self):
        self.skater.bail()
        self.bails += 1
        self.flick.reset()
    def save(self):
        self.log(self.flick.summary())
        self.log("tricks: %d landed=%d bails=%d grinds=%d settles=%d" % (self.tricks, self.landed, self.bails, self.grinds,
                                                                       self.skater.att.settles))
    def open_menu(self):
        self.flick.reset()
        super().open_menu()
    def menu_items(self):
        if self.scene == "play":
            return [("やり直す", self.restart), ("タイトルへ", self.to_title)]
        return []
    def debug_state(self):
        skater = self.skater
        body = skater.body
        return {"scene": self.scene, "mode": self.mode, "cursor": self.cursor, "score": self.combo.score,
                "sections": self.shown_sections,
                "combo": self.combo.value, "parts": len(self.combo.parts), "time": round(self.time_left, 2),
                "best": self.progress.best[0], "record": self.new_record, "x": round(body.x, 2), "y": round(body.y, 2), "z": round(body.z, 2), "vy": round(body.vy, 2),
                "speed": round(skater.speed, 2), "heading": round(skater.heading, 1), "air": not skater.grounded,
                "pushes": skater.pushes, "motion": self.figure.state, "mirror": self.figure.backward, "crouch": self.flick.crouch,
                "tricks": self.tricks, "trick": self.trick, "spin": round(skater.facing(), 1), "spun": round(skater.att.spun, 1),"stance": round(skater.stance), "board": round(skater.board_yaw), "bail": skater.bailing,
                "sfx": self.sound.history[-4:], "sfx_count": self.sound.played, "held": self.sound.held(),
                "dust": len(self.dust), "lip_air": skater.lip_air, "grab": skater.grabbing, "grab_time": round(skater.grab_time, 2), "air_shown": list(self.air_shown) if self.air_popup.active else None,
                "air_last": list(self.air_last), "wall": skater.wall_state, "apex": round(skater.apex, 2), "flip": round(skater.flip, 1), "flips": skater.flips, "camera": round(self.camera_angle, 1),
                "tilt": round(skater.att.tilt, 1),
                "landed": self.landed, "bails": self.bails, "grind": skater.grind is not None, "across": skater.across, "edge": skater.grind is not None and skater.grind.out is not None, "grinds": self.grinds,
                "leaps": self.leaps, "leap": self.last_leap, "shown": self.shown_names(), "takeoff": skater.takeoff}
if __name__ == "__main__":
    sys.exit(Skate().run())
