import math
from rgbkit import g3d
GRASS = (112, 150, 84)
TRUNK = (110, 80, 55)
LEAVES = [(52, 105, 60), (64, 120, 58), (44, 92, 66), (78, 128, 62)]
WALLS = [(205, 200, 190), (175, 180, 190), (215, 205, 180), (150, 160, 175), (190, 175, 160)]
ROOF = (120, 122, 128)
GLASS = (90, 115, 150)
GRASS_AREAS = [
    (-160.0, -32.0, -170.0, 170.0), (32.0, 160.0, -170.0, 170.0),
    (-32.0, 32.0, -170.0, -64.0), (-32.0, 32.0, 64.0, 170.0),
]
GRASS_Y = -0.10
ROAD_RIGHT = (36.0, 44.0, -170.0, 170.0)
ROAD_BACK = (-160.0, 36.0, 68.0, 76.0)
WALK = 2.0
WALK_HEIGHT = 0.15
ROAD_Y = -0.04
LINE_Y = -0.02
ASPHALT = (78, 80, 86)
SIDEWALK = (180, 176, 168)
LINE = (235, 235, 225)
POND = (-38.0, 25.0, 10.0, 15.0)
SHORE = 2.0
WATER = (70, 125, 170)
SAND = (196, 182, 140)
POND_Y, SHORE_Y = -0.06, -0.08
WOODS = [
    (-40.0, -23.0, -95.0, 64.0),
    (-23.0, 34.0, -82.0, -66.0),
    (23.0, 34.0, -66.0, 66.0),
]
TREE_STEP = 5.0
CITY = [
    (46.0, 106.0, -100.0, 110.0),
    (-60.0, 30.0, 78.0, 118.0),
]
BLOCK = 15.0
SECTION = 40.0
VIEW_HALF = math.radians(40.0)
WINDOW = ["wwwwwwww",
          "wggwwggw",
          "wggwwggw",
          "wggwwggw",
          "wwwwwwww",
          "wwwwwwww"]
WINDOW_COLORS = {"w": (240, 240, 240), "g": GLASS}
FLOOR = 3.0
def _rand(i, j, k):
    n = (i * 73856093) ^ (j * 19349663) ^ (k * 83492791)
    n = (n ^ (n >> 13)) * 1274126177
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0
def _pyramid(width, height):
    w = width / 2
    vertices = [(-w, 0.0, -w), (w, 0.0, -w), (w, 0.0, w), (-w, 0.0, w), (0.0, height, 0.0)]
    faces = [(0, 1, 4), (1, 2, 4), (2, 3, 4), (3, 0, 4)]
    return g3d.Shape(vertices, faces)
def _prism(width, height):
    shape = g3d.box(width, height, width)
    shape.faces = shape.faces[:4]
    shape.vertices = [(x, y + height / 2, z) for x, y, z in shape.vertices]
    return shape
def _tree(shape, x, z, size, leaves):
    shape.add(_prism(0.4 * size, 1.4 * size), pos=(x, 0.0, z), color=TRUNK)
    shape.add(_pyramid(3.0 * size, 3.6 * size), pos=(x, 1.0 * size, z), rot=(0, 45 * _rand(int(x * 7), int(z * 7), 3), 0),
              color=leaves)
    shape.add(_pyramid(2.1 * size, 3.0 * size), pos=(x, 2.9 * size, z), color=leaves)
def _building(shape, x, z, w, h, d, wall):
    hx, hz = w / 2, d / 2
    sides = [
        ([(-hx, 0, -hz), (hx, 0, -hz), (hx, h, -hz), (-hx, h, -hz)], w),
        ([(hx, 0, hz), (-hx, 0, hz), (-hx, h, hz), (hx, h, hz)], w),
        ([(hx, 0, -hz), (hx, 0, hz), (hx, h, hz), (hx, h, -hz)], d),
        ([(-hx, 0, hz), (-hx, 0, -hz), (-hx, h, -hz), (-hx, h, hz)], d),
    ]
    vertices, uvs, faces = [], [], []
    for corners, width in sides:
        u, v = width / FLOOR, h / FLOOR
        faces.append(tuple(range(len(vertices), len(vertices) + 4)))
        vertices += corners
        uvs += [(0, v), (u, v), (u, 0), (0, 0)]
    faces.append(tuple(range(len(vertices), len(vertices) + 4)))
    vertices += [(-hx, h, -hz), (hx, h, -hz), (hx, h, hz), (-hx, h, hz)]
    uvs += [(0.01, 0.01)] * 4
    body = g3d.Shape(vertices, faces, uvs=uvs)
    shape.add(body, pos=(x, 0.0, z), color=wall)
    if h > 20.0:
        top = g3d.box(w * 0.4, 2.0, d * 0.4)
        top.uvs = [(0.01, 0.01)] * len(top.uvs)
        shape.add(top, pos=(x, h + 1.0, z), color=ROOF)
def _sections(areas, step, put):
    found = {}
    for k, (x0, x1, z0, z1) in enumerate(areas):
        cols, rows = int((x1 - x0) // step), int((z1 - z0) // step)
        for col in range(cols):
            for row in range(rows):
                x, z = x0 + (col + 0.5) * step, z0 + (row + 0.5) * step
                key = (int(x // SECTION), int(z // SECTION))
                shape = found.setdefault(key, g3d.Shape([], []))
                put(shape, col + k * 1000, row, x, z)
    return [shape for shape in found.values() if shape.faces]
def seen(eye, look, center, radius):
    to = [c - e for c, e in zip(center, eye)]
    dist = math.sqrt(sum(v * v for v in to))
    if dist <= radius:
        return True
    sight = [a - e for a, e in zip(look, eye)]
    length = math.sqrt(sum(v * v for v in sight)) or 1.0
    angle = math.acos(max(-1.0, min(1.0, sum(a * b for a, b in zip(to, sight)) / (dist * length))))
    return angle - math.asin(radius / dist) <= VIEW_HALF
def _flat(shape, area, y, color):
    x0, x1, z0, z1 = area
    shape.add(g3d.plane(x1 - x0, z1 - z0), pos=((x0 + x1) / 2, y, (z0 + z1) / 2), color=color)
def _walk(shape, area):
    x0, x1, z0, z1 = area
    shape.add(g3d.box(x1 - x0, WALK_HEIGHT, z1 - z0), pos=((x0 + x1) / 2, WALK_HEIGHT / 2 + ROAD_Y, (z0 + z1) / 2), color=SIDEWALK)
def in_pond(x, z, margin=0.0):
    cx, cz, rx, rz = POND
    return ((x - cx) / (rx + SHORE + margin)) ** 2 + ((z - cz) / (rz + SHORE + margin)) ** 2 < 1.0
def grass_shape():
    shape = g3d.Shape([], [])
    for area in GRASS_AREAS:
        _flat(shape, area, GRASS_Y, GRASS)
    cx, cz, rx, rz = POND
    shape.add(g3d.disc(1.0, 28), pos=(cx, SHORE_Y, cz), scale=(rx + SHORE, 1.0, rz + SHORE), color=SAND)
    shape.add(g3d.disc(1.0, 28), pos=(cx, POND_Y, cz), scale=(rx, 1.0, rz), color=WATER)
    _flat(shape, ROAD_RIGHT, ROAD_Y, ASPHALT)
    _flat(shape, ROAD_BACK, ROAD_Y, ASPHALT)
    rx0, rx1, rz0, rz1 = ROAD_RIGHT
    bx0, bx1, bz0, bz1 = ROAD_BACK
    _walk(shape, (rx1, rx1 + WALK, rz0, rz1))
    _walk(shape, (rx0 - WALK, rx0, rz0, bz0 - WALK))
    _walk(shape, (rx0 - WALK, rx0, bz1 + WALK, rz1))
    _walk(shape, (bx0, rx0, bz0 - WALK, bz0))
    _walk(shape, (bx0, rx0, bz1, bz1 + WALK))
    mid = (rx0 + rx1) / 2
    for z in range(int(rz0), int(rz1), 6):
        if not bz0 - 1.0 < z + 1.5 < bz1 + 1.0:
            _flat(shape, (mid - 0.1, mid + 0.1, z, z + 3.0), LINE_Y, LINE)
    mid = (bz0 + bz1) / 2
    for x in range(int(bx0), int(rx0) - 3, 6):
        _flat(shape, (x, x + 3.0, mid - 0.1, mid + 0.1), LINE_Y, LINE)
    return shape
def wood_shapes():
    def put(shape, i, j, x, z):
        jitter = TREE_STEP * 0.35
        x, z = x + (_rand(i, j, 2) - 0.5) * 2 * jitter, z + (_rand(i, j, 4) - 0.5) * 2 * jitter
        if _rand(i, j, 1) < 0.12 or in_pond(x, z, 2.0):
            return
        _tree(shape, x, z,
              0.8 + 0.7 * _rand(i, j, 5), LEAVES[int(_rand(i, j, 6) * len(LEAVES)) % len(LEAVES)])
    return _sections(WOODS, TREE_STEP, put)
def city_shapes():
    def put(shape, i, j, x, z):
        w = BLOCK * (0.45 + 0.4 * _rand(i, j, 1))
        d = BLOCK * (0.45 + 0.4 * _rand(i, j, 2))
        h = 9.0 + 36.0 * _rand(i, j, 3) ** 2
        _building(shape, x, z, w, h, d, WALLS[int(_rand(i, j, 4) * len(WALLS)) % len(WALLS)])
    return _sections(CITY, BLOCK, put)
