POINTS = {"ollie": 50, "kickflip": 200, "heelflip": 200, "shuvit_left": 150, "shuvit_right": 150}
NAMES = {"ollie": "OLLIE", "kickflip": "KICKFLIP", "heelflip": "HEELFLIP", "shuvit_left": "SHOVE-IT",
         "shuvit_right": "SHOVE-IT"}
SPIN_POINTS = 100
FLIP_POINTS = 500
FLIP_COUNT = {2: "DOUBLE ", 3: "TRIPLE "}
SPIN_SLACK = 40.0
GRIND_POINTS = 100
GRIND_RATE = 100
GRIND = "GRIND"
GRAB = "INDY"
GRAB_POINTS = 300
GRAB_RATE = 200
LEAP_POINTS = {"GAP": 300}
class Combo:
    def __init__(self):
        self.score = 0
        self.parts = []
        self.banked = None
    @property
    def active(self):
        return bool(self.parts)
    @property
    def points(self):
        return int(sum(points for _name, points in self.parts))
    @property
    def value(self):
        return self.points * len(self.parts)
    def trick(self, name):
        self.parts.append([NAMES[name], POINTS[name]])
    def spin(self, degrees):
        halves = int((abs(degrees) + SPIN_SLACK) // 180)
        if halves:
            self.parts.append([str(180 * halves), SPIN_POINTS * halves])
    def flip(self, degrees):
        turns = abs(round(degrees / 360.0))
        if turns:
            name = FLIP_COUNT.get(turns, "%dx " % turns if turns > 3 else "") + ("FRONTFLIP" if degrees > 0 else "BACKFLIP")
            self.parts.append([name, FLIP_POINTS * turns])
    def air(self, height, turns, points):
        self.parts.append(["AIR %.1fm" % height + (" x%d" % turns if turns > 1 else ""), points])
    def grab(self, dt, first):
        if first:
            self.parts.append([GRAB, GRAB_POINTS])
            return
        for part in reversed(self.parts):
            if part[0] == GRAB:
                part[1] += GRAB_RATE * dt
                return
    def leap(self, takeoff, landing, leaps):
        for name, start, end in leaps:
            if start == takeoff and end == landing:
                self.parts.append([name, LEAP_POINTS[name]])
                return name
        return None
    def grind(self):
        self.parts.append([GRIND, GRIND_POINTS])
    def grinding(self, dt):
        if self.parts and self.parts[-1][0] == GRIND:
            self.parts[-1][1] += GRIND_RATE * dt
    def bank(self):
        gained = self.value
        self.score += gained
        self.banked = (self.names(), self.points, len(self.parts))
        self.parts = []
        return gained
    def drop(self):
        self.parts = []
    def names(self):
        return " + ".join(name for name, _points in self.parts)
