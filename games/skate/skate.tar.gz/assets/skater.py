import math
from rgbkit import anim, g3dbody, g3drot
import park
import pipe
import attitude
from attitude import Attitude
WIDTH = 0.5
TRICK_TIME = 0.4
SPIN_SLACK = 40.0
BAIL_TIME = 1.5
RAIL_OFF = WIDTH / 2 + park.RAIL_WIDTH / 2 + 0.05
EDGE_CATCH = 0.45
EDGE_RIDE = 0.2
EDGE_ALONG = math.cos(math.radians(45.0))
EDGE_SPEED = 1.5
MAGNET = 2.5
MAGNET_REACH = 0.7
TURN_EVERY = 0.05
WALL_TURN = 1.0
TRICKS = {"ollie": (0.0, 0.0), "kickflip": (360.0, 0.0), "heelflip": (-360.0, 0.0),
          "shuvit_left": (0.0, -180.0), "shuvit_right": (0.0, 180.0)}
def spin_halves(degrees):
    return int((abs(degrees) + SPIN_SLACK) // 180.0)
class Grind:
    def __init__(self, box, axis, line, out):
        self.box, self.axis, self.line, self.out = box, axis, line, out
    def hold(self, body):
        if self.axis == "x":
            body.z = self.line
        else:
            body.x = self.line
    def pull(self, body, amount):
        box = self.box
        if body.y < box.y1 - 0.05:
            return
        if self.axis == "x":
            if box.x0 <= body.x <= box.x1 and abs(self.line - body.z) <= MAGNET_REACH:
                body.z += max(-amount, min(amount, self.line - body.z))
        elif box.z0 <= body.z <= box.z1 and abs(self.line - body.x) <= MAGNET_REACH:
            body.x += max(-amount, min(amount, self.line - body.x))
    def drop(self, body):
        if self.axis == "x":
            body.z = self.line + (RAIL_OFF if body.z >= self.line else -RAIL_OFF)
        else:
            body.x = self.line + (RAIL_OFF if body.x >= self.line else -RAIL_OFF)
        body.release()
class Skater:
    def __init__(self, boxes):
        self.boxes = boxes
        self.open_boxes = [box for box in boxes if box.tag not in ("pipe_step", "pipe_back")]
        self.body = g3dbody.Body(width=WIDTH, height=1.6, gravity=attitude.GRAVITY, jump_speed=attitude.POP, edge=None)
        self.pushes = 0
        self.flips = 0
        self.trace = False
        self.turn_time = None
        self.turn_noted = 0.0
        self.notes = []
        self.rails = [Grind(box, "x" if box.size[0] > box.size[2] else "z",
                            box.center[2] if box.size[0] > box.size[2] else box.center[0], None)
                      for box in boxes if park.is_rail(box)]
        self.place(*park.SPOTS["start"])
    def place(self, x, z, heading, speed=0.0):
        self.body.floor = park.floor_at(x, z)
        self.body.place((x, self.body.floor, z))
        self.steer = 0.0
        self.board_yaw = 0.0
        self.trick = None
        self.trick_time = 0.0
        self.bail_time = None
        self.grind = None
        self.before = 0.0
        self.sliding = 0.0
        self.why = ""
        self.flying = False
        self.wall = None
        self.apex = 0.0
        self.lip_top = 0.0
        self.att = Attitude(heading, speed)
        self.lip_air = False
        self.launch_speed = 0.0
        self.grabbing = False
        self.grab_time = 0.0
        self.air_result = None
        self.takeoff = None
        self.leap = None
    @property
    def heading(self):
        return self.att.heading
    @property
    def speed(self):
        return self.att.speed
    @property
    def grounded(self):
        return self.body.grounded
    @property
    def bailing(self):
        return self.bail_time is not None
    @property
    def flip(self):
        return self.att.pitch
    @property
    def air_flip(self):
        return self.att.landed_pitch
    @property
    def tumbling(self):
        return self.att.tumbling
    @property
    def air_turn(self):
        return self.att.spun
    @property
    def stance(self):
        return self.att.stance
    def travel(self):
        if self.wall is not None:
            return self.wall.world()
        return self.att.ground_travel()
    def facing(self):
        return self.att.facing(self.travel())
    def note(self, result):
        if self.trace:
            extra = "spin=%d" % round(self.air_turn)
            if self.lip_air or self.air_result is not None:
                extra += " launch=%.1f height=%.2f grab=%.2f%s" % (self.launch_speed, self.lip_height(), self.grab_time,
                                                                  " grabbing" if self.grabbing else "")
            self.notes.append(self.att.summary("%s %s" % (extra, result)))
    def grind_note(self, what):
        if self.trace and self.grind is not None:
            grind = self.grind
            self.notes.append("grind: %s box=%s line=%s@%.2f edge=%s speed=%.1f x=%.2f z=%.2f" % (
                what, grind.box.tag, grind.axis, grind.line, "ledge" if grind.out is not None else "rail", self.speed,
                self.body.x, self.body.z))
    @property
    def wall_state(self):
        if self.wall is None or self.wall.phase != "wall":
            return None
        return "up" if self.wall.u > 0 else "down"
    def wall_tilt(self):
        return self.att.tilt
    @property
    def across(self):
        return self.grind is not None and self.att.stance % 180.0 == 90.0
    @property
    def turning(self):
        return self.trick is not None and self.trick_time < TRICK_TIME and TRICKS[self.trick] != (0.0, 0.0)
    def board_turn(self):
        if self.trick is None:
            return 0.0, self.board_yaw
        roll, yaw = TRICKS[self.trick]
        t = min(1.0, self.trick_time / TRICK_TIME)
        return roll * t, self.board_yaw + yaw * t
    def push(self):
        if not self.grounded or self.bailing or self.grind is not None or self.wall is not None:
            return False
        self.att.push()
        self.pushes += 1
        return True
    def pop(self, trick="ollie"):
        if self.bailing:
            return False
        if self.wall is not None and self.wall.ramp:
            vy = self.att.leave_wall(self.att.jump_off(self.wall.normal()))
            self.wall = None
            self.body.release()
            self.body.vy = vy
            self.trick, self.trick_time = trick, 0.0
            return True
        if self.wall is not None:
            if self.wall.phase != "wall" or self.wall.u <= 0:
                return False
            self.att.wall_pop(self.wall.normal())
            self.trick, self.trick_time = trick, 0.0
            return True
        if not self.grounded or self.body.jump() == 0:
            return False
        self.trick, self.trick_time = trick, 0.0
        return True
    def find_grind(self, box, catch=EDGE_CATCH):
        if box is g3dbody.FLOOR:
            return None
        body = self.body
        if park.is_rail(box):
            along_x = box.size[0] > box.size[2]
            return Grind(box, "x" if along_x else "z", box.center[2] if along_x else box.center[0], None)
        if self.speed < EDGE_SPEED:
            return None
        angle = math.radians(self.heading)
        found = None
        if abs(math.sin(angle)) >= EDGE_ALONG:
            for line, out in ((box.z0, (0.0, -1.0)), (box.z1, (0.0, 1.0))):
                far = abs(body.z - line)
                if far <= catch and (found is None or far < found[0]):
                    found = (far, Grind(box, "x", line, out))
        if abs(math.cos(angle)) >= EDGE_ALONG:
            for line, out in ((box.x0, (-1.0, 0.0)), (box.x1, (1.0, 0.0))):
                far = abs(body.x - line)
                if far <= catch and (found is None or far < found[0]):
                    found = (far, Grind(box, "z", line, out))
        return found[1] if found else None
    def start_grind(self, grind):
        self.att.enter_grind(grind.axis)
        self.att.align(self.travel(), 90.0)
        self.grind = grind
        grind.hold(self.body)
        self.grind_note("enter")
    def bail(self):
        self.lip_air, self.air_result = False, None
        self.grabbing = False
        self.grind_note("leave bail")
        self.bail_time = 0.0
        self.trick, self.steer, self.grind = None, 0.0, None
        self.att.unwind = None
        self.att.crash(self.travel())
    def fly(self, dt, steer, tumble=0.0):
        self.steer = 0.0
        if not self.flying:
            self.flying, self.apex = True, self.body.y
            self.lip_air = False
            self.att.take_off(self.att.velocity(self.body.vy), tumble)
        if abs(tumble) > abs(steer):
            steer = 0.0
        else:
            tumble = 0.0
        self.att.fly(dt, tumble)
        self.att.spin(dt, steer, self.travel())
        if self.wall is not None:
            self.att.follow(dt, self.wall.world(), self.wall.w)
        self.trick_time += dt
    def fault(self):
        if self.turning:
            return "board speed=%.1f" % self.speed
        if self.grabbing:
            return "grab time=%.2f" % self.grab_time
        return self.att.fault()
    def landed(self):
        if self.trick is not None:
            self.board_yaw = (self.board_yaw + TRICKS[self.trick][1]) % 360.0
        self.trick = None
        turns = abs(self.att.landed())
        self.flips += turns
        if self.lip_air:
            self.air_result = (round(self.lip_height(), 1), turns * 2 + spin_halves(self.air_turn))
            self.lip_air = False
    def air_halves(self):
        return int(abs(self.att.pitch) // 180.0) + spin_halves(self.air_turn)
    def lip_height(self):
        return max(0.0, self.apex - self.lip_top)
    def ride(self, ride):
        self.wall = ride
        self.grind = None
        self.steer = 0.0
    def update_pipe(self, dt, steer, tumble=0.0, grab=False):
        body = self.body
        ride = self.wall
        happened = []
        if ride.phase == "air":
            self.fly(dt, steer, tumble)
            self.grabbing = grab and self.lip_air and not self.bailing
            if self.grabbing:
                self.grab_time += dt
            what = ride.update(body, dt)
        else:
            self.steer = 0.0
            what = ride.update(body, dt, falling=self.bailing)
            if self.bailing:
                self.att.crash_step(dt, self.bail_time / BAIL_TIME, (self.bail_time + dt) / BAIL_TIME)
                self.bail_time += dt
                if self.bail_time >= BAIL_TIME:
                    self.bail_time = None
                    self.att.stand()
                    happened.append("up")
            if self.trick is not None and ride.phase == "wall" and ride.u <= 0:
                self.landed()
        if what in ("bottom", "deck"):
            self.att.to_floor()
        else:
            self.att.unfold(ride.normal(), ride.out, ride.lat(), ride.phase == "air")
        normal = ride.normal()
        if what == "launch":
            body.grounded = False
            body.vy = ride.vy
            self.flying, self.apex = True, body.y
            self.lip_air = True
            self.launch_speed = ride.vy
            self.lip_top = ride.surface.top
            self.grab_time = 0.0
            self.att.carry(normal)
            self.att.take_off(ride.world(), tumble, lip=True)
        elif what == "attach":
            body.grounded = True
            self.flying = False
            self.att.unwind = None
            self.att.touch(normal)
            why = self.fault()
            if why:
                self.why = "wall " + why
                self.note("bail " + self.why)
                self.bail()
                happened.append("bail")
            else:
                self.note("land wall")
                self.landed()
                happened.append("wall")
        elif what in ("bottom", "deck"):
            self.wall = None
            body.floor = ride.surface.floor if what == "bottom" else ride.surface.top
            body.place((body.x, body.floor, body.z))
            happened.append(what)
        elif what == "out":
            vy = self.att.leave_wall(ride.world())
            self.wall = None
            self.att.expect(attitude.UP)
            if body.grounded:
                body.release()
            body.vy = vy
        if self.wall is not None and ride.phase == "air":
            body.vy = ride.vy
            self.apex = max(self.apex, body.y)
            self.att.carry(normal)
        elif self.wall is not None:
            self.att.on_surface(dt, normal, ride.world() if self.speed > WALL_TURN else None,
                                "bail" if self.bailing else "wall")
        return happened
    def update(self, dt, steer, brake, tumble=0.0, grab=False):
        self.att.begin_frame()
        face = self.face()
        if face is not None:
            self.takeoff = face
        happened = self.update_pipe(dt, steer, tumble, grab) if self.wall is not None else self.update_open(dt, steer, brake, tumble)
        if self.trace and self.att.air:
            self.note_turn(dt, steer, tumble)
        else:
            self.turn_time = None
        jump = self.att.frame_jump(dt)
        if jump is not None and self.trace:
            amount, moves = jump
            body = self.body
            self.notes.append("jump: angle=%d dt=%.3f moves=%s pos=(%.2f,%.2f,%.2f) wall=%s bail=%d air=%d" % (
                round(amount), dt, ",".join("%s:%d" % (why, round(deg)) for why, deg in moves) or "-",
                body.x, body.y, body.z, "-" if self.wall is None else self.wall.phase, self.bailing, self.att.air))
        return happened
    def face(self):
        if self.wall is not None:
            if self.wall.phase == "air":
                return None
            return self.wall.surface.name
        if self.grind is not None:
            return self.grind.box.tag
        if not self.grounded:
            return None
        return "floor" if self.body.surface is g3dbody.FLOOR else self.body.surface.tag
    def note_turn(self, dt, steer, tumble):
        first = self.turn_time is None
        self.turn_time = 0.0 if first else self.turn_time + dt
        if not first and self.turn_time - self.turn_noted < TURN_EVERY - 1e-6:
            return
        self.turn_noted = self.turn_time
        att = self.att
        amount, axis = att.frame_turn()
        rate = amount / dt if dt > 0 else 0.0
        travel = g3drot.unit(self.travel()) or (0.0, 0.0, 0.0)
        self.notes.append("turn: t=%.2f stick=(%.2f,%.2f) rate=%d axis=(%s) up=(%.2f,%.2f,%.2f) chest=(%.2f,%.2f,%.2f) "
                          "fwd=(%.2f,%.2f,%.2f) pitch=%d spun=%d flip_axis=(%.2f,%.2f,%.2f) travel=(%.2f,%.2f,%.2f) pos=(%.2f,%.2f,%.2f)" % (
                              self.turn_time, steer, tumble, round(rate), "-" if axis is None else "%.2f,%.2f,%.2f" % axis,
                              *att.up(), *att.chest(), *att.forward(), round(att.pitch), round(att.spun), *att.axis, *travel,
                              self.body.x, self.body.y, self.body.z))
    def update_open(self, dt, steer, brake, tumble):
        self.grabbing = False
        body = self.body
        happened = []
        if self.grind is not None and not (self.grounded and body.surface is self.grind.box):
            self.att.unwind = self.before if self.att.stance % 180.0 == 90.0 else None
            self.grind_note("leave off")
            self.grind = None
        if self.bailing:
            self.att.crash_step(dt, self.bail_time / BAIL_TIME, (self.bail_time + dt) / BAIL_TIME)
            if self.grounded:
                self.att.on_surface(dt, attitude.UP, None, "bail")
                self.flying = False
            self.bail_time += dt
            self.att.sliding_down(dt)
            if self.bail_time >= BAIL_TIME:
                self.bail_time = None
                self.att.stand()
                self.att.stop()
                happened.append("up")
        elif self.grind is not None:
            self.steer = 0.0
            self.att.grinding(dt)
            self.att.on_surface(dt, attitude.UP, self.travel(), "grind")
            self.grind.hold(body)
        elif self.grounded:
            self.steer = steer
            turned = self.att.steer(dt, steer)
            self.att.on_surface(dt, attitude.UP, self.travel(), "ground", steered=turned)
            self.sliding = self.att.roll(dt, brake)
            if body.surface is not g3dbody.FLOOR and not park.is_rail(body.surface):
                grind = self.find_grind(body.surface, EDGE_RIDE)
                if grind is not None:
                    if self.att.stance % 180.0 == 0.0:
                        self.before = self.att.stance
                    self.start_grind(grind)
                    happened.append("grind")
        else:
            self.fly(dt, steer, tumble)
            if body.vy < 0:
                for rail in self.rails:
                    rail.pull(body, MAGNET * dt)
        boxes = self.open_boxes if park.PIPE.inside(body.x, body.z) else self.boxes
        body.floor = park.floor_at(body.x, body.z)
        events, heading, speed, hit = body.glide(dt, boxes, self.heading, self.speed, bounce=attitude.BOUNCE)
        self.att.glided(heading, speed)
        if hit is not None:
            why = self.att.collide(*hit, self.grind is not None, self.bailing)
            if why:
                self.why = why
                if self.flying:
                    self.note("bail " + self.why)
                self.bail()
                happened.append("bail")
        flew = self.flying
        ride = next((found for found in (pipe.enter(surface, body, self.att) for surface in park.CURVES) if found), None)
        if ride is not None:
            self.ride(ride)
            normal = ride.normal()
            if flew:
                self.att.touch(normal)
                if self.bailing:
                    self.att.crash()
            else:
                self.att.carry(normal)
            if flew and not self.bailing:
                self.flying = False
                self.att.unwind = None
                why = self.fault()
                if why:
                    self.why = "wall " + why
                    self.note("bail " + self.why)
                    self.bail()
                    happened.append("bail")
                else:
                    self.note("land wall")
                    self.landed()
                    happened.append("wall")
            return happened
        if not self.grounded:
            self.apex = max(self.apex, body.y)
        landing = next((event for event in events if event.kind == "land"), None)
        if landing is not None and not self.bailing:
            self.att.unwind = None
            self.flying = False
            if self.att.stance % 180.0 == 0.0:
                self.before = self.att.stance
            grind = self.find_grind(landing.box)
            off = (self.att.yaw(self.travel()) + 90.0) % 180.0 - 90.0
            self.att.touch(attitude.UP)
            why = self.fault()
            if why:
                self.why = "%s angle=%d" % (why, round(off))
                self.note("bail " + self.why)
                self.bail()
                happened.append("bail")
                if grind is not None and grind.out is None:
                    grind.drop(body)
            else:
                self.att.align(self.travel(), 180.0)
                self.note("land")
                self.landed()
                self.leap = (self.takeoff, "floor" if landing.box is g3dbody.FLOOR else landing.box.tag)
                if grind is None:
                    happened.append("land")
                else:
                    self.start_grind(grind)
                    happened.append("grind")
        return happened
