import sys
import rules
import stage
from rgbkit import HEIGHT, WIDTH, Game, Progress, format_time, g3d, g3dstick
WHITE = (255, 255, 255)
DARK = (20, 30, 50)
YELLOW = (255, 225, 90)
FOV = 70
STAGES = stage.STAGES
JUMP_BUFFER = 0.1
LOOK_DOWN = 60.0
LOOK_DOWN_SPEED = 150.0
LOOK_BACK_SPEED = 240.0
GOAL_WAIT = 1.5
HINT_SECONDS = 6.0
SHADOW_STRENGTH = 0.8
SAVE_FILE = "save.json"
BEST_MIN = 0.1
GOAL_COLOR = (245, 245, 245)
GRASS_COLORS = {"g": (95, 170, 95), "d": (70, 140, 75)}
EDGED_COLORS = {"w": (255, 255, 255), "e": (150, 150, 150)}
SPRING_COLORS = {"p": (255, 80, 130), "y": (255, 235, 90), "e": (150, 40, 70)}
GRASS = ["dddddddddddddddd"] + ["dggggggggggggggg"] * 15
EDGED = ["eeeeeeeeeeeeeeee"] + ["ewwwwwwwwwwwwwwe"] * 14 + ["eeeeeeeeeeeeeeee"]
MOVING = ["eeeeeeeeeeeeeeee", "ewwwwwwwwwwwwwwe", "ewwwwwwwwwwwwwwe", "ewweeeeeeeeeewwe"] + \
         ["ewwewwwwwwwwewwe"] * 8 + ["ewweeeeeeeeeewwe", "ewwwwwwwwwwwwwwe", "ewwwwwwwwwwwwwwe", "eeeeeeeeeeeeeeee"]
SPRING = ["eeeeeeeeeeeeeeee",
          "eppppppppppppppe",
          "eppppppyyppppppe",
          "epppppyyyypppppe",
          "eppppyyppyyppppe",
          "epppyyppppyypppe",
          "eppyyppppppyyppe",
          "eppppppppppppppe",
          "eppppppyyppppppe",
          "epppppyyyypppppe",
          "eppppyyppyyppppe",
          "epppyyppppyypppe",
          "eppyyppppppyyppe",
          "eppppppppppppppe",
          "eppppppppppppppe",
          "eeeeeeeeeeeeeeee"]
def pad_color(level, pad):
    if pad is level.goal:
        return GOAL_COLOR
    t = (pad.number - 1) / max(1, len(level.pads) - 2) * (len(level.colors) - 1)
    index = min(int(t), len(level.colors) - 2)
    return tuple(int(a + (b - a) * (t - index)) for a, b in zip(level.colors[index], level.colors[index + 1]))
def flag_shape():
    return g3d.Shape([(0, 0, 0), (1.3, -0.4, 0), (0, -0.8, 0)], [(0, 1, 2), (0, 2, 1)])
def old_save(data):
    if not isinstance(data, dict):
        return data
    data = dict(data)
    if type(data.get("best")) in (int, float):
        data["best"] = [data["best"]]
        if type(data.get("unlocked")) is not int:
            data["unlocked"] = 2
    if "stage" in data:
        chosen = data.pop("stage")
        if "selected" not in data and type(chosen) is int:
            data["selected"] = chosen - 1
    return data
class SkyJump(Game):
    title = "スカイジャンプ"
    background = STAGES[0].sky
    save_with_command = False
    log_scenes = True
    uses_3d = True
    web_keyboard = {}
    web_touch_layout = {}
    web_sound_band = (300, 6000)
    def controls(self):
        return {"dpad", "a", "b", "start", "left_stick", "right_stick"}
    def start(self):
        view = self.view = g3d.View(self)
        cube = g3d.box(1, 1, 1)
        self.ground = view.mesh(g3d.plane(stage.GROUND, stage.GROUND, cells=10),
                                texture=view.texture_rows(GRASS, GRASS_COLORS))
        plain = view.mesh(cube, texture=view.texture_rows(EDGED, EDGED_COLORS))
        moving = view.mesh(cube, texture=view.texture_rows(MOVING, EDGED_COLORS))
        spring = view.mesh(cube, texture=view.texture_rows(SPRING, SPRING_COLORS))
        self.looks = [[(spring, None) if pad.bounce else (moving if pad.to else plain, pad_color(level, pad))
                       for pad in level.pads] for level in STAGES]
        self.pole = view.mesh(g3d.box(0.12, stage.POLE, 0.12), color=(230, 230, 235))
        self.flag = view.mesh(flag_shape(), color=(230, 60, 60))
        view.light((0.4, -1.0, 0.6), ambient=0.55)
        self.walker = g3dstick.Walker(self, speed=rules.WALK_SPEED)
        self.body = rules.new_body()
        for name in ("jump1", "jump2", "land", "goal", "bounce"):
            self.sound.load("sounds/%s.wav" % name)
        self.progress = Progress(self, len(STAGES), name=SAVE_FILE, low=BEST_MIN, migrate=old_save)
        self.new_best = False
        self.spin = 0.0
        self.jump_count = 0
        self.bounce_count = 0
        self.select(self.progress.selected)
        self.enter("title")
    def select(self, index):
        self.index = self.progress.selected = index
        self.level = level = STAGES[index]
        self.background = level.sky
        self.view.background(level.sky)
        self.view.fog(level.sky, *level.fog)
        self.reset()
    def reset(self, pad=None, yaw=None):
        level, body = self.level, self.body
        level.place(0.0)
        if pad is None:
            body.place((level.start[0], 0.0, level.start[1]))
            yaw = level.start_yaw if yaw is None else yaw
        else:
            box = level.boxes[pad.number - 1]
            body.place((pad.x, pad.top, pad.z), **({} if pad.bounce else {"on": box}))
            if yaw is None:
                after = level.pads[min(pad.number, len(level.pads) - 1)]
                yaw = stage.facing(pad, after) if after is not pad else 0.0
        walker = self.walker
        walker.yaw, walker.pitch = yaw % 360, 0.0
        body.follow(walker)
        self.time = 0.0
        self.tilt = 0.0
        self.want_jump = 0.0
        self.bounced = False
        self.new_best = False
    def start_play(self):
        self.reset()
        self.enter("play")
    def hidden_command(self, text):
        values = self.command_values()
        if values.flag("unlock"):
            self.progress.unlocked = len(STAGES)
        number = values.int("stage", 1, len(STAGES))
        if number is not None:
            self.select(number - 1)
        pads = self.level.pads
        pad = values.int("pad", 0, len(pads))
        if values.flag("goal"):
            pad = len(pads) - 1
        yaw = values.float("angle")
        if number is not None or pad is not None:
            self.reset(pads[pad - 1] if pad else None, yaw)
            self.enter("play")
        elif yaw is not None:
            self.walker.yaw = yaw % 360
    def update(self, dt):
        self.spin = (self.spin + 20 * dt) % 360
        super().update(dt)
    def update_title(self, dt):
        inp = self.input
        self.level.advance(dt)
        if inp.tapped("a"):
            self.start_play()
        elif inp.tapped("left") and self.index > 0:
            self.select(self.index - 1)
        elif inp.tapped("right") and self.index + 1 < self.progress.unlocked:
            self.select(self.index + 1)
    def update_play(self, dt):
        inp, body, level = self.input, self.body, self.level
        self.time += dt
        if inp.pressed("b") and inp.only("b"):
            self.want_jump = JUMP_BUFFER
        if self.want_jump > 0:
            number = body.jump()
            if number:
                self.want_jump = 0.0
                self.jump_count += 1
                self.sound.play("sounds/jump%d.wav" % number, volume=0.6)
            else:
                self.want_jump -= dt
        for event in body.walk(self.walker, dt, level.boxes, level.movers, self.on_land):
            if event.kind == "land":
                self.bounced = False
                if event.box is level.goal_box:
                    self.goal()
                    return
                if event.speed > 3:
                    self.sound.play("sounds/land.wav", volume=min(1.0, 0.25 + event.speed / body.max_fall * 0.75))
        if not body.grounded and (body.jumps_used >= body.jumps or (self.bounced and body.vy < 0)):
            self.tilt = g3dstick.approach(self.tilt, LOOK_DOWN, LOOK_DOWN_SPEED * dt)
        else:
            self.tilt = g3dstick.approach(self.tilt, 0.0, LOOK_BACK_SPEED * dt)
    def on_land(self, body, box, speed):
        if not box.tag.bounce:
            return True
        body.bounce(box.tag.bounce)
        self.bounced = True
        self.want_jump = 0.0
        self.bounce_count += 1
        self.sound.play("sounds/bounce.wav", volume=0.7)
        return False
    def update_goal(self, dt):
        if self.input.tapped("a", since=self.entered, wait=GOAL_WAIT):
            if self.index + 1 < len(STAGES):
                self.select(self.index + 1)
                self.enter("play")
            else:
                self.enter("title")
    def goal(self):
        self.sound.play("sounds/goal.wav", volume=0.8)
        self.log("goal: stage=%d time=%.2f" % (self.index + 1, self.time))
        self.new_best = self.progress.record(self.index, self.time)
        self.progress.unlock(self.index + 2)
        self.progress.save()
        self.enter("goal")
    def restart(self):
        self.confirm("最初からやり直しますか？", self.start_play, lines=["タイムは 0 に戻ります"])
    def menu_items(self):
        items = [("最初からやり直す", self.restart)] if self.scene in ("play", "goal") else []
        return items + self.walker.menu_items()
    def save(self):
        self.progress.save()
    def draw(self, gfx):
        view, body, level = self.view, self.body, self.level
        goal = level.goal
        if self.scene == "title":
            view.orbit((0, goal.top * 0.47, 0), radius=goal.top, height=goal.top * 0.18, angle=self.spin, fov=FOV)
        elif self.scene == "goal":
            view.orbit((goal.x, goal.top + 1.8, goal.z), radius=7, height=1.4, angle=self.spin * 2, fov=FOV)
        else:
            self.walker.aim(view, fov=FOV, pitch=-self.tilt)
        view.draw(self.ground, color=level.ground)
        for (mesh, color), box in zip(self.looks[self.index], level.boxes):
            view.draw(mesh, pos=box.center, scale=box.size, color=color)
        view.draw(self.pole, pos=(goal.x, goal.top + stage.POLE / 2, goal.z))
        view.draw(self.flag, pos=(goal.x, goal.top + stage.POLE, goal.z), rot=(0, self.spin * 3, 0))
        if self.scene == "play":
            top = body.below(level.boxes)
            size = max(0.3, 0.9 - (body.y - top) * 0.06)
            view.shadow((body.x, top, body.z), radius=size / 2, strength=SHADOW_STRENGTH)
        view.show()
        self.draw_scene(gfx)
    def draw_title(self, gfx):
        best = self.progress.best[self.index]
        gfx.text(WIDTH // 2, 110, "スカイジャンプ", 84, align="center", shadow=DARK)
        gfx.text(WIDTH // 2, 400, self.level.name, 44, align="center", shadow=DARK)
        if self.index > 0:
            gfx.text(WIDTH // 2 - 190, 400, "<", 44, YELLOW, align="center", shadow=DARK)
        if self.index + 1 < self.progress.unlocked:
            gfx.text(WIDTH // 2 + 190, 400, ">", 44, YELLOW, align="center", shadow=DARK)
        gfx.text(WIDTH // 2, 462, "ベスト  " + (format_time(best) if best is not None else "-"), 28, align="center",
                 shadow=DARK)
        gfx.text(WIDTH // 2, 530, "A: スタート", 40, YELLOW, align="center", shadow=DARK)
        if self.progress.unlocked > 1:
            gfx.text(WIDTH // 2, HEIGHT - 120, "十字キーの左右: ステージを選ぶ", 22, align="center", shadow=DARK)
        gfx.text(WIDTH // 2, HEIGHT - 84, "左スティック: 移動   右スティック: 視線   B: ジャンプ", 22, align="center",
                 shadow=DARK)
    def draw_play(self, gfx):
        gfx.text(20, 14, format_time(self.time), 34, shadow=DARK)
        gfx.text(WIDTH // 2, 16, self.level.name, 24, align="center", shadow=DARK)
        gfx.text(WIDTH - 20, 14, "高さ %d / %d" % (round(self.body.y), round(self.level.goal.top)), 28, align="right",
                 shadow=DARK)
        cx, cy = WIDTH // 2, HEIGHT // 2
        gfx.rect(cx - 7, cy - 1, 14, 2, WHITE)
        gfx.rect(cx - 1, cy - 7, 2, 14, WHITE)
        if self.time < HINT_SECONDS:
            gfx.text(WIDTH // 2, HEIGHT - 60, "B: ジャンプ（空中で、もう 1 回）", 26, align="center", shadow=DARK)
    def draw_goal(self, gfx):
        best = self.progress.best[self.index]
        gfx.text(WIDTH // 2, 100, "GOAL", 110, YELLOW, align="center", shadow=DARK)
        gfx.text(WIDTH // 2, 250, self.level.name, 30, align="center", shadow=DARK)
        gfx.text(WIDTH // 2, 300, "タイム  " + format_time(self.time), 44, align="center", shadow=DARK)
        if self.new_best:
            gfx.text(WIDTH // 2, 370, "NEW  ベストタイム", 32, YELLOW, align="center", shadow=DARK)
        elif best is not None:
            gfx.text(WIDTH // 2, 370, "ベスト  " + format_time(best), 30, align="center", shadow=DARK)
        if self.scene_time >= GOAL_WAIT:
            after = "A: 次のステージへ" if self.index + 1 < len(STAGES) else "A: タイトルへ"
            gfx.text(WIDTH // 2, HEIGHT - 80, after, 32, align="center", shadow=DARK)
    def debug_state(self):
        walker, body, level = self.walker, self.body, self.level
        below = body.under(level.boxes)
        under = below.tag.number if below in level.boxes else 0
        on = body.surface
        return {"x": round(body.x, 2), "y": round(body.y, 2), "z": round(body.z, 2),
                "vy": round(body.vy, 2), "yaw": round(walker.yaw, 1), "pitch": round(walker.pitch, 1), "tilt": round(self.tilt, 1),
                "air": not body.grounded, "jumps": body.jumps_used, "jump_count": self.jump_count,
                "bounce_count": self.bounce_count, "pad": 0 if isinstance(on, str) else on.tag.number, "under": under,
                "time": round(self.time, 2), "stage": self.index + 1, "unlocked": self.progress.unlocked,
                "best": [value and round(value, 2) for value in self.progress.best]}
if __name__ == "__main__":
    sys.exit(SkyJump().run())
