from rgbkit import g3dbody
GROUND = 40.0
EDGE = GROUND / 2 - 0.5
WALK_SPEED = 5.0
BOUNCE_SPEED = 17.0
def new_body():
    return g3dbody.Body(width=0.7, height=1.5, eye=1.2, gravity=18.0, jump_speed=10.0, jumps=2, max_fall=20.0,
                        coyote=0.1, air_control=1.0, floor=0.0, edge=EDGE)
