import math
from rgbkit import g3dbody
from rules import BOUNCE_SPEED, GROUND
THICK = 0.6
POLE = 3.0
def polar(angle, radius, top, size):
    return (radius * math.sin(math.radians(angle)), radius * math.cos(math.radians(angle)), top, size, size)
def mover(row, to, period=5.0, phase=0.0):
    return tuple(row) + ({"to": to, "period": period, "phase": phase},)
def spring(row):
    return tuple(row) + ({"bounce": BOUNCE_SPEED},)
class Pad:
    def __init__(self, number, x, z, top, w, d, extra=None):
        extra = extra or {}
        self.number = number
        self.x, self.z, self.top, self.w, self.d = float(x), float(z), float(top), float(w), float(d)
        self.to = extra.get("to")
        self.period = extra.get("period", 0.0)
        self.phase = extra.get("phase", 0.0)
        self.bounce = extra.get("bounce", 0.0)
class Stage:
    def __init__(self, name, rows, start, start_yaw, sky, fog, colors, ground, margin):
        self.name = name
        self.pads = [Pad(number, *row) for number, row in enumerate(rows, 1)]
        self.boxes = [g3dbody.Box.at((pad.x, pad.top - THICK / 2, pad.z), (pad.w, THICK, pad.d), tag=pad)
                      for pad in self.pads]
        self.movers = [g3dbody.Mover(box, to=pad.to, period=pad.period, phase=pad.phase)
                       for pad, box in zip(self.pads, self.boxes) if pad.to]
        self.goal, self.goal_box = self.pads[-1], self.boxes[-1]
        self.start, self.start_yaw = start, start_yaw
        self.sky, self.fog, self.colors, self.ground, self.margin = sky, fog, colors, ground, margin
    def place(self, time=0.0):
        for item in self.movers:
            item.place(time)
    def advance(self, dt):
        for item in self.movers:
            item.advance(dt)
STAGES = [
    Stage("ステージ 1", [
        polar(180, 10.0, 1.3, 4.0),
        polar(222, 10.0, 2.6, 4.0),
        polar(264, 10.0, 3.9, 4.0),
        polar(306, 9.5, 5.2, 3.8),
        polar(348, 9.5, 6.6, 3.8),
        polar(30, 9.0, 8.0, 3.6),
        polar(72, 9.0, 9.4, 3.6),
        polar(114, 8.5, 10.8, 3.4),
        polar(170, 8.5, 13.8, 3.2),
        polar(228, 8.0, 15.6, 3.2),
        polar(288, 7.5, 18.8, 3.0),
        polar(348, 7.0, 20.6, 3.0),
        polar(52, 6.5, 23.8, 2.8),
        polar(118, 6.0, 25.6, 2.6),
        polar(190, 5.0, 27.4, 2.5),
        polar(0, 0.0, 30.0, 3.0),
    ], start=(0.0, -15.0), start_yaw=0.0, sky=(140, 195, 240), fog=(35, 80),
        colors=[(90, 200, 110), (240, 210, 80), (240, 140, 60)], ground=(255, 255, 255), margin=0.8),
    Stage("ステージ 2", [
        (-6.0, -8.0, 1.4, 2.6, 2.6),
        (-1.5, -8.0, 2.8, 2.4, 2.4),
        (3.5, -8.0, 4.6, 2.2, 2.2),
        (9.0, -8.0, 6.4, 2.2, 2.2),
        (12.0, -3.0, 8.6, 1.2, 5.0),
        (8.0, 3.5, 11.6, 2.2, 2.2),
        (2.0, 3.5, 13.4, 2.0, 2.0),
        (-4.5, 3.5, 15.0, 2.0, 2.0),
        (-10.0, 3.5, 18.6, 2.2, 2.2),
        (-13.0, 9.0, 20.4, 1.2, 5.0),
        (-8.0, 14.5, 23.6, 2.0, 2.0),
        (-1.5, 14.5, 25.2, 5.0, 1.2),
        (5.5, 14.5, 28.6, 2.0, 2.0),
        (11.5, 14.5, 30.0, 1.8, 1.8),
        (13.0, 8.5, 33.4, 1.8, 1.8),
        (8.0, 4.0, 35.0, 1.8, 1.8),
        (3.5, 0.0, 38.0, 1.8, 1.8),
        (-2.0, -4.0, 40.0, 3.0, 3.0),
    ], start=(-6.0, -15.0), start_yaw=0.0, sky=(245, 175, 130), fog=(45, 95),
        colors=[(110, 130, 225), (190, 110, 205), (245, 110, 120)], ground=(200, 215, 190), margin=0.88),
    Stage("ステージ 3", [
        (0.0, -10.0, 1.4, 3.0, 3.0),
        (0.0, -4.5, 2.8, 2.6, 2.6),
        spring((0.0, 1.0, 3.6, 2.4, 2.4)),
        (0.0, 8.0, 10.0, 3.0, 3.0),
        mover((4.5, 8.0, 11.4, 2.4, 2.4), to=(7.0, 0.0, 0.0), period=5.0),
        (16.0, 8.0, 12.8, 2.4, 2.4),
        mover((16.0, 2.5, 13.6, 2.4, 2.4), to=(0.0, 6.0, 0.0), period=6.0),
        (16.0, -4.0, 21.0, 2.4, 2.4),
        spring((10.5, -4.0, 22.0, 2.0, 2.0)),
        (4.0, -4.0, 29.0, 2.4, 2.4),
        mover((-1.5, -4.0, 30.4, 2.2, 2.2), to=(0.0, 0.0, 8.0), period=5.0),
        mover((-7.0, 6.0, 31.8, 2.2, 2.2), to=(-7.0, 0.0, 0.0), period=4.4),
        (-15.0, 0.0, 33.4, 2.2, 2.2),
        spring((-15.0, -6.0, 34.2, 2.0, 2.0)),
        (-15.0, -13.5, 41.5, 2.4, 2.4),
        mover((-9.5, -13.5, 42.6, 2.2, 2.2), to=(8.0, 4.0, 0.0), period=6.0),
        spring((4.0, -13.5, 46.0, 2.0, 2.0)),
        (11.0, -13.5, 53.0, 3.0, 3.0),
    ], start=(0.0, -16.0), start_yaw=0.0, sky=(120, 110, 195), fog=(55, 115),
        colors=[(80, 225, 205), (130, 215, 255), (255, 240, 150)], ground=(170, 190, 215), margin=0.85),
]
def facing(a, b):
    return math.degrees(math.atan2(b.x - a.x, b.z - a.z)) % 360
